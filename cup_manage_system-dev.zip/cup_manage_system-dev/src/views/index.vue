<template>
  <div class="cup">
    <div class="nav">
      <NavComponent></NavComponent>
    </div>

    <div class="content">
      <TopComponent></TopComponent>
      <RouteHistoryComponent></RouteHistoryComponent>
      <keep-alive>
        <router-view v-if="$route.meta.keepAlive"></router-view>
      </keep-alive>
      <router-view v-if="!$route.meta.keepAlive"></router-view>

    </div>
    <!-- <keep-alive >
      <router-view v-if="$route.meta.keepAlive"></router-view>
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive"></router-view> -->
  </div>
</template>

<script>
import NavComponent from '@/components/nav/index.vue'
import TopComponent from '@/components/top/index.vue'
import RouteHistoryComponent from '@/components/routeHistory/index.vue'
export default {
  name: 'cupComponent',
  components: {
    NavComponent,
    TopComponent,
    RouteHistoryComponent
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.cup {
  width: 100%;
  display: flex;
  justify-content: flex-start;
  align-items: flex-start;
  .nav {
    height: 100vh;
    background-color: rgb(48, 65, 86);
  }
  .content {
    width: 100%;
  }
}
</style>
