<template>
  <div class="time">

    <div class="op">
        <el-form :inline="true"  class="demo-form-inline">
            <el-form-item label="請選擇比賽狀態">
                <el-select v-model="query.status" placeholder="請選擇比賽狀態" @change="init">
                    <el-option
                    v-for="item in statusOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="請選擇比賽類型">
                <el-select v-model="query.type" placeholder="請選擇比賽類型" @change="init">
                    <el-option
                    v-for="item in typeOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
        </el-form>
            <!-- <div class="flex-start-center">
                <span>请选择比赛状态</span>
                <el-select v-model="query.status" placeholder="请选择状态">
                    <el-option
                    v-for="item in statusOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div>
            <div class="flex-start-center">
                <span>请选择比赛类型</span>
                <el-select v-model="query.type" placeholder="请选择比赛类型">
                    <el-option
                    v-for="item in typeOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </div> -->
        <div class="flex-start-center">
            <el-button type="primary" @click="init">查詢</el-button>
            <el-button type="primary" @click="dialogVisible = true">新增配置</el-button>
            <!-- <el-button type="primary">主要按钮</el-button>
            <el-button type="primary">主要按钮</el-button> -->

        </div>
    </div>

    <el-dialog
        :title="!form.id?'新增賽程':'修改賽程'"
        :visible.sync="dialogVisible"
        width="60%"
        :before-close="handleClose">
        <div>
            <el-form ref="form" :model="form" label-width="200px">
                <el-form-item label="fomoAddress">
                    <el-input v-model="form.fomoAddress"></el-input>
                </el-form-item>
                <el-form-item label="gameModelAddress">
                    <el-input v-model="form.gameModelAddress"></el-input>
                </el-form-item>
                <el-form-item label="比賽狀態">
                    <el-radio-group v-model="form.status" @change="statusChange">
                        <el-radio v-for="v in statusOptions" :key="v.value" :label="v.value">{{v.label}}</el-radio>
                    </el-radio-group>
                </el-form-item>
                <el-form-item label="比賽類型">
                    <el-radio-group v-model="form.type">
                        <el-radio v-for="v in typeOptions" :key="v.value" :label="v.value">{{v.label}}</el-radio>
                    </el-radio-group>
                </el-form-item>
                <el-form-item label="比賽名稱">
                    <el-input v-model="form.name"></el-input>
                </el-form-item>
                <el-form-item label="隊伍A（國語）">
                    <el-input v-model="form.team1Name"></el-input>
                </el-form-item>
                <el-form-item label="隊伍A（英文）">
                    <el-input v-model="form.team1NameEn"></el-input>
                </el-form-item>
                <el-form-item label="隊伍A（得分）">
                    <el-input :disabled="form.status==1" v-model="form.team1Score"></el-input>
                </el-form-item>
                <el-form-item label="隊伍A(國旗)">
                    <img class="logo" :src="form.team1Logo" alt="">
                    <input type="file" accept="image/*" multiple="multiple" @change="changeImg('team1Logo',$event)">
                </el-form-item>
                <el-form-item label="隊伍B（國語）">
                    <el-input v-model="form.team2Name"></el-input>
                </el-form-item>
                <el-form-item label="隊伍B（英文）">
                    <el-input v-model="form.team2NameEn"></el-input>
                </el-form-item>
                <el-form-item label="隊伍B（得分）">
                    <el-input :disabled="form.status==1" v-model="form.team2Score"></el-input>
                </el-form-item>
                <el-form-item label="隊伍B(國旗)">
                    <img class="logo" :src="form.team2Logo" alt="">
                    <input type="file" accept="image/*" multiple="multiple" @change="changeImg('team2Logo',$event)">
                </el-form-item>
                <!-- <el-form-item label="活动区域">
                    <el-select v-model="form.region" placeholder="请选择活动区域">
                    <el-option label="区域一" value="shanghai"></el-option>
                    <el-option label="区域二" value="beijing"></el-option>
                    </el-select>
                </el-form-item> -->
                <!-- <el-form-item label="活动时间">
                    <el-col :span="11">
                    <el-date-picker type="date" placeholder="选择日期" v-model="form.date1" style="width: 100%;"></el-date-picker>
                    </el-col>
                    <el-col class="line" :span="2">-</el-col>
                    <el-col :span="11">
                    <el-time-picker placeholder="选择时间" v-model="form.date2" style="width: 100%;"></el-time-picker>
                    </el-col>
                </el-form-item> -->
                <!-- <el-form-item label="即时配送">
                    <el-switch v-model="form.delivery"></el-switch>
                </el-form-item> -->
                
                <!-- <el-form-item label="活动形式">
                    <el-input type="textarea" v-model="form.desc"></el-input>
                </el-form-item> -->
            </el-form>
        </div>
        <span slot="footer" class="dialog-footer">
            <el-button @click="handleClose">取 消</el-button>
            <el-button type="primary" @click="onSubmit">確 定</el-button>
        </span>
    </el-dialog>

    <el-table
    :data="tableData"
    border
    style="width: 100%">
    <el-table-column
      fixed
      prop="fomoAddress"
      label="fomoAddress"
      width="150">
    </el-table-column>
    <el-table-column
      prop="gameModelAddress"
      label="gameModelAddress"
      width="120">
    </el-table-column>
    <el-table-column
      prop="name"
      label="比賽名稱"
      width="120">
    </el-table-column>
    <el-table-column
      prop="team1Name"
      label="隊伍A（國語）">
    </el-table-column>
    <el-table-column
      prop="team1NameEn"
      label="隊伍A（英文）">
    </el-table-column>
    <el-table-column
      prop="team1Logo"
      label="隊伍A(國旗)">
      <template slot-scope="scope">
        <img :src="scope.row.team1Logo" class="logo" alt="">
      </template>
    </el-table-column>
    <el-table-column
      prop="team2Name"
      label="隊伍B（國語）">
    </el-table-column>
    <el-table-column
      prop="team2NameEn"
      label="隊伍B（英文）">
    </el-table-column>
    <el-table-column
      prop="team2Logo"
      label="隊伍B(國旗)">
      <template slot-scope="scope">
        <img :src="scope.row.team2Logo" class="logo" alt="">
      </template>
    </el-table-column>
    <el-table-column
      prop="status"
      label="狀態">
      <template slot-scope="scope">
        <span>{{ statusSpan(scope) }}</span>
      </template>
    </el-table-column>
    <el-table-column
      prop="type"
      label="類型">
      <template slot-scope="scope">
        <span>{{ typeSpan(scope) }}</span>
      </template>
    </el-table-column>
    <el-table-column
      fixed="right"
      label="操作"
      width="100">
      <template slot-scope="scope">
        <el-button @click="handleClick(scope.row)" type="text" size="small">编辑</el-button>
      </template>
    </el-table-column>
  </el-table>
  <div class="flex-start-center page">
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="query.currentPage"
      :page-sizes="[10, 20, 30, 40,100]"
      :page-size="query.pageSize"
      layout="total, sizes, prev, pager, next, jumper"
      :total="total">
    </el-pagination>
  </div>
  </div>

</template>

<script>
import {getRaceList,setRace} from "@/api/api"
export default {
  name: 'timeComponent',
  data () {
    return {
      total:0,
      props: { multiple: true },
      query:{
        "currentPage": 1,
        "pageSize":10,
        "status": 1,
        "type":""
      },
      tableData:[],
      dialogVisible:false,
      fileList:[],
      statusOptions:[{
          value: 0,
          label: '結束'
        },{
          value: 1,
          label: '未開始'
        },{
          value: 2,
          label: '進行中'
        },{
          value: 3,
          label: '暫停'
        }],
      typeOptions:[
        {
          value: "",
          label: '全部'
        },
        {
          value: 1,
          label: '普通比賽'
        },{
          value: 2,
          label: '總決賽'
        }],
      time: [
        // {
        //   value: 0,
        //   label: '0m',
        //   children: [{
        //     value: 0,
        //     label: '0s'
        //   },
        //   {
        //     value: 1,
        //     label: '1s'
        //   }

        //   ]
        // }
      ],
      form: {
        "date": "2022-10-29T07:46:20.532Z",
        "fomoAddress": "",
        "gameModelAddress": "",
        "name": "",
        "status": 1,// 0结束 1未开始 2进行中 3暂停
        "team1Logo": "",
        "team1Name": "",
        "team1NameEn": "",
        "team1Score": "0",
        "team2Logo": "",
        "team2Name": "",
        "team2NameEn": "",
        "team2Score": "0",
        "teams": "",
        "id":"",
        "type": 1,// 1普通比赛 2总决赛
      },
      currentPage4:1
    }
  },
  created () {
    this.init()
  },
  methods: {
    statusChange(){
        if(this.form.status==1){
            this.form.team1Score = 0
            this.form.team2Score = 0
        }
    },
    statusSpan(v){
        let statusOptions = this.statusOptions;
        let sapn = ""
        statusOptions.map((item)=>{
            if(item.value ==v.row.status){
                sapn = item.label
            }
        })
        return sapn
    }, 
    typeSpan(v){
        let statusOptions = this.typeOptions;
        let sapn = ""
        statusOptions.map((item)=>{
            if(item.value ==v.row.status){
                sapn = item.label
            }
        })
        return sapn
    },  
    handleClick(row) {
        this.form = row;
        this.dialogVisible = true
    },
    handleSizeChange(val) {
        this.query.pageSize = val;
        this.init()
        console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
        this.query.currentPage = val;
        this.init()
        console.log(`当前页: ${val}`);
    },
    handleClose(){
        this.dialogVisible = false
        this.initForm()
    },
    changeImg(k,e){
        const reader = new FileReader()
        // reader里面有个方法readAsDataURL 可以将图片转base64进制
        reader.readAsDataURL(e.target.files[0])
        // onload可以监听转换完成后
        reader.onload = () => {
        // 给声明变量赋值
            this.form[k] = reader.result
        }
    },  
    onSubmit(){
        let form = this.form
        form.teams = form.team1Name+ " VS " + form.team2Name
        setRace(this.form).then(()=>{
            this.dialogVisible = false;
            this.$message({
                message: '設置成功',
                type: 'success'
            });
            this.initForm();
            this.init()
        })
    },
    initForm(){
        this.form = {
                "date": "2022-10-29T07:46:20.532Z",
                "fomoAddress": "",
                "gameModelAddress": "",
                "name": "",
                "status": 1,// 0结束 1未开始 2进行中 3暂停
                "team1Logo": "",
                "team1Name": "",
                "team1NameEn": "",
                "team1Score": "0",
                "team2Logo": "",
                "team2Name": "",
                "team2NameEn": "",
                "team2Score": "0",
                "teams": "",
                "id":"",
                "type": 1,// 1普通比赛 2总决赛
            }
    },
    init () {
        let data = this.query
        getRaceList(data).then((res)=>{
            this.tableData = res.rows
            this.total = res.total
        })
    },
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.time {
  width: 100%;
  padding: 100px 0 0 20px;
  .op{
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
}
.page{
    margin:10px 0 0 0;
}
.logo{
    width: 20px;
    margin:20px
}
</style>
