<template>
  <div class="time">
    <el-form ref="form"
             :model="form"
             label-width="180px">

      <el-form-item label="蓄勢待發期">
        <el-input v-model="form.beforeG1KeyBuyTimeSpan"
        oninput ="value=value.replace(/[^0-9.]/g,'')"
                  placeholder="請輸入秒"></el-input>
      </el-form-item>
      <el-form-item label="延遲分紅期">
        <el-input v-model="form.beforeG1KeyShareTimeSpan"
        oninput ="value=value.replace(/[^0-9.]/g,'')"
                  placeholder="請輸入秒"></el-input>
      </el-form-item>
      <el-button type="primary"
                 @click="onSubmit">立即配置</el-button>
      <el-button>取消</el-button>
    </el-form>
  </div>

</template>

<script>
import { activate } from '@/api/api.js'
export default {
  name: 'timeComponent',
  data () {
    return {
      form: {
        beforeG1KeyBuyTimeSpan: '',
        beforeG1KeyShareTimeSpan: ''
      }
    }
  },
  created () {
    this.initTime()
  },
  methods: {
    initTime () {

    },
    onSubmit () {
      let data = [this.form.beforeG1KeyBuyTimeSpan, this.form.beforeG1KeyShareTimeSpan]
      // console.log(data)
      activate(data).then(() => {
        this.$message({
          message: '設置成功',
          type: 'success'
        });
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.time {
  width: 450px;
  padding: 100px 0 0 20px;
}
</style>
