<template>
  <div class="bonus">
    <el-form ref="form"
             :model="form"
             label-width="180px">
      <el-form-item label="下一場的地址">
        <el-select v-model="form.address"
                   filterable
                   placeholder="請選擇">
          <el-option v-for="item in options"
                     :key="item.value"
                     :label="item.teams"
                     :value="item.id">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="預設結束時間">
        <el-date-picker v-model="form.timestamp"
                        type="datetime"
                        value-format="timestamp"
                        placeholder="選擇日期時間">
        </el-date-picker>
      </el-form-item>
      <el-button type="primary"
                 @click="onSubmit">立即配置</el-button>
      <el-button>取消</el-button>
    </el-form>
  </div>
</template>

<script>
import { setNextPot, getRaceList } from "@/api/api.js"
export default {
  name: 'bonusComponent',
  data () {
    return {
      options: [],
      form: {
        address: "",
        timestamp: "",
      },
      dialogVisible: false,
      arr: [{ value: "", time: "" }],
    }
  },
  created () {
    this.init()
  },
  methods: {
    init () {
      let data = {
        "currentPage": 1,
        "pageSize": 10,
        "status": 1
      }
      getRaceList(data).then((res) => {
        this.options = res.rows
      })
    },
    onSubmit () {
      let form = this.form
      let data = [form.address, form.timestamp / 1000]
      setNextPot(data).then(() => {
        this.$message({
          message: '設置成功',
          type: 'success'
        });
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.bonus {
  width: 450px;
  padding: 100px 0 0 20px;
  .arr-item {
    margin: 0 0 20px 0;
  }
  .el-icon-circle-plus-outline {
    font-size: 20px;
    margin: 0 10px;
  }
  .el-icon-remove-outline {
    font-size: 20px;
  }
}
</style>
