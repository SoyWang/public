<template>
  <div class="time">
    <el-form ref="form"
             :model="form"
             label-width="180px">
      <el-form-item label="世界杯是否開始">
        <el-select v-model="form.cupBegin"
                   placeholder="世界杯是否開始">
          <el-option label="是"
                     :value="true"></el-option>
          <el-option label="否"
                     :value="false"></el-option>
        </el-select>
      </el-form-item>
			<el-form-item label="是否開啟買KEY">
        <el-select v-model="form.cupEnableKey"
                   placeholder="是否開啟買KEY">
          <el-option label="是"
                     :value="true"></el-option>
          <el-option label="否"
                     :value="false"></el-option>
        </el-select>
      </el-form-item>
			<el-form-item label="世界杯是否結束">
        <el-select v-model="form.cupEnd"
                   placeholder="世界杯是否結束">
          <el-option label="是"
                     :value="true"></el-option>
          <el-option label="否"
                     :value="false"></el-option>
        </el-select>
      </el-form-item>
      <el-button type="primary"
                 @click="onSubmit">立即配置</el-button>
      <el-button>取消</el-button>
    </el-form>
  </div>

</template>

<script>
import { setCup } from '@/api/api.js'
export default {
  name: 'timeComponent',
  data () {
    return {
      props: { multiple: true },
      time: [
        // {
        //   value: 0,
        //   label: '0m',
        //   children: [{
        //     value: 0,
        //     label: '0s'
        //   },
        //   {
        //     value: 1,
        //     label: '1s'
        //   }

        //   ]
        // }
      ],
      form: {
        cupBegin: false,
				cupEnableKey:false,
				cupEnd:false
      }
    }
  },
  created () {
    this.initTime()
  },
  methods: {
    initTime () {

    },
    onSubmit () {
			let form = this.form
			let data  = [form.cupEnd,form.cupEnableKey,form.cupEnd]
      setCup(data).then(()=>{
				this.$message({
					message: '設置成功',
					type: 'success'
				});
			})
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.time {
  width: 450px;
  padding: 100px 0 0 20px;
}
</style>
