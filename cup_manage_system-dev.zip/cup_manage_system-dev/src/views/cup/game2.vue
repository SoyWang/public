<template>
  <div class="time">
    <el-form ref="form"
             :model="form"
             label-width="180px">

      <el-form-item label="Game2強製開啟">
        <el-switch v-model="form.value"
                   active-text="是"
                   inactive-text="否"
                   active-color="#13ce66"
                   inactive-color="#999999">
        </el-switch>
      </el-form-item>
      <el-button type="primary"
                 @click="onSubmit">立即配置</el-button>
      <el-button>取消</el-button>
    </el-form>
  </div>

</template>

<script>
import { setForceOpenGame2 } from '@/api/api.js'
export default {
  name: 'timeComponent',
  data () {
    return {
      form: {
        value: false,
      }
    }
  },
  created () {
    this.initTime()
  },
  methods: {
    initTime () {

    },
    onSubmit () {
      setForceOpenGame2([true]).then(() => {
        this.$message({
          message: '設置成功',
          type: 'success'
        });
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.time {
  width: 450px;
  padding: 100px 0 0 20px;
}
</style>
