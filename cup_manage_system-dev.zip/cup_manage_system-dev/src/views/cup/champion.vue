<template>
  <div class="time">
    <el-form ref="form"
             :model="form"
             label-width="180px">
      <el-form-item label="冠軍隊伍">
        <el-select v-model="form.name"
                   filterable
                   placeholder="請選擇">
          <el-option v-for="v in raceSchedule"
                     :key="v.value"
                     :label="v.label"
                     :value="v.value"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="結束時間">
        <el-date-picker value-format="timestamp"
                        v-model="form.gameEnd"
                        type="datetime"
                        placeholder="選擇日期時間">
        </el-date-picker>
      </el-form-item>
      <el-button type="primary"
                 @click="onSubmit">立即配置</el-button>
      <el-button>取消</el-button>
    </el-form>
  </div>

</template>

<script>
import raceSchedule from '/public/data/raceSchedule.json'
import { setChampion } from '@/api/api.js'

export default {
  name: 'timeComponent',
  data () {
    return {
      props: { multiple: true },
      raceSchedule: raceSchedule.group,
      time: [
        // {
        //   value: 0,
        //   label: '0m',
        //   children: [{
        //     value: 0,
        //     label: '0s'
        //   },
        //   {
        //     value: 1,
        //     label: '1s'
        //   }

        //   ]
        // }
      ],
      form: {
        name: '',
        gameEnd:""
      }
    }
  },
  created () {
    // this.raceScheduleData()
  },
  methods: {
    onSubmit () {
      let form = this.form;
      let data = [[],[],form.gameEnd/1000,form.name]
      setChampion(data).then(()=>{
        this.$message({
          message: '設置成功',
          type: 'success'
        });
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.time {
  width: 450px;
  padding: 100px 0 0 20px;
}
</style>
