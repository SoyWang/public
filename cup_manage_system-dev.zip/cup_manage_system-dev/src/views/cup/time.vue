<template>
  <div class="time">
    <el-form ref="form"
             :model="form"
             label-width="180px">
      <!-- <el-form-item label="比賽場次">
        <el-select v-model="form.region"
                   value-key="id"
                   placeholder="請選擇比賽場次">
          <el-option :label="v.team_a+' VS '+v.team_b"
                     v-for="(v) in raceSchedule"
                     :key="v.id"
                     :value="v"></el-option>
        </el-select>
      </el-form-item> -->
      <el-form-item :label="($store.state.team1Name||'A')+'進球時間點'">
        <div class="data flex-start-center">
          <div v-for="(v,k) in data_a"
               class="item"
               :key="k">
            <el-date-picker v-model="v.timing"
                            type="datetime"
                            placeholder="選擇日期時間">
            </el-date-picker>
            <i class="el-icon-circle-plus-outline"
               @click="calculate('add',k)"></i>
            <i class="el-icon-remove-outline"
               @click="calculate('remove',k)"
               v-if="data_a.length>1"></i>
          </div>
        </div>

      </el-form-item>
      <el-form-item :label="($store.state.team1Name||'A')+'點球個數'">
        <el-input v-model="form.penalty_a"
                  oninput="value=value.replace(/[^0-9.]/g,'')"
                  placeholder="請輸入個數"></el-input>
      </el-form-item>
      <el-form-item :label="($store.state.team2Name||'B')+'進球時間點'">
        <div class="data flex-start-center">
          <div v-for="(v,k) in data_b"
               class="item"
               :key="k">
            <el-date-picker multiple
                            v-model="v.timing"
                            type="datetime"
                            placeholder="選擇日期時間">
            </el-date-picker>
            <i class="el-icon-circle-plus-outline"
               @click="calculateB('add',k)"></i>
            <i class="el-icon-remove-outline"
               @click="calculateB('remove',k)"
               v-if="data_b.length>1"></i>
          </div>
        </div>
      </el-form-item>
      <el-form-item :label="($store.state.team2Name||'B')+'點球個數'">
        <el-input v-model="form.penalty_b"
                  oninput="value=value.replace(/[^0-9.]/g,'')"
                  placeholder="請輸入個數"></el-input>
      </el-form-item>
      <el-form-item :label="'比賽結束時間點'">
        <el-date-picker v-model="form.endTime"
                        type="datetime"
                        placeholder="選擇日期時間">
        </el-date-picker>
      </el-form-item>
      <!-- <el-form-item label="赛果">
        <el-radio-group v-model="form.resource">
          <el-radio label="1">A赢</el-radio>
          <el-radio label="0">平局</el-radio>
          <el-radio label="2">B赢</el-radio>
        </el-radio-group>
      </el-form-item> -->

      <el-button type="primary"
                 @click="onSubmit">立即配置</el-button>
      <el-button>取消</el-button>
    </el-form>
  </div>
</template>

<script>
import raceSchedule from '/public/data/raceSchedule.json'
import { setGameResult } from '@/api/api.js'
export default {
  name: 'timeComponent',
  data () {
    return {
      raceSchedule: raceSchedule.game_group,
      props: { multiple: true },
      time: [
        // {
        //   value: 0,
        //   label: '0m',
        //   children: [{
        //     value: 0,
        //     label: '0s'
        //   },
        //   {
        //     value: 1,
        //     label: '1s'
        //   }

        //   ]
        // }
      ],
      data_a: [{ timing: "" }],
      data_b: [{ timing: "" }],

      form: {
        penalty_a: "",
        penalty_b: "",
        region: "",
        endTime: ""
      }
    }
  },
  async created () {
    console.log(this.$store.state.team1Name)
  },
  methods: {
    initTime () {
      let time = [];
      for (let i = 0; i < 120; i++) {
        let obj_m = {
          value: i,
          label: i + "m",
          children: []
        }
        for (let j = 0; j < 59; j++) {
          let obj_s = {
            value: j,
            label: j + "s",
          }
          obj_m.children.push(obj_s)
        }
        time.push(obj_m)
      }
      this.time = time
    },
    onSubmit () {
      // {
      // 	"name": "_timestampA",
      // 	"type": "uint256[]"
      // },
      // {
      // 	"name": "_timestampB",
      // 	"type": "uint256[]"
      // },
      // {
      // 	"name": "_gameEnd",
      let _timestampA = []
      let _timestampB = []
      let offset = new Date().getTimezoneOffset();
      let data_a = this.data_a
      let form = this.form
      if (data_a.length > 0) {
        data_a.forEach((item) => {
          if(item.timing){
            _timestampA.push(new Date(item.timing).getTime() / 1000)
          }
          
        })
      }


      for (let i = 0; i < form.penalty_a; i++) {
        _timestampA.push(0)
      }

      let data_b = this.data_b
      console.log(data_b)
      if (data_b.length > 0) {
        data_b.forEach((item) => {
          if(item.timing){
            _timestampB.push(new Date(item.timing).getTime() / 1000)
          }
          
        })
      }

      for (let i = 0; i < form.penalty_b; i++) {
        _timestampB.push(0)
      }
      // => -480 因为格林尼治时间比本地时间小8h
      // let obj = {
      //   _timestampA:_timestampA,
      //   _timestampB:_timestampB,
      //   _gameEnd: 
      // };
      // console.log(obj)
      let _gameEnd = new Date(this.form.endTime).getTime() / 1000 + offset * 60
      let data = [_timestampA, _timestampB, _gameEnd]
      console.log(data)
      setGameResult(data).then(() => {
        this.$message({
          message: '設置成功',
          type: 'success'
        });
      })
    },
    calculate (type, index) {

      if (type == 'add') {
        let obj = {
          value: "",
          timing: ""
        }
        let arr = this.data_a;
        console.log(arr)
        arr.push(obj)
        this.data_a = arr
      } else {
        let arr = this.data_a;
        arr.splice(index, 1)
        this.data_a = arr
      }
    },
    calculateB (type, index) {

      if (type == 'add') {
        let obj = {
          value: "",
          timing: ""
        }
        let arr = this.data_b;
        console.log(arr)
        arr.push(obj)
        this.data_b = arr
      } else {
        let arr = this.data_b;
        arr.splice(index, 1)
        this.data_b = arr
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.time {
  width: 650px;
  padding: 100px 0 0 20px;
  .data {
    flex-direction: column;
    .item {
      margin: 0 0 10px 0;
    }
  }
  .el-form-item {
    display: flex;
    justify-items: flex-start;
    align-items: flex-start;
    .el-form-item__content {
      margin-left: 0 !important;
    }
  }
  .el-icon-circle-plus-outline {
    font-size: 20px;
    margin: 0 10px;
  }
  .el-icon-remove-outline {
    font-size: 20px;
  }
}
</style>
