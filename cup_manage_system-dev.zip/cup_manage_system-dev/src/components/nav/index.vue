<template>
  <div class="nav"
       :class="isCollapse?'hide-nav':''">
    <el-row class="tac">
      <el-col :span="24">
        <el-menu :default-active="activeNav"
                 class="el-menu-vertical"
                 @open="handleOpen"
                 @close="handleClose"
                 background-color="#304156"
                 text-color="#BFCBD9"
                 :collapse="isCollapse"
                 router
                 active-text-color="rgb(64, 158, 255)">
          <el-submenu :index="k+1+''"
                      v-for="(v,k) in routes"
                      v-show="!v.meta.hide&&((cupFlag&&v.name=='cup')||(kolFlag&&v.name=='kol'))"
                      :key="k">

            <template slot="title">
              <i class="el-icon-location"></i>
              <span>{{v.name}}</span>
            </template>
            <el-menu-item-group v-if="!v.meta.hide">
              <el-menu-item v-for="(vi,ki) in v.children"
                            :key="k+'-'+ki"
                            :index="'/'+v.name+'/'+vi.name">{{vi.meta.title}}</el-menu-item>
            </el-menu-item-group>
          </el-submenu>
        </el-menu>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { CUP_ADDRESS } from '/public/data/cupAddress'
import { KOL_ADDRESS } from '/public/data/kolAddress'
import router from '../../router/index.js'
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  watch: {
    $route: {
      handler: function (val) {
        this.activeNav = val.fullPath
      },
      // 深度观察监听
      deep: true
    }
  },
  data () {
    return {
      cupFlag: false,
      kolFlag: false,
      activeNav: "/cup/time",
      routes: router.options.routes,
      isCollapse: false
    }
  },
  created () {
    this.activeNav = window.location.hash.split("#")[window.location.hash.split("#").length - 1]
    console.log(window.location.hash)
    let address = localStorage.getItem("address")
    for (let i = 0; i < CUP_ADDRESS.length; i++) {
      console.log(CUP_ADDRESS[i], address)
      if (address.toLowerCase() == CUP_ADDRESS[i].toLowerCase()) {
        this.cupFlag = true;
        break
      }
    }
    for (let i = 0; i < KOL_ADDRESS.length; i++) {
      if (address.toLowerCase() == KOL_ADDRESS[i].toLowerCase()) {
        this.kolFlag = true;
        break
      }
    }
    if (!this.cupFlag && !this.kolFlag) {
      localStorage.removeItem("address")
      this.$message({
        message: '該賬號沒有權限，請切換賬號',
        type: 'warning'
      });
      this.$router.push({ path: "/login" })
    }
    console.log(this.cupFlag, this.kolFlag)
  },
  methods: {
    handleOpen (key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose (key, keyPath) {
      console.log(key, keyPath);
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.nav {
  width: 210px;
  .el-menu-vertical {
    text-align: start;
  }
}
.hide-nav {
  width: auto;
}
</style>
