<template>
  <div class="top">
    <div class="top-team">
      <el-form ref="form"
               :model="form"
               v-if="selectShow"
               label-width="180px">
        <el-form-item label="請選擇比賽場次">
          <el-select v-model="form.address"
                     filterable
                     value-key="id"
                     @change="addressChange()"
                     placeholder="請選擇">
            <el-option v-for="item in options"
                       :key="item.value"
                       :label="item.teams"
                       :value="item">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
    </div>

    <div class="top-user">
      <span class="auth flex-start-center">歡迎您 <span class="address">{{auth.address}}</span></span>
      <span @click="loginout"
            class="loginout">退出登錄</span>
    </div>

  </div>
</template>

<script>
import { setFomoAddress, setGameModeAddress } from "@/api/cryptozombies"
import { getRaceList } from "@/api/api.js"
export default {
  name: 'topComponent',
  watch: {
    $route: {
      handler: function (val, oldVal) {
        console.log(val, oldVal);
        this.selectShowFlag(val)
      },
      // 深度观察监听
      deep: true
    }
  },
  data () {
    return {
      selectShow: false,
      selectShowNav: ["bonus", "game1Time", "game1Stage", "game2", "time", "jackpot", "champion"],
      auth: {
        address: ""
      },
      form: {
        address: {
          // ga
          fomoAddress: "",
          gameModelAddress: ""
        }
      },
      address: "",
      options: [],
    }
  },
  created () {
    this.auth.address = localStorage.getItem("address")
    let selectShowNav = this.selectShowNav
    let current = this.$router.history.current
    if (selectShowNav.indexOf(current.name) != -1) {
      this.selectShow = true
    } else {
      this.selectShow = false
    }
    this.init()
  },
  methods: {
    selectShowFlag (val) {
      let selectShowNav = this.selectShowNav
      if (selectShowNav.indexOf(val.name) != "-1") {
        this.selectShow = true
      } else {
        this.selectShow = false
      }
    },
    init () {
      let data = {
        "currentPage": 1,
        "pageSize": 100,
      }
      getRaceList(data).then((res) => {
        this.options = res.rows
        if (res.rows.length > 0) {
          this.form.address = res.rows[0]
          this.addressChange()

        }
      })
    },
    addressChange (v) {
      console.log(v)
      setFomoAddress(this.form.address.fomoAddress)
      setGameModeAddress(this.form.address.gameModelAddress)
      this.$store.commit("changeTeam", this.form.address)
    },
    loginout () {
      localStorage.removeItem("address")
      this.$router.push({ path: '/login' })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.top {
  height: 64px;
  width: 100%;
  padding: 0 20px;
  background: #fff;
  border-bottom: 1px solid #d8dce5;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  display: flex;
  justify-content: space-between;
  align-items: center;
  .top-team {
    margin: 20px 0 0 0;
  }
  .top-user {
    display: flex;
    justify-content: flex-start;
    align-items: center;
  }
  .auth {
    .address {
      display: inline-block;
      width: 200px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      margin: 0 0 0 20px;
      font-size: 24px;
    }
  }
  .loginout {
    cursor: pointer;
    &:hover {
      color: #409efe;
    }
  }
  .el-form {
    .el-form-item__label {
      color: red;
    }
  }
}
</style>
