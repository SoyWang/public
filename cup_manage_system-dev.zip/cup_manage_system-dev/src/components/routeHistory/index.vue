<template>
  <div class="routeHistory">
    <span v-for="(v,k) in routeArr"
				@click="routeLink(v)"
          :key="v.name"
          class="item"
          :class="v.name==$route.name?'active':''">
      {{v.meta.title}}
      <el-icon v-if="v.name==$route.name&&routeArr.length>1?'active':''"
               @click.native="deleteRoute(k)"
               class="el-icon-close"></el-icon>
    </span>
  </div>
</template>

<script>
export default {
  name: 'routeHistory',
  // 监听,当路由发生变化的时候执行
  watch: {
    $route: {
      handler: function (val, oldVal) {
        console.log(val, oldVal);
        let routeArr = this.routeArr;
        let flag = true
        for (let i = 0; i < routeArr.length; i++) {
          if (routeArr[i].name === val.name) {
            // routeArr[i]['active'] = true
            flag = false
          } else {
            // routeArr[i]['active'] = false
          }
        }
        if (flag) {
          // val['active'] = true
          routeArr.push(val)
        }
        this.routeArr = routeArr
      },
      // 深度观察监听
      deep: true
    }
  },
  data () {
    return {
      routeArr: [],

    }
  },
  created(){
    let current=  this.$router.history.current
    this.routeArr = [current]
  },
  methods: {
    routeLink (v) {
      if (v.name != this.$route.name) {
        this.$router.push({ name: v.name })
      }

    },
    deleteRoute (k) {
      console.log(k)
      this.$router.go(-1)
      let routeArr = this.routeArr
      routeArr.splice(k, 1)
      this.routeArr = routeArr
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.routeHistory {
  height: 36px;
  border-bottom: 1px solid #d8dce5;
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.12);
  display: flex;
  justify-items: center;
  align-items: flex-start;
  .item {
    display: inline-block;
    position: relative;
    cursor: pointer;
    height: 26px;
    line-height: 26px;
    border: 1px solid #d8dce5;
    color: #495060;
    background: #fff;
    padding: 0 8px;
    font-size: 12px;
    margin-left: 5px;
    margin-top: 4px;
    flex-shrink: 0;
  }
  .active {
    background-color: #42b983;
    border-color: #42b983;
    color: white;
    &::before {
      content: '';
      background: #fff;
      display: inline-block;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      position: relative;
      margin-right: 2px;
    }
  }
}
</style>
