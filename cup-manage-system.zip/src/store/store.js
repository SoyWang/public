import Vue from 'vue'

import Vuex from 'vuex'

Vue.use(Vuex)
const store =  new Vuex.Store({
	state:{
		team1Name:"",
		team2Name:""
	},
	mutations:{
		changeTeam(state,msg){
			state.team1Name = msg.team1Name
			state.team2Name = msg.team2Name
		}
	}
})
export default store