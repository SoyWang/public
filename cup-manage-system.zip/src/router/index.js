import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '@/views/index'
Vue.use(VueRouter)
//   // let cupAddress = CUP_ADDRESS
//   // let kolAddress = KOL_ADDRESS
// import {CUP_ADDRESS} from '/public/data/cupAddress'
// import {KOL_ADDRESS} from '/public/data/kolAddress'
const cupRoutes = {
  path: '/kol',
  name: 'kol',
  component: Home,
  label:"",
  hidden:false,
  meta:{keepAlive: true,hide:false}, // 是否缓存组件
  redirect: '/kol/regular',
  children: [
    {
      path: 'regular',
      name: 'regular',
      meta:{keepAlive: true,title:'kol轉正資格配置'}, // 是否缓存组件
      component: () => import('@/views/kol/regular.vue')
    },{
      path: 'deposit',
      name: 'deposit',
      meta:{keepAlive: true,title:'kol退押金資格配置'}, // 是否缓存组件
      component: () => import('@/views/kol/deposit.vue')
    },]
  }
const kolRoutes ={
  path: '/cup',
  name: 'cup',
  component: Home,
  label:"",
  hidden:false,
  meta:{keepAlive: true}, // 是否缓存组件
  redirect: '/cup/bonus',
  children: [
    {
      path: 'race',
      name: 'race',
      
      meta:{keepAlive: true,title:"比賽配置"}, // 是否缓存组件
      component: () => import('@/views/cup/race.vue')
    },
    {
      path: 'bonus',
      name: 'bonus',
      
      meta:{keepAlive: true,title:"奖池流转配置"}, // 是否缓存组件
      component: () => import('@/views/cup/bonus.vue')
    }
    ,
    {
      path: 'game1Time',
      name: 'game1Time',
      
      meta:{keepAlive: true,title:"game1起止時間配置"}, // 是否缓存组件
      component: () => import('@/views/cup/game1Time.vue')
    },
    {
      path: 'game1Stage',
      name: 'game1Stage',
      
      meta:{keepAlive: true,title:"game1階段時間間隔配置"}, // 是否缓存组件
      component: () => import('@/views/cup/game1Stage.vue')
    },
    {
      path: 'game2',
      name: 'game2',
      
      meta:{keepAlive: true,title:"game2強製開啟"}, // 是否缓存组件
      component: () => import('@/views/cup/game2.vue')
    },
    {
      path: 'time',
      name: 'time',
      meta:{keepAlive: true,title:'進球時間點及賽果配置'}, // 是否缓存组件
      component: () => import('@/views/cup/time.vue')
    },
    {
      path: 'jackpot',
      name: 'jackpot',
      meta:{keepAlive: true,title:'獎池查詢'}, // 是否缓存组件
      component: () => import('@/views/cup/jackpot.vue')
    },
    {
      path: 'champion',
      name: 'champion',
      
      meta:{keepAlive: true,title:"冠軍隊伍配置"}, // 是否缓存组件
      component: () => import('@/views/cup/champion.vue')
    },
    // {
    //   path: 'keySetting',
    //   name: 'keySetting',
      
    //   meta:{keepAlive: true,title:"key價格配置"}, // 是否缓存组件
    //   component: () => import('@/views/cup/key.vue')
    // }
    // ,
    {
      path: 'worldCup',
      name: 'worldCup',
      
      meta:{keepAlive: true,title:"世界杯信息配置"}, // 是否缓存组件
      component: () => import('@/views/cup/worldCup.vue')
    }
    ,
    {
      path: 'gas',
      name: 'gas',
      
      meta:{keepAlive: true,title:"充值提現手續費配置"}, // 是否缓存组件
      component: () => import('@/views/cup/gas.vue')
    }
  ]
}
const normolRoutes={
  path: '/login',
  name: 'login',
  label:"",
  component: () => import('@/views/login/login.vue'),
  meta:{keepAlive: false,hide:true}, // 是否缓存组件
}
let routes = [
  
]
routes.push(kolRoutes)
routes.push(cupRoutes)

routes.push(normolRoutes)
let router = new VueRouter({
  routes
})
router.beforeEach((to, from, next) => {
  let userInfo = localStorage.getItem("address")
  if(userInfo){
    next()
    // if(CUP_ADDRESS.indexOf(userInfo)!=-1||KOL_ADDRESS.indexOf(userInfo)!=-1){
    //   for(let i=0;i<cupRoutes.children.length;i++){
    //     if(cupRoutes.children[i].name==to.name){
    //       next()
    //     }
    //   }
    //   for(let i=0;i<kolRoutes.children.length;i++){
    //     if(kolRoutes.children[i].name==to.name){
    //       next()
    //     }
    //   }
    //   next({path:"/login"})
    // }else{
    //   localStorage.removeItem("address")
    //   next({path:"/login"})
    // }
  }else{
    if(to.name=="login"){
      next()
    }else{
      next({path:"/login"})
    }
  }
  next()
})
// router.beforeEach(()=>{
// })
// export function getRoute(data){
//   // let cupAddress = CUP_ADDRESS
//   // let kolAddress = KOL_ADDRESS
//   // routes.push(normolRoutes)
//   // if(data && data.address){
    
//   // }
  
  
// }
export default router
