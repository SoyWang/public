import { fomoMethods,gameModeMethods ,kolMethods,bankMethods} from './cryptozombies'

import { post,put } from './axios'



//******************************************* fomo ****************************************//

// 设置比赛结果
export const setGameResult = (data) => fomoMethods('setGameResult',"send", data)

// 设置冠军
export const setChampion = (data) => fomoMethods('setChampion',"send", data)

// game1阶段时间间隔配置
export const activate = (data) => fomoMethods('activate',"send", data)

// 查看当前奖池是否流转
export const swap = (data) => fomoMethods('swap',"call", data)

// 当前池子的剩余余额
export const getBalance = (data) => fomoMethods('getBalance',"call", data)

//******************************************* gameMode ****************************************//

// 设置game1 起止时间配置
export const setPara = (data) => gameModeMethods('setPara',"send", data)

// game2强制开启
export const setForceOpenGame2 = (data) => gameModeMethods('setForceOpenGame2',"send", data)

// 流转设置
export const setNextPot = (data) => gameModeMethods('setNextPot',"send", data)

//******************************************* kol ****************************************//

// 获取用户数据列表
export const getUserByStatus = (data) => kolMethods('getUserByStatus',"call", data)

// 设置用户转正
export const setUserVerified = (data) => kolMethods('setUserVerified',"send", data)

// 设置用户提现资格
export const setUserIsReach = (data) => kolMethods('setUserIsReach',"send", data)

// 设置世界杯相关参数
export const setCup = (data) => kolMethods('setCup',"send", data)

//******************************************* bank ****************************************//

// 设置提现手续费
export const setWithdrawFee = (data) => bankMethods('setWithdrawFee',"send", data)

// 设置充值手续费
export const setTopUpFee = (data) => bankMethods('setTopUpFee',"send", data)


//******************************************* http ****************************************//
// 获取所有未启动的比赛
export const getRaceList = (data) => post("/race/list",data)
// 新增比赛
export const setRace = (data) => put("/race",data)