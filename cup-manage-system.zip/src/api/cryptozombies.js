
import Web3 from 'web3'
import {GAMEMODE_ADDRESS,GAMEMODE_ABI} from '/public/data/gamemode.js'
import {FOMO_ADDRESS,FOMO_ABI} from '/public/data/fomo.js'
import {KOL_ADDRESS,KOL_ABI} from '/public/data/kol.js'
import {BANK_ADDRESS,BANK_ABI} from '/public/data/bank.js'

import { Message, Loading } from 'element-ui'

let web3 = new Web3(window.web3.currentProvider)

let myContract = "";
let fomoContract = ""
let gamemodeContract = ""
let kolContract=""
let bankContract=""
let address = ""
let loadingInstance
// 获取用户授权
function getAuth() {  
	console.log(window.ethereum)
	if (window.ethereum) {
		return new Promise((resolve, reject) => {
			window.ethereum.enable().then((res) => {
				web3.eth.defaultAccount = res[0]
				address = res[0]
				myContract = web3.eth.Contract;
				
				kolContract = new myContract(KOL_ABI,KOL_ADDRESS).methods;
				bankContract = new myContract(BANK_ABI,BANK_ADDRESS).methods;
				resolve(res);
				// alert("当前钱包地址:" + res[0]);
			}).catch((err)=>{
				reject(err)
			})
		})
		
	} else {
		alert("请安装MetaMask钱包");
	}
}
getAuth()
// 设置fomo合约地址
export function setFomoAddress(address){
	fomoContract = new myContract(FOMO_ABI,address).methods;
	console.log(FOMO_ADDRESS)
}
// 设置gamemode合约地址
export function setGameModeAddress(address){
	gamemodeContract = new myContract(GAMEMODE_ABI,address).methods;
	console.log(GAMEMODE_ADDRESS)
}
export function fomoMethods (method, type,data) {
	loadingInstance = Loading.service({ fullscreen: true })
  return new Promise((resolve, reject) => {
		fomoContract[method](...data)[[type]]({from:address})
		.then((res) => {
			loadingInstance.close()
			resolve(res)
		})
		.catch((err) => {
			Message('设置失败')
			loadingInstance.close()
			console.log(err)
			reject(err)
		})
  })
}
export function gameModeMethods(method,type,data) {
	console.log(...data)
	loadingInstance = Loading.service({ fullscreen: true })
	return new Promise((resolve, reject) => {
		gamemodeContract[method](...data)[type]({from:address})
		.then((res) => {
			loadingInstance.close()
			console.log(res)
			resolve(res)
		})
		.catch((err) => {
			Message('设置失败')
			loadingInstance.close()
			console.log(err)
			reject(err)
		})
  })
}

export function kolMethods(method,type,data) {
	loadingInstance = Loading.service({ fullscreen: true })
	return new Promise((resolve, reject) => {
		console.log(data)
		kolContract[method](...data)[type]({from:address})
		.then((res) => {
			loadingInstance.close()
			console.log(res)
			resolve(res)
		})
		.catch((err) => {
			Message('设置失败')
			loadingInstance.close()
			console.log(err)
			reject(err)
		})
  })
}
export function bankMethods(method,type,data) {
	loadingInstance = Loading.service({ fullscreen: true })
	return new Promise((resolve, reject) => {
		console.log(data)
		bankContract[method](...data)[type]({from:address})
		.then((res) => {
			loadingInstance.close()
			console.log(res)
			resolve(res)
		})
		.catch((err) => {
			Message('设置失败')
			loadingInstance.close()
			console.log(err)
			reject(err)
		})
  })
}
export {
	getAuth
}