import Vue from 'vue';
import App from './App.vue';
import router from './router';
import Vuex from 'vuex'
import store from './store/store'



import Web3 from 'web3'
Vue.config.productionTip = false
Vue.prototype.Web3 = Web3

import Element from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css';//使用
import 'element-ui/lib/locale/lang/zh-TW'
import i18n from './lang/index'
import './styles/index.scss';//使用
// Vue.use(Element);
Vue.use(Element, {
  i18n: (key, value) => i18n.t(key, value)
});
Vue.use(Vuex);
Vue.config.productionTip = false;
new Vue({
  i18n,
  router,
  store,
  render: h => h(App),
}).$mount('#app');