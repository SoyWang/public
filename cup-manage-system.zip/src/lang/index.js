import Vue from 'vue'
import VueI18n from 'vue-i18n'
// import cnlocale from './zh-cn'
// import molocale from './zh-mo'
import zhLocale from 'element-ui/lib/locale/lang/zh-CN'
import twLocale from 'element-ui/lib/locale/lang/zh-TW'
console.log(twLocale)
Vue.use(VueI18n)

const i18n = new VueI18n({
locale: "mo",
messages: {
cn: {
// ...cnlocale,
...zhLocale
},
mo: {
// ...molocale,
...twLocale
}
}
})

export default i18n