<template>
  <div class="time">
    <el-form ref="form"
             class="form"
             :model="form1"
             label-width="280px">
      <el-form-item label="充值手續費配置(0-1000000)">
        <el-input-number v-model="form1.value"
                         :min="0"
                         :max="1000000"
                         label=""></el-input-number>
      </el-form-item>

      <el-button type="primary"
                 @click="onSubmit1">立即配置</el-button>
      <el-button>取消</el-button>
    </el-form>
    <el-form ref="form"
             class="form"
             :model="form2"
             label-width="280px">
      <el-form-item label="提現手續費配置(0-1000000)">
        <el-input-number v-model="form2.value"
                         :min="0"
                         :max="1000000"
                         label=""></el-input-number>
      </el-form-item>

      <el-button type="primary"
                 @click="onSubmit2">立即配置</el-button>
      <el-button>取消</el-button>
    </el-form>
  </div>

</template>

<script>
import { setWithdrawFee, setTopUpFee } from '@/api/api.js'
export default {
  name: 'timeComponent',
  data () {
    return {
      props: { multiple: true },
      time: [
        // {
        //   value: 0,
        //   label: '0m',
        //   children: [{
        //     value: 0,
        //     label: '0s'
        //   },
        //   {
        //     value: 1,
        //     label: '1s'
        //   }

        //   ]
        // }
      ],
      form1: {
        value: ""
      },
      form2: {
        value: ""
      }
    }
  },
  created () {
    this.initTime()
  },
  methods: {
    initTime () {

    },
    onSubmit1 () {
      let gas = this.form1.value
      setTopUpFee([gas]).then(() => {
        this.$message({
          message: '設置成功',
          type: 'success'
        });
      })
    }
    ,
    onSubmit2 () {
      let gas = this.form2.value
      setWithdrawFee([gas]).then(() => {
        this.$message({
          message: '設置成功',
          type: 'success'
        });
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.time {
  width: 600px;
  padding: 100px 0 0 20px;
  .form {
    margin: 0 0 20px 0;
  }
}
</style>
