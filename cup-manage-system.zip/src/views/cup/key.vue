<template>
  <div class="time">
    <el-form ref="form"
             :model="form"
             label-width="180px">
      <el-form-item label="价格输入（F3Cash）">
        <el-input v-model="form.value"
                  placeholder="价格输入（F3Cash）"></el-input>
      </el-form-item>

      <el-button type="primary"
                 @click="onSubmit">立即配置</el-button>
      <el-button>取消</el-button>
    </el-form>
  </div>

</template>

<script>

export default {
  name: 'timeComponent',
  data () {
    return {
      props: { multiple: true },
      time: [
        // {
        //   value: 0,
        //   label: '0m',
        //   children: [{
        //     value: 0,
        //     label: '0s'
        //   },
        //   {
        //     value: 1,
        //     label: '1s'
        //   }

        //   ]
        // }
      ],
      form: {
				value:""
      }
    }
  },
  created () {
    this.initTime()
  },
  methods: {
    initTime () {
      
    },
    onSubmit () {
      console.log(this.form)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.time {
  width: 450px;
  padding: 100px 0 0 20px;
}
</style>
