<template>
  <div class="time">
    <el-form ref="form"
             :model="form"
             label-width="180px">

      <!-- <el-form-item label="比賽選擇">
        <el-select v-model="form.region"
                   value-key="id"
                   placeholder="請選擇比賽場次">
          <el-option :label="v.team_a+' VS '+v.team_b"
                     v-for="(v) in raceSchedule"
                     :key="v.id"
                     :value="v"></el-option>
        </el-select>
      </el-form-item> -->
      <el-form-item label="起止時間">
        <el-date-picker v-model="form.time"
                        style="margin:0 0 0 16px"
                        type="datetimerange"
                        value-format="timestamp"
                        start-placeholder="開始日期"
                        end-placeholder="結束日期">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="比賽開始時間">
        <el-date-picker v-model="form.gameStart"
                        type="datetime"
                        value-format="timestamp"
                        start-placeholder="開始日期"
                        end-placeholder="結束日期">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="設定分配模式">
        <el-select v-model="form.resultMode"
                   placeholder="請選擇分配模式">
          <el-option label="根據進球點映射模式"
                     :value="1"></el-option>
          <el-option label="猜中者均分模式"
                     :value="0"></el-option>
        </el-select>
      </el-form-item>
      <el-button type="primary"
                 @click="onSubmit">立即配置</el-button>
      <el-button>取消</el-button>
    </el-form>
  </div>

</template>

<script>
import raceSchedule from '/public/data/raceSchedule.json'
import { setPara } from '@/api/api.js'
export default {
  name: 'timeComponent',
  data () {
    return {
      raceSchedule: raceSchedule.game_group,
      form: {
        name: '',
        region: "",
        time: '',
        gameStart: "",
        resultMode: 1
      },
    }
  },
  created () {
    // getWallet()
    // getETH().then((res)=>{
    //   console.log(res)
    // });
    this.initTime()
  },
  methods: {
    initTime () {

    },
    onSubmit () {
      // _game1Start-投票开始时间
      // _game1End-投票结束时间
      // _gameStart-比赛开始时间
      // _resultMode-比赛模式（1是一般比赛，0是冠军赛）
      let form = this.form
      let obj = {
        game1Start: form.time[0] / 1000,
        game1End: form.time[1] / 1000,
        gameStart: form.gameStart / 1000
      }
      let data = [obj.game1Start, obj.game1End, obj.gameStart, form.resultMode]
      setPara(data).then(() => {
        this.$message({
          message: '設置成功',
          type: 'success'
        });
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.time {
  width: 450px;
  padding: 100px 0 0 20px;
}
</style>
