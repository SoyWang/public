<template>
  <div class="time">
    <el-form ref="form"
             :model="form"
             label-width="180px">
      <el-form-item label="池子的剩余余額">
        <div class="item">
          <span class="span">{{form.balance}}</span>
          <el-button type="primary"
                     @click="getBalanceSearch">立即查詢</el-button>
        </div>

      </el-form-item>
      <el-form-item label="獎池是否流轉">
        <div class="item">
          <span class="span">{{form.swap?'是':'否'}}</span>
          <el-button type="primary"
                     @click="getSwap">立即查詢</el-button>
        </div>

      </el-form-item>
      <!-- <el-button type="primary"
                 @click="onSubmit">立即查询</el-button>
      <el-button>取消</el-button> -->
    </el-form>
  </div>

</template>

<script>
import { swap, getBalance } from '@/api/api.js'
export default {
  name: 'timeComponent',
  data () {
    return {
      props: { multiple: true },
      time: [
        // {
        //   value: 0,
        //   label: '0m',
        //   children: [{
        //     value: 0,
        //     label: '0s'
        //   },
        //   {
        //     value: 1,
        //     label: '1s'
        //   }

        //   ]
        // }
      ],
      form: {
        balance: 0,
        swap: false,
      }
    }
  },
  created () {
    setTimeout(() => {
      this.getBalanceSearch()
      this.getSwap()
    }, 1000);

  },
  methods: {
    // 获取当前池子的剩余余额
    getBalanceSearch () {
      getBalance([]).then((res) => {
        this.form.balance = res
      })
    },
    // 查看当前奖池是否流转
    getSwap () {
      swap([]).then((res) => {
        this.form.swap = res
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.time {
  width: 450px;
  padding: 100px 0 0 20px;
  .item {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
  }
  .span {
    display: inline-block;
    width: 200px;
    margin: 0 20px 0 0;
  }
}
</style>
