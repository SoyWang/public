<template>
  <div class="time">
    <div class="flex-start-center">
      <el-select v-model="status"
                 @change="init"
                 placeholder="請選擇">
        <el-option v-for="item in options"
                   :key="item.value"
                   :label="item.label"
                   :value="item.value">
        </el-option>
      </el-select>
      <el-button class="btn"
                 type="primary"
                 @click="setUserIsReachFuc()">批量通過</el-button>
    </div>

    <el-table :data="tableData.slice((pageData.pageNo - 1) * pageData.pageSize, pageData.pageNo * pageData.pageSize)"
              style="width: 100%"
              @selection-change="handleSelectionChange"
              :row-class-name="tableRowClassName">
      <el-table-column type="selection"
                       :selectable='checkboxSelect'
                       width="55">
      </el-table-column>

      <el-table-column prop="lastBlock"
                       label="kol錢包地址信息">
      </el-table-column>
      <!-- <el-table-column prop="numOf"
                       label="当前层数/邀请人数">
      </el-table-column> -->
      <el-table-column prop="numOf"
                       label="可退押金金額">
      </el-table-column>
      <el-table-column fixed="right"
                       label="是否滿足退押金資格"
                       width="200">
        <template slot-scope="scope">
          <!-- <el-button @click="handleClick(scope.row)" type="text" size="small">查看</el-button> -->
          <el-button type="text"
                     v-if="scope.row.isReach"
                     size="small"
                     @click="setUserIsReachFuc(scope.row)">通過</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="block flex-start-center">
      <el-pagination @size-change="handleSizeChange"
                     @current-change="handleCurrentChange"
                     :current-page="pageData.pageNo"
                     :page-sizes="[10, 20, 30, 40]"
                     :page-size="10"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="tableData.length">
      </el-pagination>
    </div>
  </div>

</template>

<script>
import { getUserByStatus, setUserIsReach } from '@/api/api.js'
export default {
  name: 'timeComponent',
  data () {
    return {
      status: 1,
      pageData: {
        pageNo: 1,
        pageSize: 10,
        account: 20,
      },
      // 1：验证中   2：待验证
      options: [{
        label: "驗證中",
        value: 1
      }, {
        label: "已驗證",
        value: 2
      }
      ],
      form: {
        name: '',
        region: 1
      },
      tableDataItem: [],
      // {
      // 			"name": "lastBlock",
      // 			"type": "uint256"
      // 		},
      // 		{
      // 			"name": "numOf",
      // 			"type": "uint256"
      // 		},
      // 		{
      // 			"name": "status",
      // 			"type": "uint8"
      // 		},
      // 		{
      // 			"name": "isReach",
      // 			"type": "bool"
      // 		}
      tableData: [],
      selectData: []
    }
  },
  created () {

  },
  mounted () {
    setTimeout(() => {
      this.init()
    }, 1000);

  },
  methods: {
    checkboxSelect (row) {
      if (row.status == 1) {
        return true // 禁用
      } else {
        return false // 不禁用
      }
    },
    handleSelectionChange (val) {
      this.selectData = val
      console.log(val)
    },
    setUserIsReachFuc (item) {
      let data = []
      if (item) {
        data = [item.lastBlock]
        setUserIsReach(data).then(() => {
          this.$message({
            message: '設置成功',
            type: 'success'
          });
          this.init()
        })
      } else {
        if (this.selectData.length > 0) {
          this.selectData.map((v) => {
            data.push(v.lastBlock)
          })
          setUserIsReach(data).then(() => {
            this.$message({
              message: '設置成功',
              type: 'success'
            });
            this.init()
          })
        } else {
          this.$message({
            message: '請選擇地址',
            type: 'success'
          });
        }
      }

    },
    handleSizeChange (val) {
      console.log(`每页 ${val} 条`);
      let pageData = this.pageData
      pageData.pageNo = 1;
      pageData.pageSize = val
      this.pageData = pageData
      // this.dataSlice()
    },
    handleCurrentChange (val) {
      console.log(`当前页: ${val}`);
      let pageData = this.pageData
      pageData.pageNo = val;
      this.pageData = pageData
      // this.dataSlice()
    },
    tableRowClassName ({ rowIndex }) {
      if (rowIndex === 1) {
        return 'warning-row';
      } else if (rowIndex === 3) {
        return 'success-row';
      }
      return '';
    },
    init () {
      getUserByStatus([this.status]).then((res) => {
        this.tableDataItem = res
      })
    },
    onSubmit () {

    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.time {
  width: 100%;
  padding: 10px 0 0 20px;
  .block {
    margin: 20px 0 0 0;
  }
  .btn {
    margin: 0 0 0 20px;
  }
}
</style>
