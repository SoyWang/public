const FOMO_ADDRESS  ="0xe1588bC1FC877FfFbbde919Fa29F51c9c80e5571"
const FOMO_ABI =  [
	{
		"constant": true,
		"inputs": [],
		"name": "getBuyPrice",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "g1EndTime",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "name",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "address"
			}
		],
		"name": "pIDxAddr_",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "airDropTracker_",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getBalance",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getPeriod",
		"outputs": [
			{
				"name": "result",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_affCode",
				"type": "uint256"
			},
			{
				"name": "_team",
				"type": "uint256"
			},
			{
				"name": "_amount",
				"type": "uint256"
			},
			{
				"name": "_result",
				"type": "uint8"
			}
		],
		"name": "buyKey",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "Jekyll_Island_Inc",
		"outputs": [
			{
				"name": "",
				"type": "address"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"name": "round_",
		"outputs": [
			{
				"name": "plyr",
				"type": "uint256"
			},
			{
				"name": "team",
				"type": "uint256"
			},
			{
				"name": "end",
				"type": "uint256"
			},
			{
				"name": "ended",
				"type": "bool"
			},
			{
				"name": "strt",
				"type": "uint256"
			},
			{
				"name": "keys",
				"type": "uint256"
			},
			{
				"name": "eth",
				"type": "uint256"
			},
			{
				"name": "pot",
				"type": "uint256"
			},
			{
				"name": "mask",
				"type": "uint256"
			},
			{
				"name": "ico",
				"type": "uint256"
			},
			{
				"name": "icoGen",
				"type": "uint256"
			},
			{
				"name": "icoAvg",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "bytes32"
			}
		],
		"name": "plyrNames_",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"name": "fees_",
		"outputs": [
			{
				"name": "gen",
				"type": "uint256"
			},
			{
				"name": "p3d",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "gameover",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "bytes32"
			}
		],
		"name": "pIDxName_",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getCanRefundNum",
		"outputs": [
			{
				"name": "isRefund",
				"type": "bool"
			},
			{
				"name": "eth",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [],
		"name": "withdraw",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_affCode",
				"type": "uint256"
			},
			{
				"name": "_team",
				"type": "uint256"
			},
			{
				"name": "_eth",
				"type": "uint256"
			},
			{
				"name": "_result",
				"type": "uint8"
			}
		],
		"name": "reLoadXid",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getUserRecords",
		"outputs": [
			{
				"name": "",
				"type": "uint256[]"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "beforeG1KeyShareTimeSpan",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_pID",
				"type": "uint256"
			},
			{
				"name": "_addr",
				"type": "address"
			},
			{
				"name": "_name",
				"type": "bytes32"
			},
			{
				"name": "_laff",
				"type": "uint256"
			}
		],
		"name": "receivePlayerInfo",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_nameString",
				"type": "string"
			},
			{
				"name": "_affCode",
				"type": "address"
			},
			{
				"name": "_amount",
				"type": "uint256"
			},
			{
				"name": "_all",
				"type": "bool"
			}
		],
		"name": "registerNameXaddr",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "otherF3D_",
		"outputs": [
			{
				"name": "",
				"type": "address"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_playerBook",
				"type": "address"
			},
			{
				"name": "_reward",
				"type": "address"
			},
			{
				"name": "_gameMode",
				"type": "address"
			},
			{
				"name": "_bank",
				"type": "address"
			}
		],
		"name": "setup",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "gameMode",
		"outputs": [
			{
				"name": "",
				"type": "address"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			}
		],
		"name": "rndTmEth_",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "rID_",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "_pID",
				"type": "uint256"
			}
		],
		"name": "getPlayerVaults",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_nameString",
				"type": "string"
			},
			{
				"name": "_affCode",
				"type": "uint256"
			},
			{
				"name": "_amount",
				"type": "uint256"
			},
			{
				"name": "_all",
				"type": "bool"
			}
		],
		"name": "registerNameXID",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getCurrentRoundInfo",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "address"
			},
			{
				"name": "",
				"type": "bytes32"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "g1startTime",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "bank",
		"outputs": [
			{
				"name": "",
				"type": "address"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "swap",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_nameString",
				"type": "string"
			},
			{
				"name": "_affCode",
				"type": "bytes32"
			},
			{
				"name": "_amount",
				"type": "uint256"
			},
			{
				"name": "_all",
				"type": "bool"
			}
		],
		"name": "registerNameXname",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "owner",
		"outputs": [
			{
				"name": "",
				"type": "address"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_beforeG1KeyBuyTimeSpan",
				"type": "uint256"
			},
			{
				"name": "_beforeG1KeyShareTimeSpan",
				"type": "uint256"
			}
		],
		"name": "activate",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_pID",
				"type": "uint256"
			},
			{
				"name": "_name",
				"type": "bytes32"
			}
		],
		"name": "receivePlayerNameList",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "symbol",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_timestampA",
				"type": "uint256[]"
			},
			{
				"name": "_timestampB",
				"type": "uint256[]"
			},
			{
				"name": "_gameEnd",
				"type": "uint256"
			}
		],
		"name": "setGameResult",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "address"
			}
		],
		"name": "mapImport",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			}
		],
		"name": "plyrRnds_",
		"outputs": [
			{
				"name": "eth",
				"type": "uint256"
			},
			{
				"name": "keys",
				"type": "uint256"
			},
			{
				"name": "mask",
				"type": "uint256"
			},
			{
				"name": "ico",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_fee",
				"type": "uint256"
			}
		],
		"name": "setWithdrawFee",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"name": "potSplit_",
		"outputs": [
			{
				"name": "gen",
				"type": "uint256"
			},
			{
				"name": "p3d",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getTimeLeft",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "_rID",
				"type": "uint256"
			},
			{
				"name": "_eth",
				"type": "uint256"
			}
		],
		"name": "calcKeysReceived",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "_keys",
				"type": "uint256"
			}
		],
		"name": "iWantXKeys",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "activated_",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "Divies",
		"outputs": [
			{
				"name": "",
				"type": "address"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "airDropPot_",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"name": "plyr_",
		"outputs": [
			{
				"name": "addr",
				"type": "address"
			},
			{
				"name": "name",
				"type": "bytes32"
			},
			{
				"name": "win",
				"type": "uint256"
			},
			{
				"name": "gen",
				"type": "uint256"
			},
			{
				"name": "aff",
				"type": "uint256"
			},
			{
				"name": "lrnd",
				"type": "uint256"
			},
			{
				"name": "laff",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "withdrawFee",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [],
		"name": "refundKeys",
		"outputs": [
			{
				"name": "",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [],
		"name": "potSwap",
		"outputs": [],
		"payable": true,
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"name": "_addr",
				"type": "address"
			}
		],
		"name": "getPlayerInfoByAddress",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "bytes32"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			},
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_pot",
				"type": "address"
			},
			{
				"name": "_amount",
				"type": "uint256"
			}
		],
		"name": "swapPot",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_timestampA",
				"type": "uint256[]"
			},
			{
				"name": "_timestampB",
				"type": "uint256[]"
			},
			{
				"name": "_gameEnd",
				"type": "uint256"
			},
			{
				"name": "_champion",
				"type": "uint8"
			}
		],
		"name": "setChampion",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "beforeG1KeyBuyTimeSpan",
		"outputs": [
			{
				"name": "",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"name": "playerID",
				"type": "uint256"
			},
			{
				"indexed": true,
				"name": "playerAddress",
				"type": "address"
			},
			{
				"indexed": true,
				"name": "playerName",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"name": "isNewPlayer",
				"type": "bool"
			},
			{
				"indexed": false,
				"name": "affiliateID",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "affiliateAddress",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "affiliateName",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"name": "amountPaid",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "timeStamp",
				"type": "uint256"
			}
		],
		"name": "onNewName",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"name": "compressedData",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "compressedIDs",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "playerName",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"name": "playerAddress",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "ethIn",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "keysBought",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "winnerAddr",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "winnerName",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"name": "amountWon",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "newPot",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "P3DAmount",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "genAmount",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "potAmount",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "airDropPot",
				"type": "uint256"
			}
		],
		"name": "onEndTx",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"name": "playerID",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "playerAddress",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "playerName",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"name": "ethOut",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "timeStamp",
				"type": "uint256"
			}
		],
		"name": "onWithdraw",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"name": "playerAddress",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "playerName",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"name": "ethOut",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "compressedData",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "compressedIDs",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "winnerAddr",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "winnerName",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"name": "amountWon",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "newPot",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "P3DAmount",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "genAmount",
				"type": "uint256"
			}
		],
		"name": "onWithdrawAndDistribute",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"name": "playerAddress",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "playerName",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"name": "ethIn",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "compressedData",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "compressedIDs",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "winnerAddr",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "winnerName",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"name": "amountWon",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "newPot",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "P3DAmount",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "genAmount",
				"type": "uint256"
			}
		],
		"name": "onBuyAndDistribute",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"name": "playerAddress",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "playerName",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"name": "compressedData",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "compressedIDs",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "winnerAddr",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "winnerName",
				"type": "bytes32"
			},
			{
				"indexed": false,
				"name": "amountWon",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "newPot",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "P3DAmount",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "genAmount",
				"type": "uint256"
			}
		],
		"name": "onReLoadAndDistribute",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"name": "affiliateID",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "affiliateAddress",
				"type": "address"
			},
			{
				"indexed": false,
				"name": "affiliateName",
				"type": "bytes32"
			},
			{
				"indexed": true,
				"name": "roundID",
				"type": "uint256"
			},
			{
				"indexed": true,
				"name": "buyerID",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "amount",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "timeStamp",
				"type": "uint256"
			}
		],
		"name": "onAffiliatePayout",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"name": "roundID",
				"type": "uint256"
			},
			{
				"indexed": false,
				"name": "amountAddedToPot",
				"type": "uint256"
			}
		],
		"name": "onPotSwapDeposit",
		"type": "event"
	}
]
export{
	FOMO_ADDRESS,
	FOMO_ABI
}