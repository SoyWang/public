import { Toast } from 'vant';
 import Web3 from 'web3'
 import i18n from "../i18n/index";
 
 /**
  * 初始化web3客户端
  */
  const EmployeeWindow = window as any;
 let web3: any
 let currentAddress: string
 async function initWeb3() {
   if (EmployeeWindow.ethereum) {
     web3 = new Web3(EmployeeWindow.ethereum);
     try {
       currentAddress = await EmployeeWindow.ethereum.enable()
       web3.eth.defaultAccount = currentAddress[0]
       await switchChain()
     } catch (err) {
       Toast.fail(i18n.global.t("toast.connectFailText"));
     }
   } else {
    setTimeout(() => {
        Toast.fail(i18n.global.t("toast.installWalletText"));
    }, 0)
     web3 = new Web3('https://chainlist.org')
   }
 }
 initWeb3()
 
 
 /**
  * 自动添加或切换网络链
  * @returns 
  */
 async function switchChain() {
   if (EmployeeWindow.ethereum) {
     try {
       // 切换网络链
       await (EmployeeWindow.ethereum).request({
         method: 'wallet_switchEthereumChain',
         params: [{
           chainId: Web3.utils.numberToHex(108) // 目标链ID
         }]
       })
     } catch (e: any) {
       if (e.code === 4902) {
         try {
           // 添加网络链
           await (EmployeeWindow.ethereum).request({
             method: 'wallet_addEthereumChain',
             params: [{
               chainId: Web3.utils.numberToHex(108), // 目标链ID
               chainName: 'ThunderCore Mainnet',
               nativeCurrency: {
                 name: 'TST',
                 symbol: 'TST',
                 decimals: 18
               },
               rpcUrls: ['https://mainnet-rpc.thundercore.com'], // 节点
               blockExplorerUrls: ['https://viewblock.io/thundercore']
             }]
           })
         } catch (e) {
           Toast.fail(i18n.global.t("toast.addNetwordFailText"));
         }
       } else if (e.code === 4001) {
         Toast.fail(i18n.global.t("toast.switchNetwordFailText"));
       }
     }
   }
 }
 
 // 合约地址
 const usdtContractAddress = '0x4f3C8E20942461e2c3Bdd8311AC57B0c222f2b82'; 
 const kolpullContractAddress = '0x8234C141B82eE6229396248576C6341661d225D6'; 
 
 export default {
   web3,
   usdtContractAddress,
   kolpullContractAddress
 }