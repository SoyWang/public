<script setup lang="ts">
import i18n from "./i18n";
import usdtabi from "../src/web3js/abi/usdtabi.json";
import kolpullabi from "../src/web3js/abi/kolpullabi.json";
import { Toast } from "vant";
import { onMounted, ref, inject } from "vue";

const web3 = inject<any>("web3");
const BigNumber = inject<any>("BigNumber");
const usdtContractAddress = inject<any>("usdtContractAddress");
const kolpullContractAddress = inject<any>("kolpullContractAddress");

// 当前
const currentAccount = ref<String>("");

// 当前语言
const language = ref<string>();
if (i18n.global.locale == "en") {
  language.value = "English";
} else {
  language.value = "繁体中文";
}
// 语言类型
enum LanguageType {
  Zh = "zh",
  En = "en",
}

// 切换语言
function handleSwitchLanguage() {
  if (language.value == "English") {
    language.value = "繁体中文";
    i18n.global.locale = LanguageType.Zh;
    localStorage.setItem("locale", LanguageType.Zh);
  } else {
    language.value = "English";
    i18n.global.locale = LanguageType.En;
    localStorage.setItem("locale", LanguageType.En);
  }
}

// 连接钱包
async function handleConnectionWallet() {}

// 查询授权金额
async function fetchApproveMoney(): Promise<number> {
  let ethContract = new web3.eth.Contract(usdtabi, usdtContractAddress);
  let data = await ethContract.methods
    .allowance(currentAccount.value, kolpullContractAddress)
    .call();
  let money = Number(BigNumber(data).div(Math.pow(10, 6)).toString(10));
  return money;
}

// 申请授权金额
async function allowMoney(): Promise<boolean> {
  let loading = Toast.loading({
    message: i18n.global.t("toast.impowerLoadingText"),
    forbidClick: true,
    duration: 0,
    overlay: true,
  });
  try {
    let ethContract = new web3.eth.Contract(usdtabi, usdtContractAddress);
    let data = await ethContract.methods
      .approve(
        kolpullContractAddress,
        BigNumber(10000000000 * Math.pow(10, 6)).toString(10)
      )
      .send({ from: currentAccount.value });
    console.log(data);
    Toast.success(i18n.global.t("toast.impowerSuccessText"));
    return true;
    // 授权成功
  } catch (err) {
    // 授权失败
    console.log(err);
    Toast.fail(i18n.global.t("toast.impowerFailedText"));
    return false;
  } finally {
    // loading.clear();
  }
}

// 申请kol资格
async function handleApplication() {
  let money = await fetchApproveMoney();
  if (!money) {
    // 授权
    let result = await allowMoney();
    if (!result) return;
  }

  let loading = Toast.loading({
    message: i18n.global.t("toast.applicationLoadingText"),
    forbidClick: true,
    duration: 0,
    overlay: true,
  });
  // 申请
  try {
    let ethContract = new web3.eth.Contract(kolpullabi, kolpullContractAddress);
    let data = await ethContract.methods.deposit().send({
      from: currentAccount.value,
    });
    console.log(data);
    Toast.success(i18n.global.t("toast.applicationSuccessText"));
  } catch (err) {
    Toast.fail(i18n.global.t("toast.applicationFailedText"));
  } finally {
    // loading.clear();
  }
}

// 查询是否转正
async function handleFind() {
  let loading = Toast.loading({
    message: i18n.global.t("toast.queryLoadingText"),
    forbidClick: true,
    duration: 0,
    overlay: true,
  });
  let ethContract = new web3.eth.Contract(kolpullabi, kolpullContractAddress);
  let data = await ethContract.methods
    .getUserStatus(currentAccount.value)
    .call();
  if (data) {
    Toast.success(i18n.global.t("toast.queryPassText"));
  } else {
    Toast.fail(i18n.global.t("toast.queryRefuseText"));
  }
  // loading.clear();
}

// 退还押金
async function handleReturnCase() {
  let loading = Toast.loading({
    message: i18n.global.t("toast.returnLoadingText"),
    forbidClick: true,
    duration: 0,
    overlay: true,
  });
  try {
    let ethContract = new web3.eth.Contract(kolpullabi, kolpullContractAddress);
    let data = await ethContract.methods.refund().send({
      from: currentAccount.value,
    });
    // 退还成功
    console.log(data);
    Toast.success(i18n.global.t("toast.returnSuccessText"));
  } catch (err) {
    // 退还失败
    Toast.fail(i18n.global.t("toast.returnFailedText"));
    console.log(err);
  } finally {
    // loading.clear();
  }
}

// 提现
async function handlewithdrawal() {
  let loading = Toast.loading({
    message: i18n.global.t("toast.withdrawalLoadingText"),
    forbidClick: true,
    duration: 0,
    overlay: true,
  });
  try {
    let ethContract = new web3.eth.Contract(kolpullabi, kolpullContractAddress);
    let data = await ethContract.methods.withdraw().send({
      from: currentAccount.value,
    });
    // 提现成功
    console.log(data);
    Toast.success(i18n.global.t("toast.withdrawalSuccessText"));
  } catch (err) {
    // 提现失败
    Toast.fail(i18n.global.t("toast.withdrawalFailedText"));
  } finally {
    // loading.clear();
  }
}

onMounted(async () => {
  let account = await web3.eth.getCoinbase();
  currentAccount.value = account;
  // await allowMoney();
});
</script>

<template>
  <div class="home">
    <!-- 头部 -->
    <header class="header-container">
      <div class="menu">
        <img class="logo" src="./assets/logo-icon.png" alt="" />
        <div class="opt-btn">
          <p class="btn" @click="handleSwitchLanguage">
            {{ language }}
          </p>
          <!-- <p class="btn btn-active" @click="handleConnectionWallet">
            {{ $t("walletText") }}
          </p> -->
        </div>
      </div>
    </header>

    <div class="content">
      <!-- 申请规则 -->
      <div class="application-content">
        <p class="title">{{ $t("applicationRuleText") }}</p>
        <p class="text">{{ $t("applicationRuleText1") }}</p>
        <p class="text">{{ $t("applicationRuleText2") }}</p>
        <p class="text">{{ $t("applicationRuleText3") }}</p>
      </div>

      <!-- 操作按钮 -->
      <div class="operation-btn">
        <div class="btn" @click="handleApplication">
          {{ $t("btnGroupText1") }}
        </div>
        <div class="btn" @click="handleFind">{{ $t("btnGroupText2") }}</div>
        <div class="btn" @click="handleReturnCase">
          {{ $t("btnGroupText3") }}
        </div>
        <div class="btn" @click="handlewithdrawal">
          {{ $t("btnGroupText4") }}
        </div>
      </div>

      <!-- 用户指南 -->
      <a href="" class="user-guide"> {{ $t("userGuide") }}</a>

      <!-- 退还押金规则 -->
      <div class="application-content">
        <p class="title">{{ $t("returnRuleText") }}</p>
        <p class="text">{{ $t("returnRuleText1") }}</p>
        <p class="text">{{ $t("returnRuleText2") }}</p>
      </div>
    </div>
  </div>
</template>

<style lang="less" scoped>
.home {
  min-height: 100vh;
  width: 100%;
  height: auto;
  position: relative;
  background: #090909ce;

  // 头部
  .header-container {
    width: 100%;
    padding: 0 15px;
    background: #000000;
    // position: fixed;
    // top: 0;
    // left: 0;
    // z-index: 1;

    .menu {
      height: 60px;
      width: 100%;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;

      .logo {
        width: 40px;
        height: 40px;
      }

      .opt-btn {
        display: flex;
        flex-direction: row;
        align-items: center;

        .btn {
          margin-left: 10px;
          padding: 0 10px;
          height: 26px;
          line-height: 26px;
          text-align: center;
          border-radius: 20px;
          border: 1px solid rgba(255, 255, 255, 0.2);
          font-size: 15px;
          font-family: PingFang SC-Medium, PingFang SC, SourceHanSansCN-Normal;
          font-weight: 400;
          color: rgba(255, 255, 255, 0.7);
        }

        .btn-active {
          background: #363636;
        }
      }
    }
  }

  .content {
    // margin-top: 60px;
    padding-top: 15px;

    .application-content {
      margin: 0 15px;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 10px 9px;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.3);
      background: #272727;

      .title {
        margin-bottom: 10px;
        font-size: 16px;
        font-family: DM Sans-Regular, DM Sans;
        font-weight: 400;
        color: rgba(255, 255, 255, 0.9);
        line-height: 20px;
      }

      .text {
        font-size: 14px;
        font-family: DM Sans-Regular, DM Sans;
        font-weight: 400;
        color: rgba(255, 255, 255, 0.7);
        line-height: 20px;
        text-align: left;
      }
    }

    .operation-btn {
      margin: 40px 0;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-evenly;
      flex-wrap: wrap;

      .btn {
        min-width: 40%;
        margin-top: 10px;
        margin-bottom: 10px;
        height: 40px;
        line-height: 40px;
        text-align: center;
        background: #d23634;
        border-radius: 104px;
        font-size: 16px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: #ffffff;
      }
    }

    .user-guide {
      display: flex;
      width: 100%;
      padding-right: 30px;
      flex-direction: row;
      justify-content: right;
      margin-bottom: 15px;
      text-decoration-line: underline;
      color: rgb(0, 183, 255);
    }
  }
}
</style>
