import { createI18n } from 'vue-i18n';
import en from './locale/en.json'
import zh from './locale/zh.json'

// 获取缓存中的语言
const defaultLocale = localStorage.getItem('locale') || 'en'

const i18n = createI18n({
  // 默认语言
  locale: defaultLocale,
  // 关闭控制台警告
  silentFallbackWarn: true,
  // 设置语言环境
  messages: {
    'en': en,
    'zh': zh
  }
});

export default i18n;
