import { createApp } from 'vue'
import './assets/main.less'
import 'vant/lib/index.css';
import App from './App.vue'
import i18n from './i18n';
import BigNumber from 'bignumber.js';
import web3js from './web3js/index';

createApp(App)
.use(i18n)
.provide('BigNumber', BigNumber)
.provide('web3', web3js.web3)
.provide('usdtContractAddress', web3js.usdtContractAddress)
.provide('kolpullContractAddress', web3js.kolpullContractAddress)
.mount('#app')
