<template>
  <!-- 余额不足弹窗 -->
  <van-popup class="no-money-popup"
             v-model="show"
             :close-on-click-overlay="false"
             @click-overlay="handleClosePopup">
    <div class="no-money-content">
      <img @click="handleClosePopup"
           class="close-icon"
           src="../../assets/images/game/cup/close-cricle-icon.png"
           alt="" />
      <p class="message">Your balance is insufficient, please recharge in time!</p>
      <div class="recharge-btn"
           @click="$router.push('/game/cup/recharge')">Recharge</div>
    </div>
  </van-popup>
</template>

<script>
export default {
  props: {
    show: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {};
  },
  methods: {
    /**
     * 关闭弹窗
     */
    handleClosePopup() {
      this.$emit('close');
    },
  },
};
</script>

<style lang="scss" scoped>
.no-money-popup {
  // 余额不足弹窗
  width: 93%;
  background: #1b1b1b !important;
  border-radius: 7px;
  padding-bottom: 20px;

  .no-money-content {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    .close-icon {
      position: absolute;
      top: 10px;
      right: 12px;
      width: 24px;
      height: 24px;
    }

    .message {
      margin: 0 25px;
      margin-top: 46px;
      font-size: 14px;
      line-height: 16px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #ffffff;
      text-align: center;
    }

    .recharge-btn {
      margin-top: 20px;
      width: 180px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      background: #d23634;
      border-radius: 104px;
      font-size: 16px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #ffffff;
    }
  }
}
</style>