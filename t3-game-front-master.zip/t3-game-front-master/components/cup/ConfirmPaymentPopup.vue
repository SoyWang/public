<template>
  <!-- 确认支付弹窗 -->
  <van-popup
    class="custome-popup guse-payment-popup-container"
    v-model="show"
    :close-on-click-overlay="false"
    @click-overlay="$emit('close')"
  >
    <div class="popup-top">
      <p class="title">{{ $t("game.cup.index.title14") }}</p>
      <img
        @click="$emit('close')"
        class="close-icon"
        src="../../assets/images/game/cup/close-cricle-icon.png"
        alt=""
      />
    </div>
    <div class="popup-content">
      <div class="price-item">
        <p class="label">{{ $t("game.cup.index.title15") }}</p>
        <p class="number">{{ functionType }}</p>
      </div>
      <div class="price-item">
        <p class="label">{{ $t("game.cup.index.title16") }}</p>
        <p class="number">${{ balance }}</p>
      </div>
      <div class="price-item">
        <p class="label">{{ $t("game.cup.index.title17") }}</p>
        <p class="number">${{ price }}</p>
      </div>
      <div class="btn" @click="$emit('payment')">
        {{ $t("game.cup.index.title18") }}
      </div>
    </div>
  </van-popup>
</template>

<script>
export default {
  props: {
    show: {
      type: Boolean,
      default: false,
    },
    functionType: {
      type: String,
      default: "",
    },
    balance: {
      type: Number,
      default: 0,
    },
    price: {
      type: Number,
      default: 0,
    },
  },
  data() {
    return {};
  },
  methods: {},
};
</script>

<style lang="scss" scoped>
// 确认支付弹窗
.guse-payment-popup-container {
  width: 93%;
  background: #1b1b1b;
  border-radius: 7px;

  .popup-content {
    padding: 16px 35px 20px 35px;
    display: flex;
    flex-direction: column;

    .price-item {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;

      .label {
        font-size: 14px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: rgba(255, 255, 255, 0.8);
        line-height: 16px;
      }

      .number {
        font-size: 14px;
        font-family: DM Sans-Bold, DM Sans;
        font-weight: bold;
        color: #ffffff;
        line-height: 16px;
      }
    }

    .btn {
      margin: 0 auto;
      margin-top: 8px;
      width: 180px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      background: #d23634;
      border-radius: 104px;
      font-size: 16px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #ffffff;
    }
  }
}
</style>