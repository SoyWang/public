<template>
  <div
    :class="[
      'match-item-content',
      data.isStartMatch ? 'match-item-content-start' : '',
      data.isEnd && data.roundNumber == 2 ? 'match-item-content-finished' : '',
      data.collected ? 'match-item-content-collected' : '',
    ]"
    v-if="data.matchType == 1"
  >
    <div class="team-list">
      <div class="team-item">
        <div class="cover-box">
          <img class="cover" :src="data.teamCover1" alt="" />
          <!-- 比分 -->
          <p class="score" v-show="false">
            {{ data.temaScore1 }}
          </p>
        </div>
        <p class="name">{{ data.temaName1 }}</p>
      </div>
      <p class="tag">VS</p>
      <!-- 比分标志 -->
      <p class="tag" v-show="false">:</p>
      <div class="team-item">
        <div class="cover-box">
          <img class="cover" :src="data.teamCover2" alt="" />
          <!-- 比分 -->
          <p class="score" v-show="false">
            {{ data.temaScore2 }}
          </p>
        </div>
        <p class="name">{{ data.temaName2 }}</p>
      </div>
    </div>
    <div class="btn-group">
      <div class="btn" @click="$emit('handleClickPrice')">
        ${{ data.totalPool }}
      </div>
      <p class="opt-btn"></p>
    </div>
    <div class="btn-group">
      <!-- 已结束比赛 -->
      <div
        v-if="data.isEnd && data.roundNumber == 2"
        class="btn btn-red"
        @click="() => {}"
      >
        <span>Finished</span>
        <img
          class="icon"
          src="@/assets/images/game/cup/arrow-right-icon.png"
          alt=""
        />
      </div>
      <!-- 已开始比赛 -->
      <div v-else class="btn btn-red" @click="$emit('handleClickGuse')">
        <span>Guess now</span>
        <img
          class="icon"
          src="@/assets/images/game/cup/arrow-right-icon.png"
          alt=""
        />
      </div>

      <!-- 搜藏按钮 -->
      <img
        @click="$emit('hanleClickCollect')"
        class="opt-btn"
        :src="
          data.collected
            ? require('@/assets/images/game/cup/collected-btn-icon.png')
            : require('@/assets/images/game/cup/collect-btn-icon.png')
        "
        alt=""
      />
    </div>
    <!-- 第一轮图标 -->
    <img
      v-if="data.roundNumber == 1"
      class="order-icon"
      src="@/assets/images/game/cup/help1-icon.png"
      alt=""
    />
    <!-- 比赛开始图标 -->
    <img
      v-else-if="data.isStartMatch"
      class="order-icon"
      src="@/assets/images/game/cup/help4-icon.png"
      alt=""
    />
    <!-- 第二轮图标 -->
    <img
      v-else-if="data.roundNumber == 2"
      class="order-icon"
      src="@/assets/images/game/cup/help2-icon.png"
      alt=""
    />
    <!-- 比赛结束图标 -->
    <img
      v-else-if="data.isEnd && data.roundNumber == 1"
      class="order-icon"
      src="@/assets/images/game/cup/help5-icon.png"
      alt=""
    />
    <!-- 最新弹窗 -->
    <div v-if="false" class="message-popup">
      <div class="message-content">
        <img
          class="close-icon"
          src="@/assets/images/game/cup/close-cricle-icon.png"
          alt=""
        />
        <p class="text">New Earnings： +$100</p>
        <p class="text">Total Earnings：+$500</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    data: {
      type: Object,
      default: () => {},
    },
    index: {
      type: Number,
      default: 0,
    },
  },
  data() {
    return {};
  },
  created() {},
  mounted() {},
  methods: {},
};
</script>

<style lang="scss" scoped>
.match-item-content {
  width: 48.5%;
  height: 175px;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16px 12px;
  background: rgba(20, 20, 20, 0.8);
  border: 1px solid rgba(0, 0, 0, 0.85);
  border-top-color: rgba(0, 0, 0, 0.32);
  border-bottom-color: rgba(0, 0, 0, 0.76);
  border-radius: 10px;
  position: relative;
  overflow: hidden;
  margin-bottom: 10px;

  .team-list {
    width: 100%;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;

    .team-item {
      display: flex;
      flex-direction: column;
      align-items: center;

      .cover-box {
        width: 62px;
        height: 41px;
        position: relative;

        .cover {
          width: 100%;
          height: 100%;
          position: absolute;
          left: 0;
          top: 0;
          position: absolute;
        }

        .score {
          width: 100%;
          height: 100%;
          line-height: 41px;
          position: absolute;
          left: 0;
          top: 0;
          font-size: 20px;
          font-family: Neue Machina-Ultrabold, Neue Machina;
          font-weight: 800;
          color: rgba(255, 255, 255, 0.8);
          text-align: center;
          background: rgba(17, 17, 17, 0.7);
        }
      }

      .name {
        margin-top: 6px;
        width: 38px;
        font-size: 14px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: #ffffff;
      }
    }

    .tag {
      font-size: 16px;
      font-family: Neue Machina-Ultrabold, Neue Machina;
      font-weight: 800;
      color: rgba(255, 255, 255, 0.8);
      line-height: 8px;
      border-bottom: 4px solid #d23634;
    }
  }

  .btn-group {
    width: 100%;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    margin-top: 12px;

    .btn {
      height: 26px;
      margin-right: 6px;
      width: 100%;
      border-radius: 41px;
      opacity: 1;
      font-size: 14px;
      font-family: DM Sans-Regular, DM Sans;
      font-weight: 400;
      color: #ffffff;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      border: 1px solid #ffffff;

      .icon {
        margin-top: 2px;
        margin-left: 4px;
        width: 8px;
        height: 12px;
      }
    }

    .btn-red {
      color: #d23634;
      border: 1px solid #d23634;
    }

    .opt-btn {
      width: 20px;
      height: 20px;
    }
  }

  .order-icon {
    width: 27px;
    height: 29px;
    position: absolute;
    right: 0;
    top: 0;
  }

  // 消息弹框
  .message-popup {
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    position: absolute;
    top: 0;
    left: 0;

    .message-content {
      width: 100%;
      background: #000000;
      border-radius: 9px;
      border: 1px solid rgba(52, 52, 51, 0.8);
      padding: 6px;

      .close-icon {
        width: 20px;
        height: 20px;
        margin-left: 89%;
      }

      .text {
        padding: 0 4px;
        margin-bottom: 4px;
        font-size: 12px;
        font-family: DM Sans-Regular, DM Sans;
        font-weight: 400;
        color: #ffffff;
      }
    }
  }
}

.match-item-content-start {
  background: rgba(20, 20, 20, 0.8);
  border: 1px solid rgba(0, 0, 0, 0.85);
  border-top-color: rgba(0, 0, 0, 0.32);
  border-bottom-color: rgba(0, 0, 0, 0.76);
}

.match-item-content-finished {
  background: rgba(19, 34, 61, 0.7);
  border: 1px solid rgba(22, 76, 149, 0.85);
  border-top-color: rgba(22, 76, 149, 0.32);
  border-bottom-color: rgba(22, 76, 149, 0.32);
}

.match-item-content-collected {
  background: #2c0f0f;
  border: 1px solid rgba(210, 54, 52, 0.4);
  border-top-color: rgba(210, 54, 52, 0.31);
  border-bottom-color: rgba(210, 54, 52, 0.39);
}
</style>
