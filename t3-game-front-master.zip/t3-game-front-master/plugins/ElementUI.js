import Vue from 'vue'
import { Carousel, CarouselItem, Notification } from 'element-ui'
Vue.use(Carousel)
Vue.use(CarouselItem)
Vue.component(Notification)
Vue.prototype.$notification = Notification