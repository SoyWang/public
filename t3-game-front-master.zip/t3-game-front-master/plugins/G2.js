import Vue from 'vue'
let g2 = require("@antv/g2plot")
Vue.prototype.$g2 = g2