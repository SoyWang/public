import { Toast } from 'vant';
export default ({ app, $axios, redirect }) => {
    $axios.defaults.timeout = 15000 // 超时时间 单位是ms

    let loading;

    // 请求拦截
    $axios.onRequest(config => {
        // 开始加载动画
        loading = Toast.loading({
            message: app.i18n.tc('axios.loadingText'),
            forbidClick: true,
            duration: 0,
            overlay: true,
        });
        return config
    })

    // 响应拦截
    $axios.onResponse(response => {
        if (response.data.status == 0) {
            // 请求失败
            Toast.fial(app.i18n.tc('axios.requestFailText'));
        }
        // 关闭加载动画
        loading.clear();
        return response.data
    })

    // 错误拦截
    $axios.onError(error => {
        // 关闭加载动画
        loading.clear();
        console.log(error)
        Toast(error);
    })
}