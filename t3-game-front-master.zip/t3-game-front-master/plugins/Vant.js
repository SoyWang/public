import Vue from 'vue';
import { Toast, Notify, Dialog, Popup, Slider, Swipe, SwipeItem, Progress, DropdownMenu, DropdownItem, CountDown, Stepper, Search } from 'vant';

Vue.use(Toast);
Vue.use(Notify);
Vue.use(Dialog);
Vue.use(Popup);
Vue.use(Slider);
Vue.use(Swipe);
Vue.use(SwipeItem);
Vue.use(Progress);
Vue.use(DropdownMenu);
Vue.use(DropdownItem);
Vue.use(CountDown);
Vue.use(Stepper);
Vue.use(Search);