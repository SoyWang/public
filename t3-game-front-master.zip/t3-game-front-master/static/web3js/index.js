import { Toast } from 'vant';
import Vue from 'vue';
import Web3 from 'web3';
import BigNumber from 'bignumber.js'

export default ({ app }) => {
    let chainId; // 链id
    let chainName; // 链名称
    let symbol; // 链名称
    let rpcUrls; // rpc节点地址
    let blockExplorerUrls; // 区块浏览器地址

    if (window.location.pathname.startsWith('/game/cup')) {
        // tt测试网
        chainId = 18
        symbol = "TST"
        chainName = "Thundercore Testnet"
        rpcUrls = "https://testnet-rpc.thundercore.com"
        blockExplorerUrls = "https://explorer-testnet.thundercore.com"

    } else if (window.location.pathname.startsWith('/game/t3')) {
        // tt正式网
        chainId = 108
        symbol = "TT"
        chainName = "ThunderCore Mainnet"
        rpcUrls = "https://mainnet-rpc.thundercore.com"
        blockExplorerUrls = "https://viewblock.io/thundercore"
    }

    /**
     * 初始化web3客户端
     */
    let web3
    let currentAddress
    async function initWeb3() {
        if (window.ethereum) {
            web3 = new Web3(window.ethereum);
            try {
                currentAddress = await window.ethereum.enable()
                web3.eth.defaultAccount = currentAddress[0]
                await switchChain()
            } catch (err) {
                Toast.fail(app.i18n.tc('wallet.connectFailText'));
            }
        } else {
            setTimeout(() => {
                Toast.fail(app.i18n.tc('wallet.installWalletText'));
            }, 0)
            web3 = new Web3('https://mainnet-rpc.thundercore.com')
        }
    }

    /**
     * 自动添加或切换网络链
     * @returns 
     */
    async function switchChain() {
        if (window.ethereum) {
            try {
                // 切换网络链
                await (window.ethereum).request({
                    method: 'wallet_switchEthereumChain',
                    params: [{
                        chainId: Web3.utils.numberToHex(chainId) // 目标链ID
                    }]
                })
            } catch (e) {
                if (e.code === 4902) {
                    try {
                        // 添加网络链
                        await (window.ethereum).request({
                            method: 'wallet_addEthereumChain',
                            params: [{
                                chainId: Web3.utils.numberToHex(chainId), // 目标链ID
                                nativeCurrency: {
                                    name: symbol,
                                    symbol: symbol,
                                    decimals: 18
                                },
                                chainName, // 节点名称
                                rpcUrls: [rpcUrls], // 节点id
                                blockExplorerUrls: [blockExplorerUrls] // 区块链浏览器地址
                            }]
                        })
                    } catch (e) {
                        Toast.fail(app.i18n.tc('wallet.addNetworkFailText'));
                    }
                } else if (e.code === 4001) {
                    Toast.fail(app.i18n.tc('wallet.switchNetworkFailText'));
                }
            }
        }
    }
    initWeb3()

    Vue.prototype.$web3 = web3
    Vue.prototype.$BigNumber = BigNumber
    Vue.prototype.$chainId = chainId

    // t3相关地址
    Vue.prototype.$t3BaseURL = "http://13.214.197.21/api/" // t3后台接口地址
    Vue.prototype.$usdttokenabiAddress = '0xa793f79154df071326C7a7933632E64a662729Ae' // usdttokenabi合约地址
    Vue.prototype.$herotonkenabiAddress = '0x50bf5E96b4daF117dA313CF2b6d4916292Bfd4aE' // herotonkenabi合约地址
    Vue.prototype.$autoheroabiAddress = '0xCB2124E66a3a75677C62F9125Db1C2EA481AED32' // autoheroabi合约地址
    Vue.prototype.$herostorageabiAddress = '0x62010C8cbb61070E8cF242937Ed221343927fEc3' // herostorageabi合约地址
    Vue.prototype.$herobankabiAddress = '0xBE7e67E7178317d81a8D98955aaaC1f310E37195' // herobankabi合约地址


    // cup相关地址
    Vue.prototype.$cupBaseURL = "http://localhost:9999/" // cup后台接口地址
    Vue.prototype.$becomefriendsabiAddress = '0xdB1dFFB3e51Fd5259eECf1DDAffaAE36Ceb8A430' // becomefriendsabi合约地址
    Vue.prototype.$friendsrangeabiAddress = '0xF2D11163D653BE69439F1c651b21E62Cd53EeBEb' // friendsrangeabi合约地址
    Vue.prototype.$playerbookabiAddress = '0x44D5E156863B24E15eB7fc26fbbb533c3Ba07547' // playerbookabi合约地址
    Vue.prototype.$f3cashtokenabiAddress = '0x242e45E547AD14B8d24C416f0F0f82b473129260' // f3cashtokenabi合约地址
    Vue.prototype.$usdttokenTestabiAddress = '0x1425873dE73DEd4023Ed5BfCe0c6194a892Eab7d' // usdttokenTestabiAddress合约地址
    Vue.prototype.$bankabiAddress = '0x8234C141B82eE6229396248576C6341661d225D6' // bankabi合约地址
}