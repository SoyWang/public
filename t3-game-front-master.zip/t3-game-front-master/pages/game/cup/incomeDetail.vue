<template>
  <!-- 收益明细 -->
  <div class="income-detail">
    <!--余额 -->
    <div class="balance-container">
      <p class="light-cricle"></p>
      <div class="balance-content">
        <p class="title">{{ $t("game.t3.income.balanceText") }}</p>
        <div class="balance-box">
          <p class="number">999</p>
          <p class="unit">F3 Cash</p>
        </div>
        <div class="btn-group">
          <p class="btn btn-active" @click="$router.push('/game/cup/recharge')">
            {{ $t("game.cup.income.rechargeText") }}
          </p>
          <p class="btn" @click="$router.push('/game/cup/withdrawal')">
            {{ $t("game.cup.income.withdrawalText") }}
          </p>
        </div>
      </div>
    </div>

    <!-- 收益记录 -->
    <div class="income-record">
      <div class="table-header">
        <div class="label" @click="showIncomeTypeList = !showIncomeTypeList">
          <p>To the account</p>
          <img
            :class="['icon', showIncomeTypeList ? 'icon-active' : '']"
            src="@/assets/images/game/cup/drop-down-icon.png"
            alt=""
          />
        </div>
        <p class="label">Poundage</p>
        <p class="label">Match</p>
        <p class="label">Time</p>
        <div
          class="type-list"
          v-show="showIncomeTypeList"
          @click="showIncomeTypeList = false"
        >
          <div class="type-item" @click="selectedIncomeTypeIndex = 0">
            <p
              :class="[
                'text',
                selectedIncomeTypeIndex == 0 ? 'text-active' : '',
              ]"
            >
              Income
            </p>
            <img
              v-show="selectedIncomeTypeIndex == 0"
              class="icon"
              src="@/assets/images/game/cup/selected-success-icon.png"
              alt=""
            />
          </div>
          <div class="type-item" @click="selectedIncomeTypeIndex = 1">
            <p
              :class="[
                'text',
                selectedIncomeTypeIndex == 1 ? 'text-active' : '',
              ]"
            >
              Cost
            </p>
            <img
              v-show="selectedIncomeTypeIndex == 1"
              class="icon"
              src="@/assets/images/game/cup/selected-success-icon.png"
              alt=""
            />
          </div>
        </div>
      </div>
      <template v-if="recordList.length">
        <div class="table-row" v-for="(item, index) in 20" :key="index">
          <p>+{{ index }}</p>
          <p>—</p>
          <p>F3Cash</p>
          <p>2022.9.27 10:24</p>
        </div>
        <!-- 没有更多数据 -->
        <div class="none-more-data">
          {{ $t("game.cup.income.incomeDetail.noneMoreDataText") }}
        </div>
      </template>

      <!-- 没有数据 -->
      <template v-else>
        <div class="none-data">
          {{ $t("game.cup.income.incomeDetail.noneDataText") }}
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import herotonkenabi from "@/static/web3js/abi/t3/herotonkenabi.json";
import walletMxin from "@/pages/mixin/walletMxin";
export default {
  mixins: [walletMxin],
  layout: "cupGame",
  data() {
    return {
      showIncomeTypeList: false, // 是否希纳是收入类型
      selectedIncomeTypeIndex: 0, // 选中的收入类型
      balance: 0, // 当前账户余额
      selectType: 1, // 当前选中的记录类型（1:收入，2：支出）
      recordList: [], // 收入支出记录
    };
  },
  async created() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      // await this.watchAccountChange();
    }
  },
  watch: {
    // 监听记录类型变化
    selectType: {
      handler(value) {
        if (value == 1) {
          // 收入
          this.fetchIncomeRecord();
        } else {
          // 支出
          this.fetchDisbursementRecord();
        }
      },
    },
  },
  filters: {
    // 日期格式化
    dateFormat(dateStr) {
      let format = "YYYY.MM.DD HH:mm";
      const date = new Date(Number(dateStr) * 1000);
      // 位数不足两位时在前面补零
      const dateNumFun = (num) => String(num).padStart("0", 2);
      const config = {
        YYYY: date.getFullYear(),
        MM: dateNumFun(date.getMonth() + 1),
        DD: dateNumFun(date.getDate()),
        HH: dateNumFun(date.getHours()),
        mm: dateNumFun(date.getMinutes()),
      };
      for (const key in config) {
        format = format.replace(key, config[key]);
      }
      return format;
    },
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      await this.fetchUserCoin();
      await this.fetchIncomeRecord();
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 获取用户的代币
     */
    async fetchUserCoin() {
      let ethContract = new this.$web3.eth.Contract(
        herotonkenabi,
        this.$herotonkenabiAddress
      );
      let data = await ethContract.methods
        .balanceOf(this.currentAccount)
        .call();
      this.balance = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4)
        .toString(10);
      console.log("用户当前的T3T：", this.balance);
    },

    /**
     * 获取收入明细记录
     */
    async fetchIncomeRecord() {
      let data = await this.$axios.get(
        `${this.$cupBaseURL}deposit_records?address=${this.currentAccount}`
      );
      if (data.result) {
        data.result.sort((obj1, obj2) => {
          let timestamp1 = obj1.timestamp;
          let timestamp2 = obj2.timestamp;
          if (timestamp1 < timestamp2) {
            return 1;
          } else if (timestamp1 > timestamp2) {
            return -1;
          } else {
            return 0;
          }
        });
        this.recordList = data.result;
      } else {
        this.recordList = [];
      }
    },

    /**
     * 获取支出明细记录
     */
    async fetchDisbursementRecord() {
      let data = await this.$axios.get(
        `${this.$cupBaseURL}car_records?address=${this.currentAccount}`
      );
      if (data.result) {
        data.result.sort((obj1, obj2) => {
          let timestamp1 = obj1.timestamp;
          let timestamp2 = obj2.timestamp;
          if (timestamp1 < timestamp2) {
            return 1;
          } else if (timestamp1 > timestamp2) {
            return -1;
          } else {
            return 0;
          }
        });
        this.recordList = data.result;
      } else {
        this.recordList = [];
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.income-detail {
  width: 100%;
  position: relative;

  .balance-container {
    width: 100%;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    position: fixed;
    z-index: 1;
    padding-bottom: 20px;
    background-color: #030303;

    .light-cricle {
      width: 72px;
      height: 64px;
      background: rgba(210, 54, 52, 0.8);
      filter: blur(40px);
      position: absolute;
      left: -20px;
      top: 65%;
      z-index: 1;
    }
    .balance-content {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin: 30px 25px;
      border-radius: 4px;
      border: 1px solid rgba(255, 255, 255, 0.3);
      padding: 16px 20px 20px 20px;
      background: url("@/assets/images/game/cup/ball-bg.png") no-repeat;
      background-size: 41px 41px;
      background-position: 97% 10px;
      background-color: rgba(255, 255, 255, 0.05);

      .title {
        width: 60px;
        font-size: 16px;
        line-height: 10px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: #ffffff;
        border-bottom: 5px solid #d23634;
      }

      .balance-box {
        margin-top: 10px;
        display: flex;
        flex-direction: row;
        align-items: center;
        .number {
          margin-right: 7px;
          width: 78px;
          font-size: 42px;
          font-family: Faktum Test-Bold, Faktum Test;
          font-weight: bold;
          color: #ffffff;
          line-height: 44px;
        }

        .unit {
          font-size: 16px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #ffffff;
          line-height: 17px;
        }
      }

      .btn-group {
        margin-top: 20px;
        display: flex;
        flex-direction: row;
        align-items: center;

        .btn {
          width: 130px;
          height: 30px;
          line-height: 30px;
          text-align: center;
          border-radius: 104px;
          border: 1px solid #d23634;
          font-size: 14px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #d23634;

          &:nth-child(1) {
            margin-right: 18px;
          }
        }

        .btn-active {
          background: #d23634;
          border: none;
          color: #ffffff;
        }
      }
    }
  }

  .income-record {
    .table-header {
      top: 280px;
      padding: 0 15px;
      height: 44px;
      background: #1b1b1b;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      position: fixed;
      width: 100%;
      z-index: 1;
      border-top: 1px solid rgba(255, 255, 255, 0.2);

      .label {
        flex: 1;
        text-align: center;
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        color: #ffffff;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;

        .icon {
          margin-left: 2px;
          width: 10px;
          height: 10px;
        }

        .icon-active {
          transform: rotate(180deg);
        }

        &:nth-child(1) {
          width: 34%;
        }

        &:nth-child(2) {
          width: 18%;
        }

        &:nth-child(3) {
          width: 18%;
        }

        &:nth-child(4) {
          width: 30%;
        }
      }

      .type-list {
        position: absolute;
        left: 12px;
        top: 44px;
        background: #1b1b1b;
        width: 100px;
        display: flex;
        flex-direction: column;
        align-items: center;

        .type-item {
          width: 100%;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: space-between;
          height: 30px;
          line-height: 30px;
          border-bottom: 0.5px solid #6a6a6a;

          &:last-child {
            border-bottom: none;
          }

          .text {
            margin-left: 6px;
            height: 18px;
            font-size: 14px;
            font-family: DM Sans-Medium, DM Sans;
            font-weight: 500;
            color: #bbbbbb;
            line-height: 16px;
          }

          .text-active {
            color: #d23634;
          }

          .icon {
            margin-right: 6px;
            width: 14px;
            height: 14px;
          }
        }
      }
    }

    .table-row {
      margin: 0 15px;
      height: 50px;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);

      &:nth-child(2) {
        margin-top: 280px;
      }

      &:nth-last-child(2) {
        border-bottom: none;
      }

      p {
        flex: 1;
        text-align: center;
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        color: #ffffff;
        opacity: 0.5;

        &:nth-child(1) {
          width: 34%;
        }

        &:nth-child(2) {
          width: 18%;
        }

        &:nth-child(3) {
          width: 18%;
        }

        &:nth-child(4) {
          width: 30%;
        }
      }
    }

    .none-data,
    .none-more-data {
      line-height: 30px;
      padding-bottom: 15px;
      text-align: center;
      font-size: 14px;
      font-family: PingFang SC;
      font-weight: 400;
      color: rgba(142, 142, 142, 0.445);
    }

    .none-data {
      margin-top: 50px;
      line-height: 50px;
    }
  }
}
</style>