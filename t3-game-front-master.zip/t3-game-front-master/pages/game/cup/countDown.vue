<template>
  <div class="count-down">
    <!-- 光圈 -->
    <div class="light-cricle light-cricle-one"></div>
    <!-- 计时 -->
    <div class="time-container">
      <p class="desc">
        Focus on the biggest sporting event of the year——The World Cup
        championship, is coming soon.
      </p>
      <!-- 倒计时 -->
      <div class="count-up">
        <van-count-down
          :time="finalMatchObj.leftTime * 1000"
          format="DD:HH:mm:ss"
        >
          <template #default="timeData">
            <div class="time-list">
              <div class="time-item">
                <p class="label">DAYS</p>
                <p class="number">{{ timeData.days }}</p>
              </div>
              <p class="colon">:</p>
              <div class="time-item">
                <p class="label">HOUSE</p>
                <p class="number">{{ timeData.hours }}</p>
              </div>
              <p class="colon">:</p>
              <div class="time-item">
                <p class="label">MINUTES</p>
                <p class="number">{{ timeData.minutes }}</p>
              </div>
              <p class="colon">:</p>
              <div class="time-item">
                <p class="label">SECONDS</p>
                <p class="number">{{ timeData.seconds }}</p>
              </div>
            </div>
          </template>
        </van-count-down>
      </div>
    </div>
    <p class="guse-number">$ {{ finalMatchObj.totalPool }}</p>
    <div class="guse-btn" @click="handleGuess">Guess Now</div>
    <!-- 光圈 -->
    <div class="light-cricle light-cricle-two"></div>
  </div>
</template>
<script>
import walletMxin from "@/pages/mixin/walletMxin";
import fomoabi from "@/static/web3js/abi/cup/fomoabi.json";

import allMatchList from "./data/allMatchData";
export default {
  mixins: [walletMxin],
  layout: "cupGame",
  data() {
    return {
      finalMatchObj: {}, // 总决赛的数据
    };
  },
  async mounted() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      await this.watchAccountChange();
    }
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 获取数据
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      await this.fetchAllMatchList();
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 获取总决赛相关数据
     */
    async fetchAllMatchList() {
      // todo 发送请求获取所有比赛
      // let allMatchList = allMatchList;
      allMatchList.map(async (item) => {
        if (item.matchType == 2) {
          let ethContract = new this.$web3.eth.Contract(
            fomoabi,
            item.fomoAddress
          );

          // 获取比赛轮次
          let data = await ethContract.methods.rID_().call();
          item.roundNumber = Number(data);

          // 获取当前回合的剩余时间
          data = await ethContract.methods.getTimeLeft().call();
          item.leftTime = Number(data);

          // 获取预测相关的其他数据
          data = await ethContract.methods.round_(item.roundNumber).call();
          item.isEnd = data.ended;
          item.totalPool = Number(
            this.$BigNumber(data.pot)
              .div(Math.pow(10, 18))
              .toFixed(4)
              .toString(10)
          );
          this.finalMatchObj = item;
          console.log("总决赛数据：", this.finalMatchObj);
          return;
        }
      });
    },

    /**
     * 点击预测总决赛按钮
     */
    handleGuess() {
      // 跳转到首页并显示预测弹框
      this.$router.push("/game/cup/");
    },
  },
};
</script>

<style lang="scss" scoped>
.count-down {
  width: 100%;
  background-color: #030303;
  position: relative;

  // 光圈1
  .light-cricle {
    position: absolute;
    left: -20px;
    top: 80px;
    width: 62px;
    height: 54px;
    background: rgba(210, 54, 52, 0.8);
    filter: blur(48px);
  }

  // 光圈2
  .light-cricle-two {
    top: 520px;
  }

  // 倒计时
  .time-container {
    position: absolute;
    margin-top: 30px;
    left: 50%;
    transform: translateX(-50%);
    padding: 0 8px;
    padding-bottom: 40px;
    width: 95%;
    display: flex;
    flex-direction: column;
    align-items: center;
    background: rgba(20, 20, 20, 0.8);
    border-radius: 10px;
    border: 1px solid rgba(22, 76, 149, 0.85);
    border-top-color: rgba(22, 76, 149, 0.32);
    border-bottom-color: rgba(22, 76, 149, 0.32);

    .desc {
      margin-top: 20px;
      font-size: 14px;
      font-family: DM Sans-Regular, DM Sans;
      font-weight: 400;
      color: rgba(255, 255, 255, 0.8);
      line-height: 18px;
      text-align: center;
    }

    // 倒计时
    .count-up {
      margin-top: 40px;
      width: 100%;

      .time-list {
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-evenly;
        padding: 0 10px;

        .time-item {
          display: flex;
          flex-direction: column;
          align-items: center;

          .label {
            font-size: 12px;
            font-family: Faktum Test-Bold, Faktum Test;
            font-weight: bold;
            color: #ffffff;
          }

          .number {
            height: 80px;
            line-height: 80px;
            text-align: center;
            width: 52px;
            margin-top: 12px;
            font-size: 38px;
            font-family: Faktum Test-Bold, Faktum Test;
            font-weight: bold;
            color: #ffffff;
            background: url("@/assets/images/game/cup/time-bg.png") no-repeat;
            background-size: 100%;
          }
        }

        .colon {
          margin-top: 8%;
          font-size: 30px;
          font-family: Faktum Test-Bold, Faktum Test;
          font-weight: bold;
          color: #ffffff;
        }
      }
    }
  }

  // 竞猜
  .guse-number {
    position: absolute;
    margin-top: 330px;
    background: url("@/assets/images/game/cup/guse-bg.png") no-repeat;
    background-size: 100% 165px;
    width: 100%;
    height: 230px;
    font-size: 42px;
    font-family: Faktum Test-Bold, Faktum Test;
    font-weight: bold;
    color: #f1da8f;
    line-height: 195px;
    text-align: center;
    background-color: #030303;
  }
  .guse-btn {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    margin: 0 auto;
    margin-top: 485px;
    height: 50px;
    line-height: 50px;
    width: 160px;
    text-align: center;
    background: url("@/assets/images/game/cup/guse-btn-bg.png") no-repeat;
    background-size: 100% 100%;
    font-size: 18px;
    font-family: DM Sans-Medium, DM Sans;
    font-weight: 500;
    color: #ffffff;
  }
}
</style>
