<template>
  <div class="friends-circle">
    <!-- 添加朋友按钮 -->
    <div class="add-friends-container">
      <input
        class="input"
        v-model="userAddress"
        placeholder="user address"
        type="text"
      />
      <img
        class="icon"
        src="@/assets/images/game/cup/add-friends-icon.png"
        alt=""
        @click="handleAddFriends"
      />
    </div>

    <!-- 朋友列表 -->
    <div class="friends-list-container">
      <p class="title">My friends list</p>
      <div class="friends-list">
        <div
          class="friends-item"
          v-for="(item, index) in friendsList"
          :key="index"
        >
          <img
            class="avatar"
            src="@/assets/images/game/cup/friends-avatar-icon.png"
            alt=""
          />
          <p class="username">{{ item }}</p>
        </div>
      </div>
      <img
        class="more-btn"
        src="@/assets/images/game/cup/more-btn-icon.png"
        alt=""
      />
    </div>

    <!-- 朋友圈 -->
    <div class="friends-circle-container">
      <div class="group-btn">
        <p class="btn active-btn">My group</p>
        <p class="btn" @click="showCreateFirendsCirclePopup = true">
          Set up my group
        </p>
      </div>
      <div class="group-list">
        <div class="group-item" v-for="(item, index) in 1" :key="index">
          <p class="group-name">Group Name</p>
          <div class="friends-list">
            <img
              v-for="(item1, index1) in 12"
              :key="index1"
              class="avatar"
              :src="
                index1 == 0
                  ? require('@/assets/images/game/cup/own-friends-avatar-icon.png')
                  : require('@/assets/images/game/cup/other-friends-avatar-icon.png')
              "
              alt=""
            />
            <div
              class="empty-avatar"
              v-for="(item2, index2) in 6"
              :key="index2"
            ></div>
          </div>
        </div>
      </div>
    </div>

    <!-- 创建朋友圈弹框 -->
    <van-popup
      class="custome-popup create-friends-circle-popup-container"
      v-model="showCreateFirendsCirclePopup"
    >
      <div class="popup-top">
        <p class="title">Create</p>
        <img
          @click="showCreateFirendsCirclePopup = false"
          class="close-icon"
          src="@/assets/images/game/cup/close-cricle-icon.png"
          alt=""
        />
      </div>
      <div class="popup-content">
        <div class="text">Choose a name for your group</div>
        <input
          class="input"
          v-model="friendsCircleName"
          type="text"
          placeholder="Germany iron fans"
        />
        <div class="btn" @click="handleCreatFiendsCircle">Complete</div>
      </div>
    </van-popup>

    <!-- 朋友已经添加弹窗 -->
    <result-popup
      :show="addAlreadyAddFriendsPopup"
      type="failed"
      message="朋友已经添加"
      @close="addAlreadyAddFriendsPopup = false"
    ></result-popup>

    <!-- 添加朋友成功弹窗 -->
    <result-popup
      :show="showAddFriendsSuccessPopup"
      type="success"
      message="添加朋友成功"
      @close="showAddFriendsSuccessPopup = false"
    ></result-popup>

    <!-- 添加朋友失败弹窗 -->
    <result-popup
      :show="showAddFriendsFailedPopup"
      type="failed"
      message="添加朋友失败"
      @close="showAddFriendsFailedPopup = false"
    ></result-popup>

    <!-- 创建朋友圈成功弹窗 -->
    <result-popup
      :show="showCreateFriendsCircleSuccessPopup"
      type="success"
      message="创建朋友圈成功"
      @close="showCreateFriendsCircleSuccessPopup = false"
    ></result-popup>

    <!-- 创建朋友圈失败弹窗 -->
    <result-popup
      :show="showCreateFriendsCircleFailedPopup"
      type="failed"
      message="创建朋友圈失败"
      @close="showCreateFriendsCircleFailedPopup = false"
    ></result-popup>
  </div>
</template>

<script>
import ResultPopup from "@/components/cup/ResultPopup";
import walletMxin from "@/pages/mixin/walletMxin";
import becomefriendsabi from "@/static/web3js/abi/cup/becomefriendsabi.json";
import friendsrangeabi from "@/static/web3js/abi/cup/friendsrangeabi.json";
import fomoabi from "@/static/web3js/abi/cup/fomoabi.json";
export default {
  mixins: [walletMxin],
  layout: "cupGame",
  components: { ResultPopup },
  data() {
    return {
      userAddress: "", // 搜索的用户地址
      friendsCircleName: "", // 朋友圈名称
      showCreateFirendsCirclePopup: false, // 是否展示创建朋友圈弹窗
      addAlreadyAddFriendsPopup: false, // 朋友已经添加弹窗
      showAddFriendsSuccessPopup: false, // 是否展示添加朋友成功弹窗
      showAddFriendsFailedPopup: false, // 是否展示添加朋友失败弹窗
      showCreateFriendsCircleSuccessPopup: false, // 是否展示创建朋友圈成功弹窗
      showCreateFriendsCircleFailedPopup: false, // 是否展示创建朋友圈失败弹窗
      friendsList: [], // 朋友圈列表
    };
  },
  async mounted() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      await this.watchAccountChange();
    }
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 获取数据loading
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      // 获取请求数据
      await this.fetchFriendsList();
      await this.fetchFriendsCircleName();

      // 关闭加载动画
      loading.clear();
    },

    /**
     * 搜索框聚焦
     */
    handleFocus() {
      this.$refs.searchInput.focus();
    },

    /**
     * 获取朋友列表
     */
    async fetchFriendsList() {
      let ethContract = new this.$web3.eth.Contract(
        becomefriendsabi,
        this.$becomefriendsabiAddress
      );
      let data = await ethContract.methods
        .getfriends(this.currentAccount)
        .call();
      this.friendsList = data;
      console.log("朋友列表：", this.friendsList);
    },

    /**
     * 获取朋友圈名称
     */
    async fetchFriendsCircleName() {
      let ethContract = new this.$web3.eth.Contract(
        friendsrangeabi,
        this.$friendsrangeabiAddress
      );
      let data = await ethContract.methods.getGroupName().call();
      console.log("朋友圈名称：", data);
    },

    /**
     * 添加为朋友
     */
    async handleAddFriends() {
      // 判断是否添加了朋友
      let result = await this.verifySearchUser();
      if (result == null) return;

      let loading;
      if (!result) {
        // 加载数据loading
        loading = this.$toast.loading({
          message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
          forbidClick: true,
          duration: 0,
          overlay: true,
        });
        // 没有添加为朋友
        try {
          let ethContract = new this.$web3.eth.Contract(
            becomefriendsabi,
            this.$becomefriendsabiAddress
          );
          let data = await ethContract.methods
            .addfriends([this.userAddress])
            .send({ from: this.currentAccount });
          this.showAddFriendsSuccessPopup = true;
          // 获取朋友列表
          this.fetchFriendsList();
          console.log(data);
        } catch (err) {
          this.showAddFriendsFailedPopup = true;
        } finally {
          loading.close();
        }
      } else {
        // 朋友已经添加了
        this.addAlreadyAddFriendsPopup = true;
      }
    },

    /**
     * 判断用户是否已加为朋友
     */
    async verifySearchUser() {
      try {
        let ethContract = new this.$web3.eth.Contract(
          becomefriendsabi,
          this.$becomefriendsabiAddress
        );
        let data = await ethContract.methods
          .getIsFriend(this.currentAccount, this.userAddress)
          .call();
        console.log("是否加为朋友：", data);
        return data;
      } catch (err) {
        this.showAddFriendsFailedPopup = true;
        return null;
      }
    },

    /**
     * 创建朋友圈
     */
    async handleCreatFiendsCircle() {
      // 判断用户是否买key了
      let result = await this.verifyUserBuyKeys();
      if (result) {
        // 买了key，可以创建
        let loading;
        try {
          // 加载数据loading
          loading = this.$toast.loading({
            message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
            forbidClick: true,
            duration: 0,
            overlay: true,
          });

          let ethContract = new this.$web3.eth.Contract(
            friendsrangeabi,
            this.$friendsrangeabiAddress
          );

          let data = await ethContract.methods
            .BecomeGroupLeader(this.friendsCircleName)
            .send({ from: this.currentAccount });
          console.log("创建朋友圈：", data);
          this.showCreateFriendsCircleSuccessPopup = true;
        } catch (err) {
          this.showCreateFriendsCircleFailedPopup = true;
        } finally {
          this.showCreateFirendsCirclePopup = false;
          loading.close();
        }
      } else {
        // 创建失败
        this.showCreateFirendsCirclePopup = false;
        this.showCreateFriendsCircleFailedPopup = true;
      }
    },

    /**
     * 判断用户是否买key了
     */
    async verifyUserBuyKeys() {
      let ethContract = new this.$web3.eth.Contract(
        fomoabi,
        this.$fomoabiAddress
      );
      let data = await ethContract.methods
        .getPlayerInfoByAddress(this.currentAccount)
        .call();
      console.log("判断用户是否买key了：", data[2]);
      if (Number(data[2]) > 0) {
        return true;
      }
      return false;
    },
  },
};
</script>

<style lang="scss" scoped>
.friends-circle {
  // 添加朋友按钮
  .add-friends-container {
    margin: 0 12px;
    margin-top: 20px;
    height: 40px;
    border-radius: 58px;
    border: 1px solid #d23634;
    padding-left: 14px;
    padding-right: 10px;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;

    .input {
      width: 100%;
      border: none;
      height: 100%;
      background: transparent;
      font-size: 16px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #ffffff;
      padding-right: 10px;
    }

    .icon {
      width: 60px;
      height: 26px;
    }
  }

  // 朋友列表
  .friends-list-container {
    margin-top: 30px;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0 30px;

    .title {
      font-size: 16px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #ffffff;
      line-height: 8px;
      border-bottom: 5px solid #d23634;
    }

    .friends-list {
      margin-top: 20px;
      width: 100%;
      display: flex;
      flex-direction: column;
      .friends-item {
        height: 55px;
        display: flex;
        flex-direction: row;
        align-items: center;
        border-bottom: 1px solid rgba(255, 255, 255, 0.4);
        padding: 0 23px;

        &:last-child {
          border: none;
        }

        .avatar {
          margin-right: 10px;
          width: 40px;
          height: 40px;
        }

        .username {
          width: 100%;
          font-size: 16px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #ffffff;
          line-height: 19px;
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
        }
      }
    }

    .more-btn {
      margin-top: 10px;
      width: 20px;
      height: 20px;
    }
  }

  // 朋友圈
  .friends-circle-container {
    margin-top: 20px;
    width: 100%;
    display: flex;
    flex-direction: column;

    .group-btn {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      margin: 0 33px;

      .btn {
        height: 30px;
        line-height: 30px;
        text-align: center;
        border-radius: 104px;
        border: 1px solid #d23634;
        padding: 0 24px;
        font-size: 14px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: #d23634;
      }

      .active-btn {
        color: #ffffff;
        background: #d23634;
      }
    }

    .group-list {
      margin-top: 20px;
      display: flex;
      flex-direction: column;
      padding: 0 25px;

      .group-item {
        margin-bottom: 12px;
        display: flex;
        flex-direction: column;
        padding: 12px;
        background: rgba(255, 255, 255, 0.06);
        border-radius: 4px;
        border: 0.5px solid rgba(255, 255, 255, 0.4);

        .group-name {
          font-size: 14px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #ffffff;
        }

        .friends-list {
          margin-top: 5px;
          display: flex;
          flex-direction: row;
          flex-wrap: wrap;
          justify-content: space-between;

          .avatar {
            margin-top: 4px;
            width: 40px;
            height: 40px;
          }

          .empty-avatar {
            height: 0;
            width: 40px;
          }
        }
      }
    }
  }

  // 创建朋友圈弹窗
  .create-friends-circle-popup-container {
    .popup-content {
      width: 100%;
      padding: 10px 20px 30px 20px;
      display: flex;
      flex-direction: column;
      align-items: center;

      .text {
        width: 100%;
        font-size: 12px;
        font-family: DM Sans-Regular, DM Sans;
        font-weight: 400;
        color: #ffffff;
      }

      .input {
        width: 100%;
        margin-top: 8px;
        height: 30px;
        background: rgba(255, 255, 255, 0.4);
        border-radius: 43px;
        border: 1px solid rgba(255, 255, 255, 0.6);
        padding: 0 16px;
        font-size: 12px;
        font-family: DM Sans-Regular, DM Sans;
        font-weight: 400;
        color: #ffffff;
        outline: none;
      }

      input::-webkit-input-placeholder {
        color: rgba(255, 255, 255, 0.8);
      }

      .btn {
        margin-top: 30px;
        width: 180px;
        height: 30px;
        line-height: 30px;
        text-align: center;
        background: #d23634;
        border-radius: 104px;
        font-size: 16px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: #ffffff;
      }
    }
  }
}
</style>
