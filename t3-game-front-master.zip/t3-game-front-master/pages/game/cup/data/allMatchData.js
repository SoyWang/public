// 其他比赛
export default [{
        team1Logo: require('@/assets/images/game/cup/team1-img.png'), // 球队1图片
        team2Logo: require('@/assets/images/game/cup/team2-img.png'), // 球队2图片
        team1Score: 1, // 球队1分数
        team2Score: 2, // 球队2分数
        team1Name: "Qatar", // 球队1名称
        team2Name: "Ecuador", // 球队2名称
        collected: false, // 是否收藏
        fomoAddress: "0xf829B69440C1BeF1132d4910850ECA141f24Dc72", // fomo合约地址
        gameModelAddress: "0x38b129aB536CBAe158Fb030A9c39619305D981dD", // gameModel合约地址
        type: 1, // 预测类型 1 常规赛 2 总决赛
        matchStartTime: "2022-10-26 10:53:44", // 球赛开始时间
        isStartMatch: false,

        matchStage: 1, // 比赛阶段 1：蓝色 2：绿色 3：红色
        roundNumber: 1, // 比赛回合数
        leftTime: 0, // game1和game2预测剩余倒计时（时间戳秒）
        startTime: 0, // game1和game2预测开始时间（时间戳秒）
        endTime: 0, // game1和game2预测结束时间（时间戳秒）
        isEnd: false, // game1和game2是否结束
        totalKeys: 0, // 当前奖池的key的总数
        totalEth: 0, // 当前奖池的eth的总数
        totalPool: 0, // 总奖池
        airPotPollNumber: 0, // 空投池子数量
        airPotOdds: 0, // 空投概率
        stageLeftTimes: 0, // 阶段剩余时间（时间戳）
        userName: "0", // 用户名称
        userId: "0", // 用户的id
        userAddressShareUrl: "", // 用户地址分享
        userNameShareUrl: "", // 用户名称分享
        userIdShareUrl: "", // 用户id分享
        userCostKeys: 0, // 用户当前预测花费的keys
        userIncome: 0, // 用户当前通过分享的收益
        userCostEth: 0, // 用户当前花费的eth
        userReturnKeys: 0, // 用户可退f3chach
        userWinGains: 0, // 用户预估赢得钱
        userTimeGains: 0, // 用户实时分红
        userAffGains: 0, // 用户推荐分的钱
        totalGains: 0, // 用户预估赢得钱加上用户实时分红加上用户推荐分的钱总和
        campDataList: [] // 阵营总的eth
    },

]