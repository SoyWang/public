<template>
  <div class="cup">
    <!-- 顶部banner -->
    <div class="banner-container">
      <img
        class="light-circle-bg"
        src="@/assets/images/game/cup/light-circle-bg.png"
        alt=""
      />
      <div class="total-price" @click="$router.push('/game/cup/countDown')">
        $ 1,000,000
      </div>
      <div class="total-key" @click="$router.push('/game/cup/countDown')">
        9999
      </div>
      <div class="guse-btn" @click="handleShowFinalGusePopup">Guess Now</div>
    </div>

    <!-- 球赛区域 -->
    <div class="match-container">
      <!-- 背景图片 -->
      <img class="match-bg" src="@/assets/images/game/cup/match-bg.png" />
      <!-- 光圈 -->
      <img
        class="light-circle-bg"
        src="@/assets/images/game/cup/light-circle-bg.png"
        alt=""
      />
      <!-- 标题 -->
      <div class="title-box">
        <div class="title-text">
          <span class="title">Qatar World Cup</span>
          <img
            @click="showPrizePoolPathPopup = true"
            class="icon"
            src="@/assets/images/game/cup/trophy-icon.png"
            alt=""
          />
        </div>
        <div class="category-box">
          <div class="category-btn">
            <div
              :class="['btn', !isSelectedCollectionBtn ? 'active-btn' : '']"
              @click="isSelectedCollectionBtn = false"
            >
              Joined
            </div>
            <div
              :class="['btn', isSelectedCollectionBtn ? 'active-btn' : '']"
              @click="isSelectedCollectionBtn = true"
            >
              Followed
            </div>
          </div>
          <img
            class="question-icon"
            @click="showHelpPopup = !showHelpPopup"
            src="@/assets/images/game/cup/question-icon.png"
            alt=""
          />
        </div>
      </div>

      <!-- 球赛列表 -->
      <div class="match-list">
        <!-- 参加的比赛 -->
        <template v-if="!isSelectedCollectionBtn">
          <match-item
            v-for="(item, index) in joinedMatchList"
            :key="index + 10"
            :data="item"
            @handleClickPrice="handleShowMatchPopup(item, index)"
            @handleClickGuse="handleShowGusePopup(item, index)"
            @hanleClickCollect="hanldeCollectMatch(item, index, 1)"
          />
        </template>

        <!-- 收藏的比赛 -->
        <template v-else>
          <match-item
            v-for="(item, index) in collectedMatchList"
            :key="index + 100"
            :data="item"
            @handleClickPrice="handleShowMatchPopup(item, index)"
            @handleClickGuse="handleShowGusePopup(item, index)"
            @hanleClickCollect="hanldeCollectMatch(item, index, 2)"
          />
        </template>

        <!-- 更多比赛按钮 -->
        <div class="more-btn">
          <p class="text">More</p>
          <img
            class="icon"
            src="@/assets/images/game/cup/more-btn-icon.png"
            alt=""
          />
        </div>

        <!-- 其他比赛按钮 -->
        <p class="other-btn">Others</p>

        <!-- 其他的比赛 -->
        <match-item
          v-for="(item, index) in otherMatchList"
          :key="index + 1000"
          :data="item"
          @handleClickPrice="handleShowMatchPopup(item, index)"
          @handleClickGuse="handleShowGusePopup(item, index)"
          @hanleClickCollect="hanldeCollectMatch(item, index, 3)"
        />
      </div>
    </div>

    <!-- 奖品池流动路线弹框 -->
    <van-popup
      class="custome-popup prize-pool-pupop-container"
      v-model="showPrizePoolPathPopup"
    >
      <div class="popup-top">
        <p class="title">Cup prize pool flow route</p>
        <img
          @click="showPrizePoolPathPopup = false"
          class="close-icon"
          src="@/assets/images/game/cup/close-cricle-icon.png"
          alt=""
        />
      </div>
      <div class="popup-content">
        <p class="title">Group long</p>
        <div class="path-list">
          <div class="divider"></div>
          <div class="path-item">
            <div class="icon-box">
              <img
                class="icon"
                src="@/assets/images/game/cup/ball1-icon.png"
                alt=""
              />
            </div>
            <p class="text">Group</p>
          </div>
          <div class="path-item">
            <div class="icon-box">
              <img
                class="icon"
                src="@/assets/images/game/cup/ball2-icon.png"
                alt=""
              />
            </div>
            <p class="text">1/8</p>
            <p class="text">knockout</p>
          </div>
          <div class="path-item">
            <div class="icon-box">
              <img
                class="icon"
                src="@/assets/images/game/cup/ball3-icon.png"
                alt=""
              />
            </div>
            <p class="text">1/4</p>
            <p class="text">knockout</p>
          </div>
          <div class="path-item">
            <div class="icon-box">
              <img
                class="icon"
                src="@/assets/images/game/cup/ball4-icon.png"
                alt=""
              />
            </div>
            <p class="text">1/2</p>
            <p class="text">knockout</p>
          </div>
          <div class="path-item">
            <div class="icon-box">
              <img
                class="icon"
                src="@/assets/images/game/cup/trophy-active-icon.png"
                alt=""
              />
            </div>
            <p class="text">Final</p>
          </div>
        </div>
        <p class="title">Group long</p>
        <div class="path-list path-list2">
          <div class="divider"></div>
          <div class="path-item">
            <div class="icon-box">
              <img
                class="icon"
                src="@/assets/images/game/cup/trophy-icon.png"
                alt=""
              />
            </div>
            <p class="text">Cup Long</p>
            <p class="text">Start</p>
          </div>
          <div class="path-item">
            <div class="icon-box">
              <img
                class="icon"
                src="@/assets/images/game/cup/trophy-active-icon.png"
                alt=""
              />
            </div>
            <p class="text">Cup Long</p>
            <p class="text">finish</p>
          </div>
        </div>
        <p class="title">Group long:</p>
        <p class="desc">
          Multiple rounds, prize pool with the passage of the race, each game
          can be predicted results.
        </p>
        <p class="title">Group long:</p>
        <p class="desc">
          The grand prize pool throughout the World Cup, predicting the winning
          team.
        </p>
      </div>
    </van-popup>

    <!-- 帮助弹框 -->
    <van-popup
      class="custome-popup help-pupop-container"
      v-model="showHelpPopup"
    >
      <div class="popup-top">
        <p class="title">Help</p>
        <img
          @click="showHelpPopup = false"
          class="close-icon"
          src="@/assets/images/game/cup/close-cricle-icon.png"
          alt=""
        />
      </div>
      <div class="popup-content">
        <div class="icon-introduce">
          <p class="title">Icon</p>
          <div class="icon-list">
            <div class="icon-item" v-for="(item, index) in 5" :key="index">
              <img
                class="icon"
                :src="
                  require(`@/assets/images/game/cup/help${index + 1}-icon.png`)
                "
                alt=""
              />
              <p class="text">followed not start</p>
            </div>
          </div>
        </div>
        <p class="tips">
          Click on this area to view the detailed event information about the
          match；
        </p>
        <img
          class="help1-img"
          src="@/assets/images/game/cup/help1-img.png"
          alt=""
        />
        <p class="tips">
          When this prompt appears, click on this area to see a breakdown of
          your earnings for that match
        </p>
        <img
          class="help2-img"
          src="@/assets/images/game/cup/help2-img.png"
          alt=""
        />
        <p class="tips">
          The background colors represent the four stages of the round:
        </p>
        <p class="description description1">
          Blue: "Players can buy the key or choose to return the purchased key.
          All the input has not entered the prize pool, and the cost of
          returning the key shall be borne by themselves";
        </p>
        <p class="description description2">
          Green: "Players are not allowed to buy keys and cannot return
          purchased keys. Real-time bonus will be paid to all purchased keys and
          all inputs have entered the prize pool";
        </p>
        <p class="description description3">
          Red: "The game officially starts, open purchase key and can not be
          returned, you will get instant bonus until the end of the game";
        </p>
        <p class="description description4">
          Black: The "game is not started" phase.
        </p>
      </div>
    </van-popup>

    <!-- 暂未开放预测弹框 -->
    <van-popup
      class="no-open-guse-popup-container"
      v-model="showNoOpenGusePopup"
    >
      <div class="no-open-popup-content">
        <img
          @click="showNoOpenGusePopup = false"
          class="close-icon"
          src="@/assets/images/game/cup/close-cricle-icon.png"
          alt=""
        />
        <div class="message-box">
          <img
            class="icon"
            src="@/assets/images/game/cup/no-open-icon.png"
            alt=""
          />
          <p class="message">Coming soon......</p>
        </div>
      </div>
    </van-popup>

    <!-- 结束预测弹框 -->
    <van-popup class="end-guse-popup-container" v-model="showEndGusePopup">
      <div class="no-open-popup-content">
        <img
          @click="showEndGusePopup = false"
          class="close-icon"
          src="@/assets/images/game/cup/close-cricle-icon.png"
          alt=""
        />
        <div class="message-box">
          <img
            class="icon"
            src="@/assets/images/game/cup/no-open-icon.png"
            alt=""
          />
          <p class="message">The game is over</p>
        </div>
      </div>
    </van-popup>

    <!-- 赛程基本情况弹框 -->
    <van-popup
      class="custome-popup match-popup-container"
      v-model="showMatchPopup"
    >
      <div class="popup-top">
        <p class="title">The competition</p>
        <img
          @click="showMatchPopup = false"
          class="close-icon"
          src="@/assets/images/game/cup/close-cricle-icon.png"
          alt=""
        />
      </div>
      <div class="popup-content">
        <div class="btn-group">
          <div
            :class="['btn', !showTeamMatchPopup ? 'btn-active' : '']"
            @click="showTeamMatchPopup = false"
          >
            Round
          </div>
          <div
            :class="['btn', showTeamMatchPopup ? 'btn-active' : '']"
            @click="showTeamMatchPopup = true"
          >
            Team
          </div>
        </div>
        <!-- 基本情况 -->
        <div v-if="!showTeamMatchPopup" class="match-content">
          <p class="title">Countdown</p>
          <van-count-down
            class="time"
            :time="selectedMatchObj.leftTime * 1000"
          />
          <div class="data-list">
            <div class="data-item">
              <p class="text">Active Pot</p>
              <p class="number">${{ selectedMatchObj.totalPool }}</p>
            </div>
            <div class="data-item">
              <p class="text">Your Keys</p>
              <p class="number">{{ selectedMatchObj.userCostKeys }} Keys</p>
            </div>
            <div class="data-item">
              <p class="text">Total keys</p>
              <p class="number">{{ selectedMatchObj.totalKeys }} Keys</p>
            </div>
            <div class="data-item">
              <p class="text">Your Earnings</p>
              <p class="number">${{ selectedMatchObj.userIncome }}</p>
            </div>
          </div>
        </div>
        <!-- 团队情况 -->
        <div v-else class="match-content">
          <div class="team-list">
            <div
              class="team-item"
              v-for="(item, index) in selectedMatchObj.campDataList"
              :key="index"
            >
              <img
                class="team-icon"
                :src="
                  require(`@/assets/images/game/cup/camp${index + 1}-img.png`)
                "
                alt=""
              />
              <p class="price">${{ item.totalEth }}</p>
            </div>
          </div>
        </div>
      </div>
    </van-popup>

    <!-- 预测弹框 -->
    <van-popup
      class="custome-popup guse-popup-container"
      @click="showDropDownTeam = false"
      @closed="handleCloseGusePopup"
      v-model="showGusePopup"
    >
      <div class="popup-top">
        <p class="title">Select a forecast result</p>
        <img
          @click="handleCloseGusePopup"
          class="close-icon"
          src="@/assets/images/game/cup/close-cricle-icon.png"
          alt=""
        />
      </div>
      <div class="popup-content">
        <!-- 普通预测 -->
        <div class="select-result" v-if="selectedMatchObj.matchType == 1">
          <div class="team-box">
            <div class="team-item">
              <img
                class="cover"
                src="@/assets/images/game/cup/team1-img.png"
                alt=""
              />
              <p class="name">Qatar</p>
            </div>
            <p class="tag">VS</p>
            <div class="team-item">
              <img
                class="cover"
                src="@/assets/images/game/cup/team2-img.png"
                alt=""
              />
              <p class="name">Ecuador</p>
            </div>
          </div>
          <div class="result-btn-group">
            <div
              :class="['btn', guseData.result == index + 1 ? 'btn-active' : '']"
              @click="guseData.result = index + 1"
              v-for="(item, index) in guseResultBtnList"
              :key="index"
            >
              {{ item }}
            </div>
          </div>
        </div>
        <!-- 总决赛预测 -->
        <div class="select-final-result" v-else>
          <p class="title">The World Cup champions</p>
          <div class="country-box">
            <img class="cover" :src="guseData.cover" alt="" />
            <div class="select-country">
              <div
                class="value-box"
                @click.stop="showDropDownTeam = !showDropDownTeam"
              >
                <p class="value">{{ guseData.name }}</p>
                <img
                  class="icon"
                  :src="
                    showDropDownTeam
                      ? require('@/assets/images/game/cup/pull-down-top-icon.png')
                      : require('@/assets/images/game/cup/pull-down-bottom-icon.png')
                  "
                  alt=""
                />
              </div>
              <div class="option-list" v-show="showDropDownTeam">
                <p
                  :class="[
                    'option-item',
                    guseData.result == index + 1 &&
                    guseData.name != 'Choose a team'
                      ? 'selected-option'
                      : '',
                  ]"
                  v-for="(item, index) in allTeamList"
                  :key="index"
                  @click="handleSelectTeam(item, index + 1)"
                >
                  {{ item.team }}
                </p>
              </div>
            </div>
          </div>
        </div>
        <!-- 选择key的数量 -->
        <div class="select-money">
          <p class="desc">
            Purchases of X F3Cash or more have a Y% chance to win some of the Z
            F3Cash airdrop pot, instantly!
          </p>
          <p class="tips">Select the number of keys</p>
          <div class="stepper-box">
            <img
              @click="handleOperationGuseKeyNumber(-1)"
              class="btn-icon"
              src="@/assets/images/game/cup/subt-btn-bg.png"
              alt=""
            />
            <p class="number">{{ guseData.keys }}</p>
            <img
              @click="handleOperationGuseKeyNumber(1)"
              class="btn-icon"
              src="@/assets/images/game/cup/add-btn-bg.png"
              alt=""
            />
          </div>
          <p class="tips">Unit price: {{ guseData.keysTotalPrice }}</p>
        </div>
        <!-- 余额 -->
        <div
          :class="[
            'drop-down',
            'value-drop-down',
            showDropDownOne ? 'drop-down-open' : '',
          ]"
        >
          <div
            class="drop-down-title"
            @click="showDropDownOne = !showDropDownOne"
          >
            <p class="title">Vault</p>
            <img
              class="icon"
              src="@/assets/images/game/cup/arrow-top-icon.png"
              alt=""
            />
          </div>
          <div v-show="showDropDownOne" class="drop-down-content">
            <div class="value-item">
              <p class="text">At Exit(estimated)</p>
              <p class="value">${{ selectedMatchObj.userWinGains }}</p>
            </div>
            <div class="value-item">
              <p class="text">Exit Scammed</p>
              <p class="value">${{ selectedMatchObj.userTimeGains }}</p>
            </div>
            <div class="value-item">
              <p class="text">Bad Advice</p>
              <p class="value">${{ selectedMatchObj.userAffGains }}</p>
            </div>
            <div class="value-item">
              <p class="text">Total Gains</p>
              <p class="value">${{ selectedMatchObj.totalGains }}</p>
            </div>
            <div class="btn" @click="$router.push('/game/cup/withdrawal')">
              Withdrawal
            </div>
          </div>
        </div>
        <!-- 地址 -->
        <div
          :class="[
            'drop-down',
            'address-drop-down',
            showDropDownTwo ? 'drop-down-open' : '',
          ]"
        >
          <div
            class="drop-down-title"
            @click="showDropDownTwo = !showDropDownTwo"
          >
            <p class="title">Referral</p>
            <img
              class="icon"
              src="@/assets/images/game/cup/arrow-top-icon.png"
              alt=""
            />
          </div>
          <div v-show="showDropDownTwo" class="drop-down-content">
            <p class="title">
              Advise others to invest in this game and we'll reward you 10% of
              everything they lose.
            </p>
            <!-- 钱包分享地址 -->
            <div class="address-item">
              <p class="label">Wallet Referral</p>
              <div class="address-box">
                <p class="address">
                  {{ selectedMatchObj.userAddressShareUrl }}
                </p>
                <img
                  @click="
                    handleCopyInvitLink(selectedMatchObj.userAddressShareUrl)
                  "
                  class="icon"
                  src="@/assets/images/game/cup/copy-icon.png"
                  alt=""
                />
              </div>
            </div>
            <!-- 名称分享地址 -->
            <div class="address-item">
              <p class="label">Anonymous Referral</p>
              <div class="address-box">
                <p class="address">{{ selectedMatchObj.userNameShareUrl }}</p>
                <img
                  @click="
                    handleCopyInvitLink(selectedMatchObj.userNameShareUrl)
                  "
                  class="icon"
                  src="@/assets/images/game/cup/copy-icon.png"
                  alt=""
                />
              </div>
            </div>
            <!-- id分享地址 -->
            <div class="address-item">
              <p class="label">Vanity Referral</p>
              <div class="address-box">
                <p class="address">{{ selectedMatchObj.userIdShareUrl }}</p>
                <img
                  @click="handleCopyInvitLink(selectedMatchObj.userIdShareUrl)"
                  class="icon"
                  src="@/assets/images/game/cup/copy-icon.png"
                  alt=""
                />
              </div>
            </div>
            <div class="btn" @click="$router.push('/game/cup/register')">
              Register a new name
            </div>
          </div>
        </div>
        <!-- 折线图 -->
        <div
          :class="[
            'drop-down',
            'echart-drop-down',
            showDropDownThere ? 'drop-down-open' : '',
          ]"
        >
          <div
            class="drop-down-title"
            @click="showDropDownThere = !showDropDownThere"
          >
            <p class="title">Key price curve</p>
            <img
              class="icon"
              src="@/assets/images/game/cup/arrow-top-icon.png"
              alt=""
            />
          </div>
          <div v-show="showDropDownThere" class="drop-down-content">
            <!-- 图表 -->
            <div ref="myChart" id="my-chart"></div>
          </div>
        </div>
        <div class="btn" @click="showGuseTeamPopup = true">Next</div>
      </div>
    </van-popup>

    <!-- 预测阵营弹框 -->
    <van-popup
      class="custome-popup camp-popup-container"
      v-model="showGuseTeamPopup"
    >
      <div class="popup-top">
        <p class="title">Choose a Team</p>
        <img
          @click="showGuseTeamPopup = false"
          class="close-icon"
          src="@/assets/images/game/cup/close-cricle-icon.png"
          alt=""
        />
      </div>
      <div class="popup-content">
        <div class="camp-list">
          <div
            :class="[
              'camp-item',
              guseData.team == index ? 'camp-item-selected' : '',
            ]"
            v-for="(item, index) in 4"
            :key="index"
            @click="guseData.team = index"
          >
            <img
              class="cmap-icon"
              :src="
                require(`@/assets/images/game/cup/camp${index + 1}-img.png`)
              "
              alt=""
            />
            <p class="cmap-price">$999</p>
            <img
              v-show="guseData.team == index"
              class="selected-icon"
              src="@/assets/images/game/cup/selected-icon.png"
              alt=""
            />
          </div>
        </div>
        <div class="btn" @click="showGusePaymentPopup = true">Submit</div>
      </div>
    </van-popup>

    <!-- 预测支付弹窗 -->
    <confirm-payment-popup
      :show="showGusePaymentPopup"
      functionType="Guse fee"
      :balance="userBalance"
      :price="guseData.keysTotalPrice"
      @close="showGusePaymentPopup = false"
      @payment="handlePaymentGuse"
    ></confirm-payment-popup>

    <!-- 预测成功弹窗 -->
    <result-popup
      :show="showGuseSuccessPopup"
      type="success"
      message="预测成功"
      @close="showGuseSuccessPopup = false"
    ></result-popup>

    <!-- 预测失败弹窗 -->
    <result-popup
      :show="showGuseFailedPopup"
      type="failed"
      message="预测失败"
      @close="showGuseFailedPopup = false"
    ></result-popup>

    <!-- 余额不足弹窗 -->
    <no-money-popup
      :show="showNoMoneyPopup"
      @close="showNoMoneyPopup = false"
    ></no-money-popup>
  </div>
</template>
<script>
import MatchItem from "@/components/cup/MatchItem";
import ConfirmPaymentPopup from "@/components/cup/ConfirmPaymentPopup";
import ResultPopup from "@/components/cup/ResultPopup";
import NoMoneyPopup from "@/components/cup/NoMoneyPopup";
import walletMxin from "@/pages/mixin/walletMxin";
import fomoabi from "@/static/web3js/abi/cup/fomoabi.json";

import allMatchList from "./data/allMatchData";
export default {
  mixins: [walletMxin],
  layout: "cupGameIndex",
  components: { MatchItem, ConfirmPaymentPopup, ResultPopup, NoMoneyPopup },
  data() {
    return {
      isSelectedCollectionBtn: false, // 是否选中了收藏按钮
      showPrizePoolPathPopup: false, // 是否展示奖品池路线弹框
      showHelpPopup: false, // 是否展示帮助弹框
      showNoOpenGusePopup: false, // 是否展示暂未开放预测弹框
      showEndGusePopup: false, // 是否展示预测结束弹框
      showMatchPopup: false, // 是否展示比赛情况弹框
      showTeamMatchPopup: false, // 是否展示团队比赛情况
      showGusePopup: false, // 是否展示预测弹框
      showGuseTeamPopup: false, // 是否展示预测阵营弹框
      showGusePaymentPopup: false, // 是否显示预测支付弹窗
      showGuseSuccessPopup: false, // 是否展示预测成功弹窗
      showGuseFailedPopup: false, // 是否展示预测失败弹窗
      showNoMoneyPopup: false, // 是否展示余额不足弹窗
      showDropDownTeam: false, // 是否显示选择球队下拉框
      showDropDownOne: false, // 是否显示下拉框1
      showDropDownTwo: false, // 是否显示下拉框2
      showDropDownThere: false, // 是否显示下拉框3
      guseResultBtnList: ["Qatar Win", "Ecuador Win", "Comments"], // 预测结果按钮
      joinedMatchList: [], // 加入比赛列表
      collectedMatchList: [], // 收藏比赛列表
      otherMatchList: [], // 其他比赛列表
      allMatchList: [], // 总共比赛列表
      allTeamList: [], // 总共球队列表
      selectedMatchIndex: 0, // 选中比赛的索引
      selectedMatchObj: {}, // 选中比赛的数据
      userBalance: 0, // 用户余额
      shareInfo: {
        type: 3, // 分享的类型 1 地址分享链接；2 昵称分享链接；3 id分享链接
        address: "", // 上级分享的地址
      }, // 分享信息
      guseData: {
        name: "Choose a team", // 选中的球队名称
        cover: require("@/assets/images/game/cup/unkown-team-img.png"), // 选中的球队封面
        result: 1, // 选择的比赛结果, 1 胜；2 负；3平
        keys: 1, // 选择的key的数量
        team: 0, // 选中的阵营索引
        keysTotalPrice: 0, // 选中keys的总价
      }, // 预测数据
    };
  },
  async created() {
    // 获取分享信息
    if (this.$route.query.type && this.$route.query.address) {
      this.shareInfo.type = Number(this.$route.query.type);
      this.shareInfo.address = this.$route.query.address;
    }
  },
  async mounted() {
    // 获取比赛数据
    await this.fetchAllMatchList();

    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      await this.watchAccountChange();
    }
  },
  watch: {
    // 监听keys的变化
    "guseData.keys": {
      handler() {
        this.fetchKeysTotalPrice();
      },
    },
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 获取数据
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      // 获取请求数据
      await this.fetchUserBalance();
      await this.fetchAllMatchOtherInfo();
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 选择队伍
     */
    handleSelectTeam(item, index) {
      this.guseData.result = index;
      this.guseData.name = item.team;
      this.guseData.cover = item.teamCover;
      this.showDropDownTeam = false;
    },

    /**
     * 操作预测的key数量
     */
    handleOperationGuseKeyNumber(value) {
      if (value < 0) {
        if (this.guseData.keys != 1) {
          this.guseData.keys += value;
        } else {
          this.guseData.keys = 1;
        }
      } else {
        this.guseData.keys += value;
      }
    },

    /**
     * 赛程基本情况弹框
     */
    async handleShowMatchPopup(match, index) {
      // await this.fetchMatchOtherInfo(match, index);
      this.selectedMatchObj = this.allMatchList[index];
      this.showMatchPopup = true;
    },

    /**
     * 显示用户预测总决赛相关数据弹窗
     */
    handleShowFinalGusePopup() {
      // 遍历获取总决赛的比赛
      for (let i = 0; i < this.allMatchList.length; i++) {
        if (this.allMatchList[i].matchType == 2) {
          this.selectedMatchObj = this.allMatchList[i];
          this.selectedMatchIndex = i;
        }
      }
      this.fetchAllTeamList();
      this.handleShowGusePopup(this.selectedMatchObj, this.selectedMatchIndex);
    },

    /**
     * 显示用户预测弹窗
     */
    handleShowGusePopup(match, index) {
      this.selectedMatchIndex = index;
      this.selectedMatchObj = match;
      this.fetchKeysTotalPrice();
      // 判断预测是否开始
      if (match.startTime > new Date().getTime() / 1000) {
        return (this.showNoOpenGusePopup = true);
      }

      // 判断预测是否结束
      if (match.isEnd) {
        return (this.showEndGusePopup = true);
      }

      this.showGusePopup = true;

      // 初始化图表
      this.$nextTick(() => {
        this.$refs.myChart.innerHTML = "";

        const Line = this.$g2.Line;
        const data = [
          { year: "1991", value: 3 },
          { year: "1992", value: 4 },
          { year: "1993", value: 3.5 },
          { year: "1994", value: 5 },
          { year: "1995", value: 4.9 },
          { year: "1996", value: 6 },
          { year: "1997", value: 7 },
          { year: "1998", value: 9 },
          { year: "1999", value: 13 },
        ];
        const line = new Line("my-chart", {
          data,
          xField: "year",
          yField: "value",
          label: {},
          point: {
            size: 5,
            shape: "diamond",
            style: {
              fill: "white",
              stroke: "#5B8FF9",
              lineWidth: 2,
            },
          },
          tooltip: { showMarkers: false },
          state: {
            active: {
              style: {
                shadowBlur: 4,
                stroke: "#000",
                fill: "red",
              },
            },
          },
          interactions: [{ type: "marker-active" }],
        });
        line.render();
      });
    },

    /**
     * 关闭用户预测弹窗
     */
    handleCloseGusePopup() {
      this.showGusePopup = false;
      this.showDropDownTeam = false;
      this.guseData = {
        name: "Choose a team",
        cover: require("@/assets/images/game/cup/unkown-team-img.png"),
        result: 1,
        keys: 1,
        team: 0,
        keysTotalPrice: 0,
      };
    },

    /**
     * 点击收藏按钮
     */
    hanldeCollectMatch(item, index, type) {
      if (type == 1) {
        // 参加比赛
        if (item.collected) {
          // 已经收藏了
          item.collected = false;
        } else {
          // 未收藏
          item.collected = true;
        }
        this.joinedMatchList[index] = item;
      } else if (type == 2) {
        // 收藏比赛
        item.collected = false;
        this.collectedMatchList.splice(index, 1);
        if (item.userCostKeys <= 0) {
          // 未参加预测
          this.otherMatchList.push(item);
        } else {
          // 已经参加预测
          this.joinedMatchList.push(item);
        }
      } else if (type == 3) {
        // 其他比赛
        item.collected = true;
        this.otherMatchList.splice(index, 1);
        this.collectedMatchList.push(item);
      }

      // todo 发送请求修改收藏状态
    },

    /**
     * 复制邀请链接
     */
    handleCopyInvitLink(invitLink) {
      let oInput = document.createElement("input");
      oInput.value = invitLink;
      document.body.appendChild(oInput);
      oInput.select();
      document.execCommand("Copy");
      this.$toast.success(this.$i18n.tc("game.t3.tips.toast.copySuccessText"));
      oInput.remove();
    },

    /**
     * 获取用户账户余额
     */
    async fetchUserBalance() {
      // 获取用户余额
      let data = await this.$web3.eth.getBalance(this.currentAccount);
      this.userBalance = Number(
        this.$BigNumber(data).div(Math.pow(10, 18)).toFixed(4).toString(10)
      );
    },

    /**
     * 获取所有球队列表（后台）
     */
    async fetchAllTeamList() {
      // 判断是否有缓存
      if (this.$store.state.teamList.length > 0) {
        this.allTeamList = this.$store.state.teamList;
      } else {
        //  没有缓存，发送请求获取后台数据
        // let data = await this.$axios.get(`${this.$cupBaseURL}findAll`);
        // if (data.code == 200) {
        //   this.allTeamList = data.data;
        // }
        this.allTeamList = [{ name: "中国" }];
        this.$store.commit("SET_TEAM_LIST", this.allTeamList);
      }
      console.log("球队列表：", this.allTeamList);
    },

    /**
     * 获取所有比赛列表（后台数据）
     */
    async fetchAllMatchList() {
      // 判断缓存是否有数据
      if (this.$store.state.matchList.length > 0) {
        // 有缓存
        this.allMatchList = this.$store.state.matchList;
      } else {
        //  没有缓存，发送请求获取后台数据
        // let data = await this.$axios.get(`${this.$cupBaseURL}play`);
        // if (data.code == 200) {
        //    this.allMatchList = data.data;
        // }
        this.allMatchList = allMatchList;
      }
      console.log("比赛后端数据列表：", this.allMatchList);
    },

    /**
     * 获取所有比赛其他相关数据（合约数据）
     */
    async fetchAllMatchOtherInfo() {
      // 判断缓存是否有数据
      if (this.$store.state.matchList.length == 0) {
        // 没有缓存，循环获取比赛合约相关的数据
        for (let i = 0; i < this.allMatchList.length; i++) {
          await this.fetchMatchOtherInfo(this.allMatchList[i], i);
        }
        // 缓存数据
        this.$store.commit("SET_MATCH_LIST", this.allMatchList);
      }

      // 遍历比赛列表，分类
      this.allMatchList.map((item) => {
        if (item.userCostKeys > 0) {
          // 参加的比赛
          this.joinedMatchList.push(item);
        }
        if (item.collected && item.userCostKeys <= 0) {
          // 收藏的比赛
          this.collectedMatchList.push(item);
        }
        if (!item.collected && item.userCostKeys <= 0) {
          // 其他比赛
          this.otherMatchList.push(item);
        }
      });

      console.log("参加的比赛：", this.joinedMatchList);
      console.log("收藏的比赛：", this.collectedMatchList);
      console.log("其他的比赛：", this.otherMatchList);
      console.log("总决赛：", this.selectedMatchObj);
      console.log("比赛所有数据：", this.allMatchList);
    },

    /**
     * 获取单个比赛相关数据（合约数据）
     */
    async fetchMatchOtherInfo(match, index) {
      let ethContract = new this.$web3.eth.Contract(fomoabi, match.fomoAddress);

      // 获取用户注册后的id
      data = await ethContract.methods.pIDxAddr_(this.currentAccount).call();
      match.userId = data;

      // 根据用户id获取用户其他信息
      data = await ethContract.methods.plyr_(match.userId).call();
      match.userName = this.$web3.utils.hexToUtf8(data.name);

      // 生成分享链接
      match.userAddressShareUrl = this.currentAccount
        ? window.location.origin + `?type=1&address=${this.currentAccount}`
        : window.location.origin;
      match.userNameShareUrl = match.userName
        ? window.location.origin + `?type=2&address=${match.userName}`
        : window.location.origin;
      match.userIdShareUrl =
        match.userId != 0
          ? window.location.origin + `?type=3&address=${match.userId}`
          : window.location.origin;

      // 判断比赛是否开始
      match.isStartMatch =
        new Date(match.matchStartTime).getTime() > Date.now() ? true : false;

      // 获取比赛轮次
      let data = await ethContract.methods.rID_().call();
      match.roundNumber = Number(data);

      // 获取当前回合的剩余时间
      data = await ethContract.methods.getTimeLeft().call();
      match.leftTime = Number(data);

      // 获取用户在本次预测中和球赛相关的其他数据
      data = await ethContract.methods
        .getPlayerInfoByAddress(this.currentAccount)
        .call();
      match.userCostKeys = Number(
        this.$BigNumber(data[2]).div(Math.pow(10, 18)).toFixed(4).toString(10)
      );
      match.userIncome = Number(
        this.$BigNumber(data[5]).div(Math.pow(10, 18)).toFixed(4).toString(10)
      );
      match.userCostEth = Number(
        this.$BigNumber(data[6]).div(Math.pow(10, 18)).toFixed(4).toString(10)
      );

      // 获取用户在本次预测中的分红数据
      data = await ethContract.methods.getPlayerVaults(match.userId).call();
      match.userWinGains = this.$BigNumber(data[0])
        .div(Math.pow(10, 18))
        .toFixed(4)
        .toString(10);
      match.userTimeGains = this.$BigNumber(data[1])
        .div(Math.pow(10, 18))
        .toFixed(4)
        .toString(10);
      match.userAffGains = this.$BigNumber(data[2])
        .div(Math.pow(10, 18))
        .toFixed(4)
        .toString(10);
      match.totalGains = this.$BigNumber(data[0])
        .plus(this.$BigNumber(data[1]))
        .plus(this.$BigNumber(data[2]))
        .div(Math.pow(10, 18))
        .toFixed(4)
        .toString(10);

      // 获取四个阵营在本次预测中的总价值
      let campDataList = [];
      for (let j = 0; j < 4; j++) {
        data = await ethContract.methods.plyrRnds_(match.roundNumber, j).call();
        campDataList.push({
          totalEth: this.$BigNumber(data.eth)
            .div(Math.pow(10, 18))
            .toFixed(4)
            .toString(10),
          totalKeys: this.$BigNumber(data.keys)
            .div(Math.pow(10, 18))
            .toFixed(4)
            .toString(10),
        });
      }
      match.campDataList = campDataList;

      // 获取预测相关的其他数据
      data = await ethContract.methods.round_(match.roundNumber).call();
      match.startTime = Number(data.strt);
      match.endTime = Number(data.end);
      match.isEnd = data.ended;
      match.totalKeys = Number(
        this.$BigNumber(data.keys).div(Math.pow(10, 18)).toFixed(4).toString(10)
      );
      match.totalEth = Number(
        this.$BigNumber(data.eth).div(Math.pow(10, 18)).toFixed(4).toString(10)
      );
      match.totalPool = Number(
        this.$BigNumber(data.pot).div(Math.pow(10, 18)).toFixed(4).toString(10)
      );
      this.allMatchList[index] = match;
    },

    /**
     * 根据选中key的数量获取总价格
     */
    async fetchKeysTotalPrice() {
      let ethContract = new this.$web3.eth.Contract(
        fomoabi,
        this.selectedMatchObj.fomoAddress
      );
      let data = await ethContract.methods
        .iWantXKeys(this.$BigNumber(this.guseData.keys).times(Math.pow(10, 18)))
        .call();
      this.guseData.keysTotalPrice = Number(
        this.$BigNumber(data).div(Math.pow(10, 18)).toFixed(4).toString(10)
      );
      console.log("keys的总价：", this.guseData.keysTotalPrice);
    },

    /**
     * 支付预测
     */
    async handlePaymentGuse() {
      if (this.userBalance < this.keysTotalPrice) {
        // 预测费用不足
        this.showNoMoneyPopup = true;
      } else {
        // 开始加载动画
        let loading = this.$toast.loading({
          message: "payment...",
          forbidClick: true,
          duration: 0,
          loadingType: "spinner",
          overlay: true,
        });

        // 预测
        let ethContract = new this.$web3.eth.Contract(
          fomoabi,
          this.selectedMatchObj.fomoAddress
        );
        try {
          console.log("预测信息：", {
            shareInfoAddress: this.shareInfo.address,
            team: this.guseData.team,
            result: this.guseData.result,
            price: this.guseData.keysTotalPrice,
          });

          let data;
          if (this.shareInfo.type == 1) {
            console.log("根据地址分享链接竞猜");
            // 根据地址分享链接竞猜
            data = await ethContract.methods
              .buyXaddr(
                this.shareInfo.address,
                this.guseData.team,
                this.$BigNumber(this.guseData.keysTotalPrice).times(
                  Math.pow(10, 18)
                ),
                this.guseData.result
              )
              .send({
                from: this.currentAccount,
              });
          } else if (this.shareInfo.type == 2) {
            console.log("根据名称分享链接竞猜");
            // 根据名称分享链接竞猜
            data = await ethContract.methods
              .buyXname(
                this.$web3.utils.toHex(this.shareInfo.address),
                this.guseData.team,
                this.$BigNumber(this.guseData.keysTotalPrice).times(
                  Math.pow(10, 18)
                ),
                this.guseData.result
              )
              .send({
                from: this.currentAccount,
              });
          } else {
            console.log("根据id分享链接竞猜（默认）");
            // 根据id分享链接竞猜（默认）
            data = await ethContract.methods
              .buyXid(
                this.shareInfo.address || 0,
                this.guseData.team,
                this.$BigNumber(this.guseData.keysTotalPrice).times(
                  Math.pow(10, 18)
                ),
                this.guseData.result
              )
              .send({
                from: this.currentAccount,
              });
          }
          // 预测成功
          this.fetchMatchOtherInfo(
            this.selectedMatchObj,
            this.selectedMatchIndex
          );
          this.showGuseSuccessPopup = true;
          this.showGuseTeamPopup = false;
          this.handleCloseGusePopup();
          console.log(data);
        } catch (err) {
          // 预测失败
          this.showGuseFailedPopup = true;
          console.error(err);
        } finally {
          // 关闭加载动画
          loading.clear();
          this.showGusePaymentPopup = false;
        }
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.cup {
  width: 100%;

  // 顶部banner
  .banner-container {
    width: 100vw;
    height: 65vw;
    background: url("@/assets/images/game/cup/banner-bg.png") no-repeat;
    background-size: 100% 100%;
    background-position: 0 0;
    display: flex;
    flex-direction: column;
    padding: 0 18px;
    position: relative;

    .light-circle-bg {
      position: absolute;
      top: 50px;
      left: -3%;
      width: 70px;
      height: 60px;
      background: rgba(210, 54, 52, 0.7);
      filter: blur(38px);
    }

    .total-price {
      margin-top: 26px;
      font-size: 42px;
      font-family: Faktum Test-Bold, Faktum Test;
      font-weight: bold;
      color: #ffffff;
      line-height: 44px;
      text-shadow: 3px 3px 1px #bf2321;
    }

    .total-key {
      height: 38px;
      width: 110px;
      margin-top: 14px;
      background: url("@/assets/images/game/cup/key-bg.png") no-repeat;
      background-size: 100% 100%;
      font-size: 20px;
      font-family: DM Sans-Bold Italic, DM Sans;
      font-weight: normal;
      color: #ffe0d4;
      line-height: 38px;
      padding-left: 45px;
    }

    .guse-btn {
      height: 46px;
      width: 136px;
      line-height: 46px;
      text-align: center;
      margin-top: 40px;
      background: url("@/assets/images/game/cup/guse-btn-bg.png") no-repeat;
      background-size: 136px 46px;
      font-size: 14px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #ffffff;
    }
  }

  // 球赛区域
  .match-container {
    width: 100%;
    display: flex;
    flex-direction: column;
    position: relative;

    .light-circle-bg {
      position: absolute;
      top: 130px;
      right: 0%;
      width: 70px;
      height: 60px;
      background: rgba(210, 54, 52, 0.7);
      filter: blur(38px);
    }

    .match-bg {
      position: absolute;
      top: 0;
      right: 0;
      width: 100%;
      height: 166px;
    }

    // 标题
    .title-box {
      margin-top: -1px;
      padding: 0 12px;
      display: flex;
      flex-direction: column;
      align-items: center;
      background: linear-gradient(187deg, #0f293a 5%, #030303 55%);

      .title-text {
        display: flex;
        flex-direction: row;
        align-items: center;
        position: relative;

        .title {
          margin-top: 38px;
          font-size: 26px;
          font-family: Neue Machina-Ultrabold, Neue Machina;
          font-weight: 800;
          color: #ffffff;
          line-height: 10px;
          border-bottom: 12px solid #d23634;
          z-index: 1;
        }

        .icon {
          position: absolute;
          width: 40px;
          height: 40px;
          right: -50px;
          top: 40%;
        }
      }

      .category-box {
        width: 100%;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        position: relative;
        .category-btn {
          width: 192px;
          margin-top: 20px;
          display: flex;
          flex-direction: row;
          z-index: 1;
          height: 30px;
          background: rgba(255, 255, 255, 0.08);
          border-radius: 104px;
          border: 1px solid rgba(255, 255, 255, 0.2);

          .btn {
            width: 50%;
            height: 100%;
            line-height: 30px;
            text-align: center;
            font-size: 16px;
            font-family: DM Sans-Regular, DM Sans;
            font-weight: 500;
            color: #ffffff;
          }

          .active-btn {
            background: #d23634;
            border-radius: 104px;
          }
        }

        .question-icon {
          position: absolute;
          top: 20px;
          right: 0;
          width: 30px;
          height: 30px;
        }
      }
    }

    // 球赛列表
    .match-list {
      width: 100%;
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      padding: 20px 12px;

      // 更多比赛按钮
      .more-btn {
        margin-top: 19px;
        width: 100%;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
        .text {
          font-size: 16px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: rgba(255, 255, 255, 0.8);
          margin-right: 5px;
        }

        .icon {
          width: 16px;
          height: 16px;
        }
      }

      // 其他比赛按钮
      .other-btn {
        margin-bottom: 20px;
        margin-left: 50%;
        transform: translateX(-50%);
        margin-top: 30px;
        width: 100px;
        height: 30px;
        line-height: 30px;
        text-align: center;
        background: #d23634;
        border-radius: 104px;
        font-size: 16px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: #ffffff;
      }
    }
  }

  // 奖品池流动路线弹框
  .prize-pool-pupop-container {
    .popup-content {
      padding: 20px;
      padding-top: 0;

      .title {
        margin-top: 20px;
        height: 18px;
        font-size: 14px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: #ffffff;
      }

      .path-list {
        width: 100%;
        margin-top: 20px;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        position: relative;

        .divider {
          position: absolute;
          top: 31px;
          left: 0;
          width: 100%;
          border-bottom: 0.5px solid rgba(255, 255, 255, 0.2);
        }

        .path-item {
          height: 70px;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: flex-start;

          .icon-box {
            width: 100%;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            justify-content: center;

            .icon {
              width: 30px;
              height: 30px;
            }
          }

          .text {
            font-size: 12px;
            font-family: DM Sans-Regular, DM Sans;
            font-weight: 400;
            color: rgba(255, 255, 255, 0.8);
            line-height: 18px;
          }
        }
      }

      .path-list2 {
        .path-item {
          .icon-box {
            justify-content: flex-end;
          }

          &:nth-child(2) {
            .icon-box {
              justify-content: flex-start;
            }
          }
        }
      }

      .desc {
        margin-top: 8px;
        font-size: 12px;
        font-family: DM Sans-Regular, DM Sans;
        font-weight: 400;
        color: rgba(255, 255, 255, 0.8);
        line-height: 14px;
      }
    }
  }

  // 帮助弹框
  .help-pupop-container {
    height: 80vh;

    .popup-content {
      padding: 20px;
      padding-top: 12px;

      .icon-introduce {
        display: flex;
        flex-direction: column;
        padding-bottom: 8px;

        .title {
          font-size: 16px;
          font-family: DM Sans-Bold, DM Sans;
          font-weight: bold;
          color: #ffffff;
        }

        .icon-list {
          display: flex;
          flex-direction: column;
          .icon-item {
            display: flex;
            flex-direction: row;
            margin-top: 12px;
            margin-left: 10px;
            .icon {
              margin-right: 10px;
              width: 20px;
              height: 20px;
            }

            .text {
              font-size: 14px;
              font-family: DM Sans-Regular, DM Sans;
              font-weight: 400;
              color: #ffffff;
            }
          }
        }
      }

      .tips {
        margin-top: 6px;
        font-size: 12px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: #ffffff;
        line-height: 14px;
      }

      .help1-img {
        margin-top: 6px;
        width: 129px;
        height: 73px;
      }

      .help2-img {
        margin-top: 6px;
        width: 130px;
        height: 54px;
      }

      .description {
        margin-top: 6px;
        border-radius: 10px;
        padding: 10px;
        font-size: 12px;
        font-family: DM Sans-Regular, DM Sans;
        font-weight: 400;
        color: #e8e8e8;
        line-height: 14px;
      }

      .description1 {
        background: rgba(19, 34, 61, 0.7);
        border: 1px solid rgba(22, 76, 149, 0.85);
        border-top-color: rgba(22, 76, 149, 0.32);
        border-bottom-color: rgba(22, 76, 149, 0.76);
      }
      .description2 {
        background: rgba(23, 44, 15, 0.69);
        border: 1px solid rgba(42, 78, 28, 0.85);
        border-top-color: rgba(42, 78, 28, 0.32);
        border-bottom-color: rgba(42, 78, 28, 0.76);
      }

      .description3 {
        background: #2c0f0f;
        border: 1px solid rgba(210, 54, 52, 0.4);
        border-top-color: rgba(210, 54, 52, 0.31);
        border-bottom-color: rgba(210, 54, 52, 0.39);
      }

      .description4 {
        background: rgba(20, 20, 20, 0.8);
        border: 1px solid rgba(70, 70, 70, 0.85);
        border-top-color: rgba(70, 70, 70, 0.32);
        border-bottom-color: rgba(70, 70, 70, 0.76);
      }
    }
  }

  // 暂未开放预测弹框 预测结束
  .no-open-guse-popup-container,
  .end-guse-popup-container {
    width: 75%;
    background: #1b1b1b !important;
    border-radius: 7px;

    .no-open-popup-content {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      .close-icon {
        position: absolute;
        top: 10px;
        right: 12px;
        width: 24px;
        height: 24px;
      }

      .message-box {
        margin-top: 50px;
        margin-bottom: 50px;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;

        .icon {
          width: 26px;
          height: 26px;
          margin-right: 10px;
        }
        .message {
          // width: 110px;
          // text-overflow: ellipsis;
          // white-space: nowrap;
          // overflow: hidden;
          font-size: 14px;
          line-height: 16px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #ffffff;
        }
      }
    }
  }

  // 赛程基本情况弹框
  .match-popup-container {
    height: 55vh;

    .popup-content {
      padding: 16px 30px 20px 30px;
      display: flex;
      flex-direction: column;
      align-items: center;

      .btn-group {
        display: flex;
        flex-direction: row;
        align-items: center;
        .btn {
          width: 100px;
          height: 30px;
          line-height: 30px;
          text-align: center;
          border-radius: 104px;
          font-size: 16px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: rgba(255, 255, 255, 0.7);
          border: 1px solid rgba(255, 255, 255, 0.4);

          &:nth-child(1) {
            margin-right: 20px;
          }
        }

        .btn-active {
          color: #d23634;
          border: 1px solid #d23634;
        }
      }

      .match-content {
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        .title {
          margin-top: 14px;
          width: 78px;
          font-size: 14px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #ffffff;
        }

        .time {
          margin-top: 8px;
          font-size: 18px;
          font-family: Faktum Test-Bold, Faktum Test;
          font-weight: bold;
          color: #d23634;
        }

        // 数据列表
        .data-list {
          margin-top: 4px;
          width: 100%;
          display: flex;
          flex-direction: column;
          align-items: center;

          .data-item {
            margin-top: 12px;
            width: 100%;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;

            .text {
              font-size: 14px;
              font-family: DM Sans-Medium, DM Sans;
              font-weight: 500;
              color: rgba(255, 255, 255, 0.8);
            }

            .number {
              font-size: 14px;
              font-family: DM Sans-Bold, DM Sans;
              font-weight: bold;
              color: #ffffff;
            }
          }
        }

        // 团队列表
        .team-list {
          display: flex;
          flex-direction: row;
          flex-wrap: wrap;
          align-items: center;
          justify-content: space-between;
          width: 207px;
          margin-top: 20px;

          .team-item {
            display: flex;
            flex-direction: column;
            align-items: center;

            &:nth-child(1),
            &:nth-child(2) {
              margin-bottom: 28px;
            }

            .team-icon {
              width: 78px;
              height: 78px;
            }

            .price {
              margin-top: 6px;
              font-size: 14px;
              font-family: DM Sans-Bold, DM Sans;
              font-weight: bold;
              color: #ffffff;
              line-height: 16px;
            }
          }
        }
      }
    }
  }

  // 预测弹框
  .guse-popup-container {
    height: 80vh;

    .popup-content {
      padding: 0 12px;
      padding-bottom: 20px;

      .select-result {
        margin-top: 16px;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        padding: 0 12px;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.3);
        background: #272727;

        .team-box {
          display: flex;
          flex-direction: row;
          align-items: center;

          .team-item {
            display: flex;
            flex-direction: column;
            align-items: center;

            .cover {
              width: 62px;
              height: 41px;
            }

            .name {
              margin-top: 6px;
              width: 38px;
              font-size: 14px;
              font-family: DM Sans-Medium, DM Sans;
              font-weight: 500;
              color: #ffffff;
            }
          }

          .tag {
            font-size: 16px;
            font-family: Neue Machina-Ultrabold, Neue Machina;
            font-weight: 800;
            color: rgba(255, 255, 255, 0.8);
            line-height: 8px;
            border-bottom: 4px solid #d23634;
            margin: 0 4px;
          }
        }

        .result-btn-group {
          display: flex;
          flex-direction: column;
          align-items: center;

          .btn {
            margin-top: 10px;
            width: 86px;
            height: 24px;
            line-height: 24px;
            text-align: center;
            border-radius: 6px;
            border: 1px solid rgba(255, 255, 255, 0.7);
            font-size: 12px;
            font-family: DM Sans-Regular, DM Sans;
            font-weight: 400;
            color: rgba(255, 255, 255, 0.7);
            background: transparent;

            &:nth-child(3) {
              margin-bottom: 10px;
            }
          }

          .btn-active {
            color: #d23634;
            border: 1px solid #d23634;
          }
        }
      }

      .select-final-result {
        margin-top: 16px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;
        padding: 10px 0;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.3);
        background: #272727;

        .title {
          height: 16px;
          font-size: 12px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #ffffff;
          border-bottom: 3px solid #d23634;
        }

        .country-box {
          margin-top: 20px;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: center;

          .cover {
            width: 57px;
            height: 41px;
            margin-right: 38px;
          }

          .select-country {
            width: 135px;
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;

            .value-box {
              display: flex;
              flex-direction: row;
              align-items: center;
              justify-content: space-between;
              width: 135px;
              height: 24px;
              line-height: 24px;
              padding: 0 10px;
              border: 1px solid rgba(255, 255, 255, 0.6);
              border-radius: 6px;
              background: rgba(255, 255, 255, 0.2);

              .value {
                font-size: 12px;
                font-family: DM Sans-Regular, DM Sans;
                font-weight: 400;
                color: rgba(255, 255, 255, 0.7);
                margin-right: 5px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
              }

              .icon {
                margin-top: 5px;
                width: 10px;
                height: 10px;
              }
            }

            .option-list {
              width: 100%;
              max-height: 176px;
              background: #ffffff;
              border-radius: 6px;
              border: 1px solid #ffffff;
              padding: 0px 10px 8px 10px;
              overflow-y: scroll;
              position: absolute;
              top: 28px;
              left: 0;

              .option-item {
                margin-top: 8px;
                font-size: 12px;
                font-family: DM Sans-Regular, DM Sans;
                font-weight: 400;
                color: #1f1f1f;
              }

              .selected-option {
                color: #d23634;
              }
            }
          }
        }
      }

      .select-money {
        margin-top: 12px;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 10px 9px;
        border-radius: 4px;
        border: 1px solid rgba(255, 255, 255, 0.3);
        background: #272727;

        .desc {
          margin-top: 2px;
          font-size: 12px;
          font-family: DM Sans-Regular, DM Sans;
          font-weight: 400;
          color: rgba(255, 255, 255, 0.7);
          line-height: 14px;
        }

        .tips {
          margin-top: 4px;
          font-size: 12px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #ffffff;
          line-height: 14px;
        }

        .stepper-box {
          margin-top: 4px;
          width: 96px;
          height: 26px;
          border-radius: 4px;
          border: 1px solid #a5a5a5;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: space-between;

          .btn-icon {
            width: 26px;
            height: 26px;
          }

          .number {
            width: 100%;
            text-align: center;
            font-size: 18px;
            font-family: DM Sans-Medium, DM Sans;
            font-weight: 500;
            color: #d23634;
          }
        }
      }

      .drop-down {
        margin-top: 10px;
        width: 100%;
        border-radius: 104px;
        border: 1px solid rgba(255, 255, 255, 0.3);
        background: #272727;
        padding: 0 17px;

        .drop-down-title {
          height: 30px;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: space-between;

          .title {
            font-size: 16px;
            font-family: DM Sans-Medium, DM Sans;
            font-weight: 500;
            color: #ffffff;
          }

          .icon {
            width: 13px;
            height: 13px;
            transform: rotate(90deg);
          }
        }

        .btn {
          margin-bottom: 15px;
        }
      }

      .value-drop-down {
        .drop-down-content {
          padding: 0 10px;

          .value-item {
            display: flex;
            flex-direction: row;
            align-items: center;
            margin-top: 12px;
            justify-content: space-between;
            .text {
              font-size: 14px;
              font-family: DM Sans-Medium, DM Sans;
              font-weight: 500;
              color: rgba(255, 255, 255, 0.8);
            }

            .value {
              font-size: 14px;
              font-family: DM Sans-Bold, DM Sans;
              font-weight: bold;
              color: #ffffff;
            }
          }
        }
      }

      .address-drop-down {
        .drop-down-content {
          padding-bottom: 15px;
          .title {
            margin-top: 12px;
            font-size: 12px;
            font-family: DM Sans-Regular, DM Sans;
            font-weight: 400;
            color: #ffffff;
          }

          .address-item {
            margin-top: 8px;
            display: flex;
            flex-direction: column;
            align-items: center;

            .label {
              font-size: 12px;
              font-family: DM Sans-Regular, DM Sans;
              font-weight: 400;
              color: #ffffff;
            }

            .address-box {
              width: 100%;
              margin-top: 6px;
              height: 28px;
              background: rgba(255, 255, 255, 0.06);
              border-radius: 4px;
              border: 1px solid rgba(255, 255, 255, 0.3);
              display: flex;
              flex-direction: row;
              align-items: center;
              justify-content: space-between;
              padding: 0 13px 0 40px;

              .address {
                width: 100%;
                text-align: center;
                font-size: 12px;
                font-family: DM Sans-Regular, DM Sans;
                font-weight: 400;
                color: #ffffff;
                margin-right: 14px;
                text-align: center;
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
              }

              .icon {
                height: 14px;
                width: 14px;
              }
            }
          }

          .btn {
            margin-bottom: 0;
          }
        }
      }
      .echart-drop-down {
        .drop-down-content {
          padding: 10px 20px 15px 20px;

          #my-chart {
            width: 100%;
            height: 170px;
          }
        }
      }

      .drop-down-open {
        border-radius: 4px;
        padding-top: 5px;
      }

      .btn {
        margin: 0 auto;
        margin-top: 20px;
        width: 180px;
        height: 30px;
        line-height: 30px;
        text-align: center;
        background: #d23634;
        border-radius: 104px;
        font-size: 16px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: #ffffff;
      }
    }
  }

  // 选择阵营弹框
  .camp-popup-container {
    .popup-content {
      padding: 20px 5px;
      display: flex;
      flex-direction: column;
      align-items: center;

      .camp-list {
        width: 100%;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-around;

        .camp-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          width: 22%;
          height: 202px;
          background: rgba(53, 53, 53, 0.6);
          border-radius: 8px;
          position: relative;

          .cmap-icon {
            width: 100%;
            height: 64px;
          }

          &:nth-child(2),
          &:nth-child(4) {
            .cmap-icon {
              height: 72px;
            }
          }

          .cmap-price {
            margin-top: 17px;
            font-size: 14px;
            font-family: DM Sans-Bold, DM Sans;
            font-weight: bold;
            color: #ffffff;
          }

          .selected-icon {
            position: absolute;
            right: 10px;
            bottom: 10px;
            width: 18px;
            height: 18px;
          }
        }

        .camp-item-selected {
          border: 1px solid rgba(210, 54, 52, 0.4);
        }
      }

      .btn {
        margin: 0 auto;
        margin-top: 20px;
        width: 180px;
        height: 30px;
        line-height: 30px;
        text-align: center;
        background: #d23634;
        border-radius: 104px;
        font-size: 16px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: #ffffff;
      }
    }
  }
}
</style>
