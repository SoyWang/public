<template>
  <div class="recharge">
    <!-- 表单区域 -->
    <div class="form-contaienr">
      <div class="input-item">
        <p class="label">
          {{ $t("game.cup.recharge.inputLabelList[1].label") }}
        </p>
        <div class="input-box">
          <input
            class="input"
            type="number"
            v-model="rechargeFrom.t3t"
            :placeholder="$t('game.cup.recharge.inputLabelList[1].placeholder')"
          />
          <p class="unit">F3Cash</p>
        </div>
      </div>
      <div class="input-item">
        <p class="label">
          {{ $t("game.cup.recharge.inputLabelList[0].label") }}
        </p>
        <div class="input-box">
          <input
            class="input"
            type="number"
            v-model="rechargeFrom.usdt"
            disabled
            :placeholder="$t('game.cup.recharge.inputLabelList[0].placeholder')"
          />
          <p class="unit">USDT</p>
        </div>
      </div>
    </div>
    <!-- 按钮区域 -->
    <div class="btn-group">
      <div class="recharge-btn" @click="handleRechargeCoin">
        {{ $t("game.cup.recharge.rechargeBtnText") }}
      </div>
      <div
        class="recharge-detail-btn"
        @click="$router.push('/game/cup/rechargeDetail')"
      >
        {{ $t("game.cup.recharge.rechargeDetailBtnText") }}
      </div>
    </div>
  </div>
</template>

<script>
import bankabi from "@/static/web3js/abi/cup/bankabi.json";
import f3cashtokenabi from "@/static/web3js/abi/cup/f3cashtokenabi.json";
import usdttokenabi from "@/static/web3js/abi/cup/usdttokenabi.json";

import walletMxin from "@/pages/mixin/walletMxin";
export default {
  mixins: [walletMxin],
  layout: "cupGame",
  data() {
    return {
      exchangeRatio: null, // 兑换比例数
      usdtBalance: null, // 用户usdt余额
      t3tBalance: null, // 合约t3t余额
      rechargeFrom: {
        usdt: null,
        t3t: null,
      }, // 充值表单
    };
  },
  watch: {
    "rechargeFrom.t3t"(value) {
      if (value) {
        this.rechargeFrom.usdt = this.$BigNumber(value)
          .times(this.exchangeRatio)
          .toString(10);
      } else {
        this.rechargeFrom.usdt = null;
      }
    },
  },
  async mounted() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      await this.watchAccountChange();
    }
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.cup.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      await this.fetchRechargeRatio();
      await this.fetchUsdtBalance();
      await this.fetchT3tBalance();
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 获取充值兑换比列
     */
    async fetchRechargeRatio() {
      let ethContract = new this.$web3.eth.Contract(
        bankabi,
        this.$bankabiAddress
      );
      let data = await ethContract.methods.f3ExchangeRatio().call();
      this.exchangeRatio = Number(data) / 100;
      console.log("充值兑换比例：", this.exchangeRatio);
    },

    /**
     * 获取用户的usdt余额
     */
    async fetchUsdtBalance() {
      let ethContract = new this.$web3.eth.Contract(
        usdttokenabi,
        this.$usdttokenTestabiAddress
      );
      let data = await ethContract.methods
        .balanceOf(this.currentAccount)
        .call();
      this.usdtBalance = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4)
        .toString(10);
      console.log("usdt余额：", this.usdtBalance);
    },

    /**
     * 获取合约中的t3t余额
     */
    async fetchT3tBalance() {
      let ethContract = new this.$web3.eth.Contract(
        f3cashtokenabi,
        this.$f3cashtokenabiAddress
      );
      let data = await ethContract.methods
        .balanceOf(this.currentAccount)
        .call();
      this.t3tBalance = this.$BigNumber(data)
        .div(Math.pow(10, 18))
        .toFixed(4)
        .toString(10);
      console.log("合约中t3t的余额：", this.t3tBalance);
    },

    /**
     * 充值代币
     */
    async handleRechargeCoin() {
      // 判断充值金额是否为空
      if (!this.rechargeFrom.usdt || !this.rechargeFrom.t3t) {
        return this.$toast(
          this.$i18n.tc("game.cup.tips.toast.rechargeNumberText1")
        );
      }
      // 判断充值金额是否大于总的usdt数量
      if (this.rechargeFrom.usdt > Number(this.usdtBalance)) {
        return this.$toast(
          this.$i18n.tc("game.cup.tips.toast.rechargeNumberText2")
        );
      }

      // 查询授权金额
      let result = await this.fetchAuthorizationPayMoney();
      if (!result) return;

      // 充值
      let ethContract = new this.$web3.eth.Contract(
        bankabi,
        this.$bankabiAddress
      );

      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.cup.tips.loading.rechargeText"),
        forbidClick: true,
        duration: 0,
        loadingType: "spinner",
        overlay: true,
      });
      try {
        let data = await ethContract.methods
          .exchangeUsdtIntoF3(
            this.$BigNumber(this.rechargeFrom.usdt)
              .times(Math.pow(10, 6))
              .integerValue()
              .toString(10)
          )
          .send({ from: this.currentAccount });
        console.log(data);
        this.$notify({
          type: "success",
          message: this.$i18n.tc("game.cup.tips.notify.rechargeSuccessText"),
        });
        this.rechargeFrom.usdt = null;
        this.rechargeFrom.t3t = null;
      } catch (err) {
        console.error(err);
        this.$notify({
          type: "danger",
          message: this.$i18n.tc("game.cup.tips.notify.rechargeFailText"),
        });
        this.withdrawFrom.t3t = null;
        this.withdrawFrom.usdt = null;
      } finally {
        // 关闭加载动画
        loading.clear();
      }
    },

    /**
     * 查询授权金额的余量
     */
    async fetchAuthorizationPayMoney() {
      let ethContract = new this.$web3.eth.Contract(
        usdttokenabi,
        this.$usdttokenTestabiAddress
      );
      let data = await ethContract.methods
        .allowance(this.currentAccount, this.$bankabiAddress)
        .call();
      let authorizationMoney = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4);
      console.log("需要充值的t3t：", this.rechargeFrom.t3t);
      console.log("剩余授权金额额度：", authorizationMoney.toString(10));
      if (this.$BigNumber(this.rechargeFrom.t3t).gt(authorizationMoney)) {
        // 额度不够，调用授权金额接口
        return await this.authorizationPayMoney();
      }
      return true;
    },

    /**
     * 授权金额
     */
    async authorizationPayMoney() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.cup.tips.loading.authorizeText"),
        forbidClick: true,
        duration: 0,
        loadingType: "spinner",
        overlay: true,
      });
      let ethContract = new this.$web3.eth.Contract(
        usdttokenabi,
        this.$bankabiAddress
      );
      try {
        let data = await ethContract.methods
          .approve(
            this.$f3cashtokenabiAddress,
            this.$BigNumber(10000000000000 * Math.pow(10, 6)).toString(10)
          )
          .send({ from: this.currentAccount });
        console.log(data);
        this.$notify({
          type: "success",
          message: this.$i18n.tc("game.cup.tips.notify.authorizeSuccessText"),
        });
        return true;
      } catch (err) {
        console.error(err);
        this.$notify({
          type: "danger",
          message: this.$i18n.tc("game.cup.tips.notify.authorizeFailText"),
        });
        return false;
      } finally {
        // 关闭加载动画
        loading.clear();
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.recharge {
  width: 100%;
  padding: 0 12px;

  // 表单区域
  .form-contaienr {
    .input-item {
      display: flex;
      flex-direction: column;
      margin-top: 30px;

      .label {
        font-size: 16px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: rgba(255, 255, 255, 0.8);
      }

      .input-box {
        height: 37px;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid rgba(255, 255, 255, 0.7);
        padding: 0 2px;

        .input {
          width: 100%;
          height: 100%;
          color: #ffffff;
          background: transparent;
          border: none;
          outline: none;
          font-size: 16px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #ffffff;
        }

        .unit {
          font-size: 14px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #ffffff9c;
          padding: 0 19px;
        }

        .unit-red {
          color: #d23634;
        }
      }
    }
  }

  // 按钮区域
  .btn-group {
    margin-top: 100px;
    display: flex;
    flex-direction: column;
    align-items: center;

    .recharge-btn {
      margin-bottom: 20px;
      width: 220px;
      height: 40px;
      line-height: 40px;
      text-align: center;
      background: #d23634;
      border-radius: 131px;
      font-size: 16px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #ffffff;
    }

    .recharge-detail-btn {
      width: 220px;
      height: 40px;
      height: 40px;
      line-height: 40px;
      text-align: center;
      border-radius: 131px;
      border: 1px solid #d23634;
      font-size: 16px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #d23634;
    }
  }
}
</style>