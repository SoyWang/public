<template>
  <!-- 提现明细 -->
  <div class="withdrawal-detail">
    <div class="table-header">
      <p
        v-for="(item, index) in $t('game.cup.withdrawDetail.tableRowLabel')"
        :key="index"
      >
        {{ item }}
      </p>
    </div>
    <template v-if="withdrawRecord.length">
      <div
        class="table-row"
        v-for="(item, index) in withdrawRecord"
        :key="index"
      >
        <p>+{{ item.amount }}</p>
        <p>—</p>
        <p>F3Cash</p>
        <p>{{ item.createTime | dateFormat }}</p>
      </div>
      <!-- 没有更多数据 -->
      <div class="none-more-data">
        {{ $t("game.cup.withdrawDetail.noneMoreDataText") }}
      </div>
    </template>

    <!-- 没有数据 -->
    <template v-else>
      <div class="none-data">
        {{ $t("game.cup.withdrawDetail.noneDataText") }}
      </div>
    </template>
  </div>
</template>

<script>
import walletMxin from "@/pages/mixin/walletMxin";
export default {
  layout: "cupGame",
  mixins: [walletMxin],
  data() {
    return {
      withdrawRecord: [], // 提现记录
    };
  },
  async created() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      await this.watchAccountChange();
    }
  },
  filters: {
    // 日期格式化
    dateFormat(dateStr) {
      let format = "YYYY.MM.DD HH:mm";
      const date = new Date(dateStr);
      // 位数不足两位时在前面补零
      const dateNumFun = (num) => String(num).padStart("0", 2);
      const config = {
        YYYY: date.getFullYear(),
        MM: dateNumFun(date.getMonth() + 1),
        DD: dateNumFun(date.getDate()),
        HH: dateNumFun(date.getHours()),
        mm: dateNumFun(date.getMinutes()),
      };
      for (const key in config) {
        format = format.replace(key, config[key]);
      }
      return format;
    },
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      await this.fetchwithdrawRecord();
    },

    /**
     * 获取提现记录
     */
    async fetchwithdrawRecord() {
      let data = await this.$axios.get(
        `${this.$cupBaseURL}userRecord/user/${this.currentAccount}/${2}`
      );
      if (data.length > 0) {
        this.withdrawRecord = data;
        console.log("提现记录：", data);
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.withdrawal-detail {
  width: 100%;
  position: relative;

  .table-header {
    padding: 0 15px;
    height: 44px;
    background: #1b1b1b;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    position: fixed;
    width: 100%;
    z-index: 1;
    border-top: 1px solid rgba(255, 255, 255, 0.2);

    p {
      flex: 1;
      text-align: center;
      font-size: 12px;
      font-family: PingFang SC;
      font-weight: 400;
      color: #ffffff;

      &:nth-child(1) {
        width: 34%;
      }

      &:nth-child(2) {
        width: 18%;
      }

      &:nth-child(3) {
        width: 18%;
      }

      &:nth-child(4) {
        width: 30%;
      }
    }
  }

  .table-row {
    margin: 0 15px;
    height: 50px;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);

    &:nth-child(2) {
      margin-top: 50px;
    }

    &:nth-last-child(2) {
      border-bottom: none;
    }

    p {
      flex: 1;
      text-align: center;
      font-size: 12px;
      font-family: PingFang SC;
      font-weight: 400;
      color: #ffffff;
      opacity: 0.5;

      &:nth-child(1) {
        width: 34%;
      }

      &:nth-child(2) {
        width: 18%;
      }

      &:nth-child(3) {
        width: 18%;
      }

      &:nth-child(4) {
        width: 30%;
      }
    }
  }

  .none-data,
  .none-more-data {
    line-height: 30px;
    padding-bottom: 15px;
    text-align: center;
    font-size: 14px;
    font-family: PingFang SC;
    font-weight: 400;
    color: rgba(142, 142, 142, 0.445);
  }

  .none-data {
    margin-top: 50px;
    line-height: 50px;
  }
}

/* 浏览器可视宽度大于600px */
@media only screen and (min-width: 600px) {
  .withdrawal-detail {
    .table-header {
      height: 65px;

      p {
        font-size: 20px;

        &:nth-child(1) {
        }

        &:nth-child(2) {
        }

        &:nth-child(3) {
        }

        &:nth-child(4) {
        }
      }
    }

    .table-row {
      height: 65px;

      &:nth-child(2) {
        margin-top: 65px;
      }

      &:nth-last-child(2) {
        border-bottom: none;
      }

      p {
        font-size: 18px;

        &:nth-child(1) {
        }

        &:nth-child(2) {
        }

        &:nth-child(3) {
        }

        &:nth-child(4) {
        }
      }
    }

    .none-data,
    .none-more-data {
      line-height: 40px;
      padding-bottom: 20px;
      font-size: 20px;
    }

    .none-data {
    }
  }
}
</style>