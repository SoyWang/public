<template>
  <!-- 我的收益 -->
  <div class="mine-income">
    <!-- 面板 -->
    <div class="panel-board-container">
      <div class="panel-board">
        <p class="total">
          <span>{{ balance }}</span>
          <span>F3Cash</span>
        </p>
        <p class="text">{{ $t("game.t3.income.balanceText") }}</p>
        <div class="btn-group">
          <div class="btn" @click="$router.push('/game/t3/recharge')">
            {{ $t("game.t3.income.rechargeText") }}
          </div>
          <div class="btn" @click="$router.push('/game/t3/withdraw')">
            {{ $t("game.t3.income.withdrawalText") }}
          </div>
        </div>
      </div>

      <div class="table-header">
        <div
          class="label"
          v-for="(item, index) in $t(
            'game.t3.income.incomeDetail.tableRowLabel'
          )"
          :key="index"
        >
          <!-- 普通值 -->
          <template v-if="item.type == 1">
            {{ item.value }}
          </template>
          <!-- 类型值 -->
          <template v-if="item.type == 2">
            {{ selectType == 1 ? item.value.balance : item.value.starId }}
          </template>
          <!-- 下拉选择框 -->
          <template v-else-if="item.type == 3">
            <van-dropdown-menu active-color="#023ad4">
              <van-dropdown-item v-model="selectType" :options="item.value" />
            </van-dropdown-menu>
          </template>
        </div>
      </div>
    </div>

    <!-- 收入明细 -->
    <div class="income-detail">
      <template v-if="recordList.length">
        <div class="table-row" v-for="(item, index) in recordList" :key="index">
          <p>
            <span>{{ selectType == 1 ? "+" : "-" }}</span
            >{{ item.amount / Math.pow(10, 6) }}
          </p>
          <p>
            {{ selectType == 1 ? item.balance / Math.pow(10, 6) : item.carId }}
          </p>
          <p>F3Cash</p>
          <p>{{ item.timestamp | dateFormat }}</p>
        </div>
        <!-- 没有更多数据 -->
        <div class="none-more-data">
          {{ $t("game.t3.income.incomeDetail.noneMoreDataText") }}
        </div>
      </template>

      <!-- 没有数据 -->
      <template v-else>
        <div class="none-data">
          {{ $t("game.t3.income.incomeDetail.noneDataText") }}
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import herotonkenabi from "@/static/web3js/abi/t3/herotonkenabi.json";
import walletMxin from "@/pages/mixin/walletMxin";
export default {
  mixins: [walletMxin],
  layout: "t3Game",
  data() {
    return {
      balance: 0, // 当前账户余额
      selectType: 1, // 当前选中的记录类型（1:收入，2：支出）
      recordList: [], // 收入支出记录
    };
  },
  async created() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      await this.watchAccountChange();
    }
  },
  watch: {
    // 监听记录类型变化
    selectType: {
      handler(value) {
        if (value == 1) {
          // 收入
          this.fetchIncomeRecord();
        } else {
          // 支出
          this.fetchDisbursementRecord();
        }
      },
    },
  },
  filters: {
    // 日期格式化
    dateFormat(dateStr) {
      let format = "YYYY.MM.DD HH:mm";
      const date = new Date(Number(dateStr) * 1000);
      // 位数不足两位时在前面补零
      const dateNumFun = (num) => String(num).padStart("0", 2);
      const config = {
        YYYY: date.getFullYear(),
        MM: dateNumFun(date.getMonth() + 1),
        DD: dateNumFun(date.getDate()),
        HH: dateNumFun(date.getHours()),
        mm: dateNumFun(date.getMinutes()),
      };
      for (const key in config) {
        format = format.replace(key, config[key]);
      }
      return format;
    },
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      await this.fetchUserCoin();
      await this.fetchIncomeRecord();
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 获取用户的代币
     */
    async fetchUserCoin() {
      let ethContract = new this.$web3.eth.Contract(
        herotonkenabi,
        this.$herotonkenabiAddress
      );
      let data = await ethContract.methods
        .balanceOf(this.currentAccount)
        .call();
      this.balance = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4)
        .toString(10);
      console.log("用户当前的T3T：", this.balance);
    },

    /**
     * 获取收入明细记录
     */
    async fetchIncomeRecord() {
      let data = await this.$axios.get(
        `${this.$t3BaseURL}deposit_records?address=${this.currentAccount}`
      );
      if (data.result) {
        data.result.sort((obj1, obj2) => {
          let timestamp1 = obj1.timestamp;
          let timestamp2 = obj2.timestamp;
          if (timestamp1 < timestamp2) {
            return 1;
          } else if (timestamp1 > timestamp2) {
            return -1;
          } else {
            return 0;
          }
        });
        this.recordList = data.result;
      } else {
        this.recordList = [];
      }
    },

    /**
     * 获取支出明细记录
     */
    async fetchDisbursementRecord() {
      let data = await this.$axios.get(
        `${this.$t3BaseURL}car_records?address=${this.currentAccount}`
      );
      if (data.result) {
        data.result.sort((obj1, obj2) => {
          let timestamp1 = obj1.timestamp;
          let timestamp2 = obj2.timestamp;
          if (timestamp1 < timestamp2) {
            return 1;
          } else if (timestamp1 > timestamp2) {
            return -1;
          } else {
            return 0;
          }
        });
        this.recordList = data.result;
      } else {
        this.recordList = [];
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.mine-income {
  width: 100%;
  position: relative;

  // 面板
  .panel-board-container {
    background: #000c1d;
    position: fixed;
    width: 100%;
    top: 68px;
    z-index: 1;

    .panel-board {
      margin: 0 15px;
      height: 180px;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 20px 43px;
      background-image: url("@/assets/images/game/t3/mine-income-bg.png");
      background-size: 100% 100%;

      .total {
        span {
          font-family: PingFang SC;
          font-weight: bold;
          color: #ffffff;

          &:nth-child(1) {
            font-size: 30px;
          }

          &:nth-child(2) {
            font-size: 14px;
          }
        }
      }

      .text {
        margin-top: 10px;
        font-size: 14px;
        font-family: PingFang SC;
        font-weight: 400;
        color: #ffffff;
      }

      .btn-group {
        margin-top: 33px;
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-between;

        .btn {
          width: 46%;
          height: 40px;
          line-height: 40px;
          border-radius: 5px;
          font-size: 14px;
          font-family: PingFang SC;
          font-weight: 400;
          color: #ffffff;
          text-align: center;

          &:nth-child(1) {
            background: rgba(255, 255, 255, 0.3);
          }

          &:nth-child(2) {
            background: rgba(255, 255, 255, 0);
            border: 1px solid #ffffff;
          }
        }
      }
    }

    .table-header {
      margin: 0 15px;
      margin-top: 20px;
      height: 50px;
      background: rgba(255, 255, 255, 0.1);
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;

      .label {
        text-align: center;
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        color: #ffffff;

        &:nth-child(1) {
          width: 34%;
        }

        &:nth-child(2) {
          width: 18%;
        }

        &:nth-child(3) {
          width: 18%;
        }

        &:nth-child(4) {
          width: 30%;
        }
      }
    }
  }

  // 收入明细
  .income-detail {
    margin: 0 15px;
    margin-top: 250px;

    .table-row {
      width: 100%;
      height: 50px;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);

      &:nth-last-child(2) {
        border-bottom: none;
      }

      p {
        text-align: center;
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        color: #ffffff;
        opacity: 0.5;

        &:nth-child(1) {
          width: 34%;
        }

        &:nth-child(2) {
          width: 18%;
        }

        &:nth-child(3) {
          width: 18%;
        }

        &:nth-child(4) {
          width: 30%;
        }
      }
    }

    .none-data,
    .none-more-data {
      line-height: 30px;
      padding-bottom: 15px;
      text-align: center;
      font-size: 14px;
      font-family: PingFang SC;
      font-weight: 400;
      color: rgba(142, 142, 142, 0.445);
    }

    .none-data {
      line-height: 50px;
    }
  }
}

/* 浏览器可视宽度大于600px */
@media only screen and (min-width: 600px) {
  .mine-income {
    width: 100%;
    position: relative;

    // 面板
    .panel-board-container {
      .panel-board {
        height: 250px;

        .total {
          span {
            &:nth-child(1) {
              font-size: 40px;
            }

            &:nth-child(2) {
              font-size: 20px;
            }
          }
        }

        .text {
          font-size: 20px;
        }

        .btn-group {
          .btn {
            margin-top: 15px;
            height: 50px;
            line-height: 50px;
            font-size: 20px;

            &:nth-child(1) {
            }

            &:nth-child(2) {
            }
          }
        }
      }

      .table-header {
        margin-top: 25px;
        height: 65px;

        .label {
          font-size: 18px;

          &:nth-child(1) {
          }

          &:nth-child(2) {
          }

          &:nth-child(3) {
          }

          &:nth-child(4) {
          }
        }
      }
    }

    // 收入明细
    .income-detail {
      margin-top: 340px;

      .table-row {
        height: 65px;

        &:nth-last-child(2) {
        }

        p {
          font-size: 18px;

          &:nth-child(1) {
          }

          &:nth-child(2) {
          }

          &:nth-child(3) {
          }

          &:nth-child(4) {
          }
        }
      }

      .none-data,
      .none-more-data {
        line-height: 40px;
        padding-bottom: 20px;
        font-size: 20px;
      }

      .none-data {
      }
    }
  }
}
</style>