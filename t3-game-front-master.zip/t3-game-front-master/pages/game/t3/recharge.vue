<template>
  <!-- 充值 -->
  <div class="recharge">
    <div class="form">
      <div class="form-item">
        <p class="label">
          {{ $t("game.t3.recharge.inputLabelList[1].label") }}
        </p>
        <div class="input-box">
          <input
            class="input"
            type="number"
            v-model="rechargeFrom.t3t"
            :placeholder="$t('game.t3.recharge.inputLabelList[1].placeholder')"
          />
          <p class="unit">F3Cash</p>
        </div>
      </div>
      <div class="form-item">
        <p class="label">
          {{ $t("game.t3.recharge.inputLabelList[0].label") }}
        </p>
        <div class="input-box">
          <input
            class="input"
            type="number"
            v-model="rechargeFrom.usdt"
            disabled
            :placeholder="$t('game.t3.recharge.inputLabelList[0].placeholder')"
          />
          <p class="unit">USDT</p>
        </div>
      </div>
    </div>
    <div class="btn-group">
      <div class="btn" @click="handleRechargeCoin">
        {{ $t("game.t3.recharge.rechargeBtnText") }}
      </div>
      <div class="btn" @click="$router.push('/game/t3/rechargeDetail')">
        {{ $t("game.t3.recharge.rechargeDetailBtnText") }}
      </div>
    </div>
  </div>
</template>

<script>
import autoheroabi from "@/static/web3js/abi/t3/autoheroabi.json";
import herotonkenabi from "@/static/web3js/abi/t3/herotonkenabi.json";
import usdttokenabi from "@/static/web3js/abi/t3/usdttokenabi.json";
import walletMxin from "@/pages/mixin/walletMxin";
export default {
  mixins: [walletMxin],
  layout: "t3Game",
  data() {
    return {
      exchangeRatio: null, // 兑换比例数
      usdtBalance: null, // 用户usdt余额
      t3tBalance: null, // 合约t3t余额
      rechargeFrom: {
        usdt: null,
        t3t: null,
      }, // 充值表单
    };
  },
  watch: {
    "rechargeFrom.t3t"(value) {
      if (value) {
        this.rechargeFrom.usdt = this.$BigNumber(value)
          .times(this.exchangeRatio)
          .toString(10);
      } else {
        this.rechargeFrom.usdt = null;
      }
    },
    // 'rechargeFrom.usdt'(value) {
    //   if (value) {
    //     this.rechargeFrom.t3t = this.$BigNumber(value)
    //       .div(this.exchangeRatio)
    //       .toString(10);
    //   } else {
    //     this.rechargeFrom.t3t = null;
    //   }
    // },
  },
  async created() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      await this.watchAccountChange();
    }
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      await this.fetchRechargeRatio();
      await this.fetchUsdtBalance();
      await this.fetchT3tBalance();
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 获取充值兑换比列
     */
    async fetchRechargeRatio() {
      let ethContract = new this.$web3.eth.Contract(
        autoheroabi,
        this.$autoheroabiAddress
      );
      let data = await ethContract.methods
        .getNTExchangeRatioAgainstUsdt()
        .call();
      this.exchangeRatio = Number(data) / 100;
      console.log("充值兑换比例：", this.exchangeRatio);
    },

    /**
     * 获取用户的usdt余额
     */
    async fetchUsdtBalance() {
      let ethContract = new this.$web3.eth.Contract(
        usdttokenabi,
        this.$usdttokenabiAddress
      );
      let data = await ethContract.methods
        .balanceOf(this.currentAccount)
        .call();
      this.usdtBalance = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4)
        .toString(10);
      console.log("usdt余额：", this.usdtBalance);
    },

    /**
     * 获取合约中的t3t余额
     */
    async fetchT3tBalance() {
      let ethContract = new this.$web3.eth.Contract(
        herotonkenabi,
        this.$herotonkenabiAddress
      );
      let data = await ethContract.methods
        .balanceOf(this.currentAccount)
        .call();
      this.t3tBalance = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4)
        .toString(10);
      console.log("合约中t3t的余额：", this.t3tBalance);
    },

    /**
     * 充值代币
     */
    async handleRechargeCoin() {
      // 判断充值金额是否为空
      if (!this.rechargeFrom.usdt || !this.rechargeFrom.t3t) {
        return this.$toast(
          this.$i18n.tc("game.t3.tips.toast.rechargeNumberText1")
        );
      }
      // 判断充值金额是否大于总的usdt数量
      if (this.rechargeFrom.usdt > Number(this.usdtBalance)) {
        return this.$toast(
          this.$i18n.tc("game.t3.tips.toast.rechargeNumberText2")
        );
      }

      // 查询授权金额
      let result = await this.fetchAuthorizationPayMoney();
      if (!result) return;

      // 充值
      let ethContract = new this.$web3.eth.Contract(
        autoheroabi,
        this.$autoheroabiAddress
      );

      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.rechargeText"),
        forbidClick: true,
        duration: 0,
        loadingType: "spinner",
        overlay: true,
      });
      try {
        let data = await ethContract.methods
          .exchangeUsdtIntoNT(
            this.$BigNumber(this.rechargeFrom.usdt)
              .times(Math.pow(10, 6))
              .integerValue()
              .toString(10)
          )
          .send({ from: this.currentAccount });
        console.log(data);
        this.$router.replace("/game/t3/rechargeSuccess");
      } catch (err) {
        console.error(err);
        this.$router.replace("/game/t3/rechargeFail");
      } finally {
        // 关闭加载动画
        loading.clear();
      }
    },

    /**
     * 查询授权金额的余量
     */
    async fetchAuthorizationPayMoney() {
      let ethContract = new this.$web3.eth.Contract(
        usdttokenabi,
        this.$usdttokenabiAddress
      );
      let data = await ethContract.methods
        .allowance(this.currentAccount, this.$autoheroabiAddress)
        .call();
      let authorizationMoney = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4);
      console.log("需要充值的t3t：", this.rechargeFrom.t3t);
      console.log("剩余授权金额额度：", authorizationMoney.toString(10));
      if (this.$BigNumber(this.rechargeFrom.t3t).gt(authorizationMoney)) {
        // 额度不够，调用授权金额接口
        return await this.authorizationPayMoney();
      }
      return true;
    },

    /**
     * 授权金额
     */
    async authorizationPayMoney() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.authorizeText"),
        forbidClick: true,
        duration: 0,
        loadingType: "spinner",
        overlay: true,
      });
      let ethContract = new this.$web3.eth.Contract(
        usdttokenabi,
        this.$usdttokenabiAddress
      );
      try {
        let data = await ethContract.methods
          .approve(
            this.$autoheroabiAddress,
            this.$BigNumber(10000000000000 * Math.pow(10, 6)).toString(10)
          )
          .send({ from: this.currentAccount });
        console.log(data);
        this.$notify({
          type: "success",
          message: this.$i18n.tc("game.t3.tips.notify.authorizeSuccessText"),
        });
        return true;
      } catch (err) {
        console.error(err);
        this.$notify({
          type: "danger",
          message: this.$i18n.tc("game.t3.tips.notify.authorizeFailText"),
        });
        return false;
      } finally {
        // 关闭加载动画
        loading.clear();
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.recharge {
  width: 100%;
  padding: 0 15px;

  .form {
    display: flex;
    flex-direction: column;
    align-items: center;

    .form-item {
      margin-top: 30px;
      width: 100%;
      display: flex;
      flex-direction: column;

      .label {
        font-size: 14px;
        font-family: PingFang SC;
        font-weight: 400;
        line-height: 22px;
        color: #ffffff;
      }

      .input-box {
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);

        .input {
          width: 88%;
          font-size: 14px;
          height: 45px;
          background: none;
          outline: none;
          border: none;
          outline: none;
          color: rgba(255, 255, 255, 0.5);
          font-family: PingFang SC;
          font-weight: 400;
        }

        .unit {
          font-size: 14px;
          font-family: PingFang SC;
          font-weight: 400;
          line-height: 45px;
          color: #ffffff;
        }

        .unit-blue {
          color: #4773fd;
        }
      }
    }
  }

  .btn-group {
    margin-top: 50px;
    width: 100%;
    display: flex;
    flex-direction: column;

    .btn {
      height: 40px;
      border-radius: 5px;
      text-align: center;
      font-size: 16px;
      font-family: PingFang SC;
      font-weight: bold;
      line-height: 40px;
      color: #ffffff;

      &:nth-child(1) {
        background: linear-gradient(180deg, #00d5ff 0%, #0044ff 100%);
      }

      &:nth-child(2) {
        margin-top: 20px;
        background: rgba(255, 255, 255, 0.39);
      }
    }
  }
}

/* 浏览器可视宽度大于600px */
@media only screen and (min-width: 600px) {
  .recharge {
    .form {
      .form-item {
        margin-top: 40px;

        .label {
          font-size: 20px;
          line-height: 32px;
        }

        .input-box {
          .input {
            font-size: 20px;
            height: 55px;
          }

          .unit {
            font-size: 20px;
            line-height: 55px;
          }

          .unit-blue {
          }
        }
      }
    }

    .btn-group {
      margin-top: 60px;

      .btn {
        height: 55px;
        font-size: 24px;
        line-height: 55px;

        &:nth-child(1) {
        }

        &:nth-child(2) {
          margin-top: 30px;
        }
      }
    }
  }
}
</style>