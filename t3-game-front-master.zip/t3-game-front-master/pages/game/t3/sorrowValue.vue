<template>
  <!-- 悲情值 -->
  <div class="sorrow-value">
    <div class="panel-board">
      <p class="total">
        <span>{{ sadValue }}</span>
        <span>{{ $t("game.t3.sadPoint.sadPointText") }}</span>
      </p>
      <div class="btn-group">
        <div
          class="btn"
          @click="$router.push('/game/t3?showUnlockStarPopup=true')"
        >
          {{ $t("game.t3.sadPoint.unlockStarText") }}
        </div>
        <div class="btn" @click="$router.push('/game/t3/share')">
          {{ $t("game.t3.sadPoint.shareText") }}
        </div>
      </div>
    </div>
    <div class="question-list">
      <div class="question-item">
        <p class="question">
          {{ $t("game.t3.sadPoint.questionList[0].question") }}
        </p>
        <p class="answer">
          {{ $t("game.t3.sadPoint.questionList[0].answer") }}
        </p>
      </div>
      <div class="question-item">
        <p class="question">
          {{ $t("game.t3.sadPoint.questionList[1].question") }}
        </p>
        <p class="answer">
          {{ $t("game.t3.sadPoint.questionList[1].answer") }}
        </p>
      </div>
      <div class="question-item">
        <p class="question">
          {{ $t("game.t3.sadPoint.questionList[2].question") }}
        </p>
        <p class="answer">
          {{ $t("game.t3.sadPoint.questionList[2].answer") }}
        </p>
      </div>
      <div class="question-item">
        <p class="question">
          {{ $t("game.t3.sadPoint.questionList[3].question") }}
        </p>
        <div class="table-content">
          <div class="table-header">
            <p>
              {{ $t("game.t3.sadPoint.questionList[3].answer.rowLabel[0]") }}
            </p>
            <p>
              {{ $t("game.t3.sadPoint.questionList[3].answer.rowLabel[1]") }}
            </p>
            <p>
              {{ $t("game.t3.sadPoint.questionList[3].answer.rowLabel[2]") }}
            </p>
          </div>
          <div class="table-row">
            <p>
              {{ $t("game.t3.sadPoint.questionList[3].answer.columnLabel[0]") }}
            </p>
            <p>2</p>
            <p>+30</p>
          </div>
          <div class="table-row">
            <p>
              {{ $t("game.t3.sadPoint.questionList[3].answer.columnLabel[1]") }}
            </p>
            <p>3</p>
            <p>+0</p>
          </div>
          <div class="table-row">
            <p>
              {{ $t("game.t3.sadPoint.questionList[3].answer.columnLabel[2]") }}
            </p>
            <p>4</p>
            <p>-100</p>
          </div>
        </div>
      </div>
      <div class="question-item">
        <p class="question">
          {{ $t("game.t3.sadPoint.questionList[4].question") }}
        </p>
        <p class="answer">
          {{ $t("game.t3.sadPoint.questionList[4].answer") }}
        </p>
      </div>
    </div>
  </div>
</template>

<script>
import herostorageabi from "@/static/web3js/abi/t3/herostorageabi.json";
import walletMxin from "@/pages/mixin/walletMxin";
export default {
  mixins: [walletMxin],
  layout: "t3Game",
  data() {
    return {
      sadValue: 0, // 悲情值
    };
  },
  async created() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      await this.watchAccountChange();
    }
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      await this.fetchSadValue();
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 获取悲情值
     */
    async fetchSadValue() {
      let ethContract = new this.$web3.eth.Contract(
        herostorageabi,
        this.$herostorageabiAddress
      );
      let data = await ethContract.methods
        .getUserLuckyValue(this.currentAccount)
        .call();
      this.sadValue = Number(data);
      console.log("悲情值：", this.sadValue);
    },
  },
};
</script>

<style lang="scss" scoped>
.sorrow-value {
  width: 100%;
  padding: 0 15px;

  .panel-board {
    width: 100%;
    height: 200px;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px 33px;
    background-image: url("@/assets/images/game/t3/sorrow-value-bg.png");
    background-size: 100% 100%;

    .total {
      span {
        font-family: PingFang SC;
        font-weight: bold;
        color: #ffffff;

        &:nth-child(1) {
          font-size: 30px;
        }

        &:nth-child(2) {
          font-size: 14px;
        }
      }
    }

    .btn-group {
      margin-top: 30px;
      width: 100%;
      display: flex;
      flex-direction: column;

      .btn {
        width: 100%;
        height: 40px;
        line-height: 40px;
        border-radius: 5px;
        font-size: 14px;
        font-family: PingFang SC;
        font-weight: 400;
        color: #ffffff;
        text-align: center;

        &:nth-child(1) {
          background: rgba(255, 255, 255, 0.3);
        }

        &:nth-child(2) {
          margin-top: 10px;
          background: rgba(255, 255, 255, 0);
          border: 1px solid #ffffff;
        }
      }
    }
  }

  .question-list {
    margin-top: 10px;
    width: 100%;
    display: flex;
    flex-direction: column;

    .question-item {
      display: flex;
      flex-direction: column;
      padding: 20px 0;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);

      .question {
        font-size: 16px;
        font-family: PingFang SC;
        font-weight: 400;
        line-height: 22px;
        color: #ffffff;

        &::before {
          content: "";
          display: inline-block;
          width: 5px;
          height: 22px;
          background: url("@/assets/images/game/t3/line-icon.png") no-repeat;
          background-size: 100% 100%;
          margin-right: 10px;
        }
      }

      .answer {
        margin-top: 10px;
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        line-height: 20px;
        color: rgba(255, 255, 255, 0.5);
      }

      .table-content {
        margin-top: 10px;
        width: 100%;
        display: flex;
        flex-direction: column;

        .table-header {
          padding: 0 15px;
          height: 60px;
          background: linear-gradient(180deg, #00d5ff 0%, #0044ff 100%);
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: space-between;

          p {
            font-size: 12px;
            font-family: PingFang SC;
            font-weight: 400;
            color: #ffffff;
            text-align: center;
            width: 100%;

            &:nth-child(1) {
              width: 33%;
              text-align: left;
            }

            &:nth-child(2) {
              width: 33%;
              text-align: center;
            }

            &:nth-child(3) {
              width: 33%;
              text-align: right;
            }
          }
        }

        .table-row {
          margin-bottom: 5px;
          padding: 0 15px;
          height: 40px;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: space-between;
          background: rgba(255, 255, 255, 0.1);

          p {
            width: 100%;
            font-size: 12px;
            font-family: PingFang SC;
            font-weight: 400;
            color: #ffffff;
            opacity: 0.5;

            &:nth-child(1) {
              width: 21%;
              text-align: left;
            }

            &:nth-child(2) {
              width: 40%;
              text-align: center;
            }

            &:nth-child(3) {
              width: 21%;
              text-align: right;
            }
          }
        }
      }
    }
  }
}

/* 浏览器可视宽度大于600px */
@media only screen and (min-width: 600px) {
  .sorrow-value {
    .panel-board {
      height: 280px;

      .total {
        span {
          &:nth-child(1) {
            font-size: 40px;
          }

          &:nth-child(2) {
            font-size: 24px;
          }
        }
      }

      .btn-group {
        margin-top: 30px;

        .btn {
          height: 50px;
          line-height: 50px;
          font-size: 22px;

          &:nth-child(1) {
          }

          &:nth-child(2) {
            margin-top: 15px;
          }
        }
      }
    }

    .question-list {
      margin-top: 20px;

      .question-item {
        padding: 20px 0;

        .question {
          font-size: 24px;
          line-height: 32px;

          &::before {
            width: 5px;
            height: 30px;
            margin-right: 10px;
          }
        }

        .answer {
          font-size: 18px;
          line-height: 30px;
        }

        .table-content {
          .table-header {
            height: 70px;

            p {
              font-size: 18px;

              &:nth-child(1) {
              }

              &:nth-child(2) {
              }

              &:nth-child(3) {
              }
            }
          }

          .table-row {
            height: 50px;

            p {
              font-size: 18px;

              &:nth-child(1) {
              }

              &:nth-child(2) {
              }

              &:nth-child(3) {
              }
            }
          }
        }
      }
    }
  }
}
</style>