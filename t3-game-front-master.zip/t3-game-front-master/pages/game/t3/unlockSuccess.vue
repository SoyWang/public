<template>
  <!-- 解锁成功 -->
  <div class="unlock-success">
    <img class="icon" src="@/assets/images/game/t3/success-icon.png" alt="" />
    <p class="tips">{{ $t("game.t3.index.unlockResult.successText") }}</p>
    <div class="go-home-btn" @click="$router.go(-1)">
      {{ $t("game.t3.index.unlockResult.goBackHomeBtnText") }}
    </div>
  </div>
</template>

<script>
export default {
  layout: "t3Game",
  data() {
    return {};
  },
};
</script>

<style lang="scss" scoped>
.unlock-success {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0 15px;

  .icon {
    margin-top: 111px;
    width: 135px;
    height: 135px;
  }

  .tips {
    padding: 0 43px;
    margin-top: 20px;
    height: 22px;
    font-size: 16px;
    font-family: PingFang SC;
    font-weight: bold;
    line-height: 22px;
    color: #ffffff;
  }

  .go-home-btn {
    margin-top: 150px;
    width: 100%;
    height: 40px;
    line-height: 40px;
    text-align: center;
    background: linear-gradient(180deg, #00d5ff 0%, #0044ff 100%);
    border-radius: 5px;
    font-size: 16px;
    font-family: PingFang SC;
    font-weight: bold;
    color: #ffffff;
  }
}

/* 浏览器可视宽度大于600px */
@media only screen and (min-width: 600px) {
  .unlock-success {
    padding: 0 15px;

    .icon {
      margin-top: 211px;
      width: 200px;
      height: 200px;
    }

    .tips {
      margin-top: 30px;
      height: 32px;
      font-size: 24px;
      line-height: 32px;
    }

    .go-home-btn {
      margin-top: 150px;
      height: 55px;
      line-height: 55px;
      font-size: 22px;
    }
  }
}
</style>