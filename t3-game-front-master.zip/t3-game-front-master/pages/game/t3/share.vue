<template>
  <!-- 分享 -->
  <div class="share">
    <div class="share-panel-board">
      <img class="bg" src="@/assets/images/game/t3/share-bg.png" alt="" />
      <div class="content">
        <p class="link">{{ $t("game.t3.share.linkText") }}{{ invitLink }}</p>
        <div class="btn" @click="createShareQrCode">
          {{ $t("game.t3.share.shareBtnText") }}
        </div>
        <div class="btn copy-btn" ref="copyBtn" @click="handleCopyInvitLink">
          {{ $t("game.t3.share.copyBtnText") }}
        </div>
      </div>
    </div>

    <!-- 进度条 -->
    <div class="progress">
      <p class="number" :style="{ left: progressValue - 12 + '%' }">
        {{ progressValue }}% F3Cash
      </p>
      <van-progress
        color="linear-gradient(90deg, #00D5FF 0%, #0044FF 100%)"
        track-color="rgba(255,255,255,0.1)"
        :percentage="progressValue"
        stroke-width="10"
        :show-pivot="false"
      />
      <div class="desc">
        <p>0%</p>
        <!-- <p>{{ $t('game.t3.share.progressText') }}</p> -->
        <p>100%</p>
      </div>
    </div>

    <!-- 分享介绍 -->
    <div class="share-introduce">
      <p class="title">
        <span class="line-left"></span>
        <span class="text">{{ $t("game.t3.share.shareTitle") }}</span>
        <span class="line-right"></span>
      </p>
      <p class="sub-title">{{ $t("game.t3.share.ruleText") }}</p>
      <!-- <div class="introduce-list">
        <div class="introduce-item" v-for="(item, index) in $t('game.t3.share.introduceListText')" :key="index">
          <img class="icon" src="@/assets/images/game/t3/circle-icon.png" alt="">
          <p class="text">{{ item }}</p>
        </div>
      </div> -->
    </div>

    <!-- 二维码弹框 -->
    <van-popup v-model="showQrCodePopup" @closed="onCloseQrCodePopup">
      <div class="qr-code-container">
        <div class="qr-code" ref="qrCode"></div>
        <!-- <div class="qr-code" ref="qrCode" @click="saveQrCode"></div> -->
        <!-- <p class="tips">点击二维码即可下载</p> -->
      </div>
    </van-popup>
  </div>
</template>

<script>
import walletMxin from "@/pages/mixin/walletMxin";
export default {
  mixins: [walletMxin],
  layout: "t3Game",
  data() {
    return {
      progressValue: 0, // 进度条进度值
      invitLink: null, // 邀请链接
      showQrCodePopup: false, // 是否展示二维码
    };
  },
  async created() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      this.setProgressValue();
      this.createInviteLink();
    }
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      this.createInviteLink();
    },

    /**
     * 生成邀请链接
     */
    createInviteLink() {
      this.invitLink =
        window.location.origin + "/game/t3?address=" + this.currentAccount;
      this.parentAddress = this.$route.query.address;
    },

    /**
     * 生成分享二维码图片
     */
    createShareQrCode() {
      this.showQrCodePopup = true;
      this.$nextTick(() => {
        new QRCode(this.$refs.qrCode, {
          // 显示二维码的元素或该元素的 ID
          text: this.invitLink, // 内容可以是文字，链接，邮箱
          width: 200, //设置宽度
          height: 200, // 设置高度
          colorDark: "black", // 设置前景色
          colorLight: "white", // 设置背景色
          correctLevel: QRCode.CorrectLevel.L, // 设置容错级别，上面有介绍
        });
      });
    },

    /**
     * 关闭二维码弹框时触发
     */
    onCloseQrCodePopup() {
      // 删除二维码
      this.$refs.qrCode.innerHTML = "";
    },

    /**
     * 保存二维码图片
     */
    saveQrCode() {
      let qrCode = this.$refs.qrCode;
      let base64 = qrCode.children[1].getAttribute("src");
      var arr = base64.split(",");
      var bytes = atob(arr[1]);
      let ab = new ArrayBuffer(bytes.length);
      let ia = new Uint8Array(ab);
      for (let i = 0; i < bytes.length; i++) {
        ia[i] = bytes.charCodeAt(i);
      }
      var blob = new Blob([ab], { type: "application/octet-stream" });
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url;
      a.download = new Date().valueOf() + ".png";
      var e = document.createEvent("MouseEvents");
      e.initMouseEvent(
        "click",
        true,
        false,
        window,
        0,
        0,
        0,
        0,
        0,
        false,
        false,
        false,
        false,
        0,
        null
      );
      a.dispatchEvent(e);
      URL.revokeObjectURL(url);
    },

    /**
     * 复制邀请链接
     */
    handleCopyInvitLink() {
      let oInput = document.createElement("input");
      oInput.value = this.invitLink;
      document.body.appendChild(oInput);
      oInput.select();
      document.execCommand("Copy");
      this.$toast.success(this.$i18n.tc("game.t3.tips.toast.copySuccessText"));
      oInput.remove();
      this.$refs.copyBtn.style.cssText = "background: rgba(255,255,255,0.2);";
    },

    /**
     * 进度条动画
     */
    setProgressValue() {
      let timer;
      timer = setInterval(() => {
        if (this.progressValue == 80) {
          clearInterval(timer);
        } else {
          this.progressValue += 1;
        }
      }, 15);
    },
  },
};
</script>

<style lang="scss" scoped>
.share {
  width: 100%;

  // 分享面板
  .share-panel-board {
    margin: 25px 20px;
    margin-top: 0;
    height: 350px;
    display: flex;
    flex-direction: column;
    position: relative;

    .bg {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    }

    .content {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: flex-end;
      text-align: center;
      padding: 20px 33px;

      .link {
        width: 100%;
        height: 17px;
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        line-height: 17px;
        color: #ffffff;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }

      .btn {
        margin-top: 10px;
        height: 40px;
        border-radius: 5px;
        font-size: 14px;
        font-family: PingFang SC;
        font-weight: bold;
        line-height: 40px;
        color: #ffffff;
        background: linear-gradient(180deg, #00d5ff 0%, #0044ff 100%);
      }

      .copy-btn {
        background: linear-gradient(180deg, #ffcb91 0%, #ff671c 100%);
      }
    }
  }

  // 进度条
  .progress {
    margin: 0 15px;
    margin-top: 80px;
    position: relative;

    .number {
      position: absolute;
      top: -40px;
      text-align: center;
      width: 80px;
      height: 30px;
      background: url("@/assets/images/game/t3/progress-bg.png") no-repeat;
      background-size: 100% 100%;
      font-size: 13px;
      font-family: PingFang SC;
      font-weight: 400;
      line-height: 25px;
      color: #ffffff;
    }

    .desc {
      margin-top: 10px;
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      font-size: 14px;
      font-family: PingFang SC;
      font-weight: 400;
      line-height: 20px;
      color: #ffffff;

      p {
        text-align: center;
        max-width: 166px;
      }
    }
  }

  // 分享规则
  .share-introduce {
    margin: 0 15px;
    display: flex;
    flex-direction: column;
    align-items: center;

    .title {
      height: 22px;
      margin-top: 30px;
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;

      .text {
        width: 35%;
        font-size: 16px;
        font-family: PingFang SC;
        font-weight: 400;
        text-align: center;
        color: #ffffff;
      }

      .line-left {
        width: 100px;
        height: 2px;
        background: linear-gradient(270deg, #ffffff 0%, #000f25 100%);
        opacity: 1;
        border-radius: 1px;
      }

      .line-right {
        width: 100px;
        height: 2px;
        background: linear-gradient(90deg, #ffffff 0%, #000f25 100%);
        opacity: 1;
        border-radius: 1px;
      }
    }

    .sub-title {
      margin-top: 10px;
      font-size: 12px;
      font-family: PingFang SC;
      font-weight: 400;
      line-height: 17px;
      color: #ffffff;
    }

    .introduce-list {
      display: flex;
      flex-direction: column;
      width: 100%;
      margin-top: 15px;
      margin-bottom: 30px;

      .introduce-item {
        display: flex;
        flex-direction: row;
        margin-top: 15px;

        .icon {
          margin-top: 4px;
          width: 10px;
          height: 10px;
        }

        .text {
          margin-left: 5px;
          font-size: 12px;
          font-family: PingFang SC;
          font-weight: 400;
          line-height: 17px;
          color: rgba(255, 255, 255, 0.5);
        }
      }
    }
  }

  // 二维码弹框
  .qr-code-container {
    padding: 10px;
    width: 220px;
    background-color: #fff;
    display: flex;
    flex-direction: column;
    align-items: center;

    .tips {
      font-size: 13px;
      font-family: PingFang SC;
      font-weight: 400;
      color: #5a5a5a;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
  }
}

/* 浏览器可视宽度大于600px */
@media only screen and (min-width: 600px) {
  .share {
    // 分享面板
    .share-panel-board {
      height: 650px;

      .bg {
      }

      .content {
        padding: 40px 33px;

        .link {
          height: 27px;
          font-size: 20px;
          line-height: 27px;
        }

        .btn {
          margin-top: 20px;
          height: 55px;
          font-size: 20px;
          line-height: 55px;
        }

        .copy-btn {
        }
      }
    }

    // 进度条
    .progress {
      margin-top: 90px;

      .number {
        top: -55px;
        width: 140px;
        height: 45px;
        font-size: 21px;
        line-height: 35px;
      }

      .desc {
        margin-top: 10px;
        font-size: 21px;
        line-height: 30px;

        p {
          max-width: 250px;
        }
      }
    }

    // 分享规则
    .share-introduce {
      margin: 0 15px;

      .title {
        height: 32px;
        margin-top: 50px;

        .text {
          width: 25%;
          font-size: 24px;
        }

        .line-left {
          width: 45vw;
          height: 4px;
        }

        .line-right {
          width: 45vw;
          height: 4px;
        }
      }

      .sub-title {
        margin-top: 20px;
        font-size: 18px;
        line-height: 27px;
      }

      .introduce-list {
        display: flex;
        flex-direction: column;
        width: 100%;
        margin-top: 15px;
        margin-bottom: 30px;

        .introduce-item {
          display: flex;
          flex-direction: row;
          margin-top: 15px;

          .icon {
            margin-top: 4px;
            width: 10px;
            height: 10px;
          }

          .text {
            margin-left: 5px;
            font-size: 12px;
            font-family: PingFang SC;
            font-weight: 400;
            line-height: 17px;
            color: rgba(255, 255, 255, 0.5);
          }
        }
      }
    }

    // 二维码弹框
    .qr-code-container {
      padding: 10px;
      width: 220px;
      background-color: #fff;
      display: flex;
      flex-direction: column;
      align-items: center;

      .tips {
        font-size: 13px;
        font-family: PingFang SC;
        font-weight: 400;
        color: #5a5a5a;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }
  }
}
</style>