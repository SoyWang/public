<template>
  <!-- 充值成功 -->
  <div class="recharge-success">
    <img class="icon" src="@/assets/images/game/t3/success-icon.png" alt="">
    <p class="tips">{{ $t('game.t3.recharge.rechargeSuccessText') }}</p>
    <p class="message">{{ $t('game.t3.recharge.rechargeSuccessTipsText') }}</p>
    <div class="btn-group">
      <div class="btn" @click="$router.replace('/game/t3/mineIncome')">{{ $t('game.t3.recharge.findBalanceBtnText') }}
      </div>
      <div class="btn" @click="$router.replace('/game/t3?showUnlockStarPopup=true')">{{
      $t('game.t3.recharge.lockStarBtnText')
      }}</div>
    </div>
  </div>
</template>

<script>
export default {
  layout: 't3Game',
  data() {
    return {};
  },
};
</script>

<style lang="scss" scoped>
.recharge-success {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0 15px;

  .icon {
    margin-top: 111px;
    width: 135px;
    height: 135px;
  }

  .tips {
    padding: 0 43px;
    margin-top: 20px;
    height: 22px;
    font-size: 16px;
    font-family: PingFang SC;
    font-weight: bold;
    line-height: 22px;
    color: #ffffff;
  }

  .message {
    text-align: center;
    padding: 0 43px;
    margin-top: 10px;
    font-size: 14px;
    font-family: PingFang SC;
    font-weight: 400;
    line-height: 20px;
    color: #ffffff;
    opacity: 0.5;
  }

  .btn-group {
    width: 100%;
    margin-top: 100px;
    display: flex;
    flex-direction: row;
    justify-content: space-between;

    .btn {
      width: 47%;
      height: 40px;
      line-height: 40px;
      text-align: center;
      border-radius: 5px;
      font-size: 16px;
      font-family: PingFang SC;
      font-weight: bold;
      color: #ffffff;
      background: rgba(255, 255, 255, 0.39);

      &:nth-child(2) {
        background: linear-gradient(180deg, #00d5ff 0%, #0044ff 100%);
      }
    }
  }
}

/* 浏览器可视宽度大于600px */
@media only screen and (min-width: 600px) {
  .recharge-success {
  padding: 0 15px;

  .icon {
    margin-top: 211px;
    width: 200px;
    height: 200px;
  }

  .tips {
    margin-top: 30px;
    height: 32px;
    font-size: 24px;
    line-height: 32px;
  }

  .message {
    margin-top: 15px;
    font-size: 20px;
    line-height: 30px;
  }

  .btn-group {
    margin-top: 100px;

    .btn {
      height: 55px;
      line-height: 55px;
      font-size: 22px;

      &:nth-child(2) {
      }
    }
  }
}
}
</style>