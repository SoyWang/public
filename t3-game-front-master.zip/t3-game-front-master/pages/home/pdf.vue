<template>
  <div>
    <iframe
      height="100%"
      width="100%"
      src="https://test123321123321123321321.oss-cn-beijing.aliyuncs.com/file.pdf"
    ></iframe>
  </div>
</template>
  <script>
export default {};
</script>
  <style scoped>
div {
  width: 100vw;
  overflow: hidden;
  height: 100vh;
}
</style>
  