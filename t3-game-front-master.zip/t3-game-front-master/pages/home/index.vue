<template>
  <div class="home" ref="top">
    <!-- 横幅 -->
    <div class="banner-container">
      <p class="title">{{ $t("home.banner.title") }}</p>
      <p class="sub-title">{{ $t("home.banner.subTitle") }}</p>
      <p class="introduce">{{ $t("home.banner.introduce") }}</p>
      <div class="join-btn">
        <p>{{ $t("home.banner.btnText") }}</p>
        <img src="@/assets/images/home/banner/join-btn-icon.png" alt="" />
      </div>
      <div class="video-box">
        <video class="video" controls>
          <source src="" type="video/mp4" />
        </video>
      </div>
    </div>

    <!-- 关于 -->
    <div class="about-container">
      <div class="about-content">
        <div class="about-title">
          <p class="title">{{ $t("home.about.title") }}</p>
          <p class="sign"></p>
        </div>
        <div class="about-list">
          <div
            class="about-item"
            v-for="(item, index) in $t('home.about.functionList')"
            :key="index"
          >
            <p class="text">{{ item }}</p>
            <img
              class="icon"
              src="@/assets/images/home/about/arrow-right-icon.png"
              alt=""
            />
            <img
              v-if="index == 0"
              class="icon"
              src="@/assets/images/home/about/arrow-right2-icon.png"
              alt=""
            />
          </div>
        </div>
        <div class="about-description">
          <p class="title">{{ $t("home.about.descriptionTitle") }}</p>
          <p class="description">{{ $t("home.about.descriptionContent") }}</p>
          <p class="tips">{{ $t("home.about.copyTips") }}</p>
          <div class="code-box">
            <p class="code-label">Contract:</p>
            <!-- <p class="code">{{ codeText }}</p> -->
            <p class="code">Coming Soon</p>
            <img
              class="icon"
              src="@/assets/images/home/about/copy-icon.png"
              alt=""
            />
          </div>
          <div class="copy-btn" @click="handleCopyCode">
            {{ $t("home.about.copyBtnText") }}
          </div>
        </div>
        <div class="about-introduce">
          <div class="introduce">
            {{ $t("home.about.answerText") }}
          </div>
        </div>
      </div>
    </div>

    <!-- 俱乐部 -->
    <div class="club-container">
      <div class="club-content">
        <div class="club-title">
          <p class="title">{{ $t("home.club.title") }}</p>
          <p class="sign"></p>
        </div>
        <p class="club-description">{{ $t("home.club.description") }}</p>
        <div class="club-list">
          <!-- 俱乐部列表1 -->
          <div class="club-item club-item-one">
            <div class="header" @click="showClubListOne = !showClubListOne">
              <p class="text">{{ $t("home.club.clubListOne.title") }}</p>
              <img
                class="icon"
                :src="
                  showClubListOne
                    ? require('@/assets/images/home/club/arrow-top-icon.png')
                    : require('@/assets/images/home/club/arrow-bottom-icon.png')
                "
                alt=""
              />
            </div>
            <div class="content" v-if="showClubListOne">
              <div class="module-list">
                <van-swipe
                  :loop="false"
                  :show-indicators="false"
                  :width="100"
                  ref="swiperOne"
                  :initial-swipe="swiperCurrentIndexOne"
                >
                  <van-swipe-item
                    v-for="(item, index) in $t('home.club.clubListOne.list')"
                    :key="index"
                  >
                    <div class="module-item">
                      <p class="title">{{ item.text }}</p>
                      <p class="divider"></p>
                      <p class="label">{{ item.label }}</p>
                      <img
                        v-if="item.path"
                        class="icon"
                        src="@/assets/images/home/club/cricle-button-icon.png"
                        alt=""
                        @click="$router.push(item.path)"
                      />
                    </div>
                  </van-swipe-item>
                  <!-- 空元素 -->
                  <van-swipe-item>
                    <div class="empty-module-item"></div>
                  </van-swipe-item>
                </van-swipe>
                <!-- <img
                  v-if="true"
                  @click="handleSwitchSwiper('swiperOne')"
                  class="switch-icon"
                  src="@/assets/images/home/club/switch-icon.png"
                  alt=""
                /> -->
              </div>
            </div>
          </div>
          <!-- 俱乐部列表2 -->
          <div class="club-item club-item-two">
            <div class="header" @click="showClubListTwo = !showClubListTwo">
              <p class="text">{{ $t("home.club.clubListTwo.title") }}</p>
              <img
                class="icon"
                :src="
                  showClubListTwo
                    ? require('@/assets/images/home/club/arrow-top-icon.png')
                    : require('@/assets/images/home/club/arrow-bottom-icon.png')
                "
                alt=""
              />
            </div>
            <div class="content" v-if="showClubListTwo">
              <div class="module-list">
                <van-swipe
                  :loop="false"
                  :show-indicators="false"
                  :width="100"
                  ref="swiperTwo"
                  :initial-swipe="swiperCurrentIndexTwo"
                >
                  <van-swipe-item
                    v-for="(item, index) in $t('home.club.clubListTwo.list')"
                    :key="index"
                  >
                    <div class="module-item">
                      <p class="title1">{{ item.text1 }}</p>
                      <p class="title2">{{ item.text2 }}</p>
                      <img
                        v-if="item.path"
                        class="icon"
                        src="@/assets/images/home/club/cricle-button-icon.png"
                        alt=""
                      />
                    </div>
                  </van-swipe-item>
                  <!-- 空元素 -->
                  <van-swipe-item>
                    <div class="empty-module-item"></div>
                  </van-swipe-item>
                </van-swipe>
                <!-- <img
                  v-if="true"
                  @click="handleSwitchSwiper('swiperTwo')"
                  class="switch-icon"
                  src="@/assets/images/home/club/switch-icon.png"
                  alt=""
                /> -->
              </div>
            </div>
          </div>
          <!-- 俱乐部列表3 -->
          <div class="club-item club-item-three">
            <div class="header" @click="showClubListThree = !showClubListThree">
              <p class="text">{{ $t("home.club.clubListThree.title") }}</p>
              <img
                class="icon"
                :src="
                  showClubListThree
                    ? require('@/assets/images/home/club/arrow-top-icon.png')
                    : require('@/assets/images/home/club/arrow-bottom-icon.png')
                "
                alt=""
              />
            </div>
            <div class="content" v-if="showClubListThree">
              <div class="module-list">
                <div
                  class="module-item"
                  v-for="(item, index) in $t('home.club.clubListThree.list')"
                  :key="index"
                >
                  <p class="title1">{{ item.text1 }}</p>
                  <p class="title2">{{ item.text2 }}</p>
                  <img
                    v-if="item.path"
                    class="icon"
                    src="@/assets/images/home/club/cricle-button-icon.png"
                    alt=""
                  />
                </div>
                <img
                  v-if="false"
                  class="switch-icon"
                  src="@/assets/images/home/club/switch-icon.png"
                  alt=""
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 路线 -->
    <div class="route-container">
      <div class="route-content">
        <div class="route-title">
          <p class="title">{{ $t("home.route.title") }}</p>
          <p class="sign"></p>
        </div>
        <!-- 路线图1 -->
        <div class="route-stage route-first-stage">
          <div class="stage-list">
            <div
              class="stage-item"
              v-for="(item, index) in $t('home.route.firstStageList')"
              :key="index"
            >
              <template v-if="index == 4">
                <p class="number">1</p>
                <p class="label">{{ $t("home.route.firstStageText") }}</p>
              </template>
              <template v-else>
                <img
                  :class="[
                    'icon',
                    index == 2 || index == 5 ? 'icon-bottom' : '',
                    index == 7 || index == 8 ? 'icon-left' : '',
                    index == 3 || index == 6 ? 'icon-top' : '',
                  ]"
                  :src="
                    item.active
                      ? require('@/assets/images/home/route/arrow-active-icon.png')
                      : require('@/assets/images/home/route/arrow-disabled-icon.png')
                  "
                  alt=""
                />
                <p :class="['text', item.active ? 'active-text' : '']">
                  {{ item.title }}
                </p>
              </template>
            </div>
          </div>
        </div>
        <!-- 播放按钮 -->
        <div class="play-icon">
          <img
            class="icon"
            src="@/assets/images/home/route/play-icon.png"
            alt=""
          />
        </div>
        <!-- 路线图2 -->
        <div class="route-stage route-second-stage">
          <div class="stage-list">
            <div
              class="stage-item"
              v-for="(item, index) in $t('home.route.secondStageList')"
              :key="index"
            >
              <template v-if="index == 4">
                <p class="number">1</p>
                <p class="label">{{ $t("home.route.secondStageText") }}</p>
              </template>
              <template v-else>
                <img
                  :class="[
                    'icon',
                    index == 2 || index == 5 ? 'icon-bottom' : '',
                    index == 7 || index == 8 ? 'icon-left' : '',
                    index == 3 || index == 6 ? 'icon-top' : '',
                  ]"
                  :src="
                    item.active
                      ? require('@/assets/images/home/route/arrow-active-icon.png')
                      : require('@/assets/images/home/route/arrow-disabled-icon.png')
                  "
                  alt=""
                />
                <p :class="['text', item.active ? 'active-text' : '']">
                  {{ item.title }}
                </p>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 相册 -->
    <div class="photo-container">
      <div class="photo-content">
        <div class="photo-title">
          <p class="title">{{ $t("home.photo.title") }}</p>
          <p class="sign"></p>
        </div>
        <div class="photo-list">
          <div class="photo-item">
            <img
              class="img"
              src="@/assets/images/home/photo/photo1-img.png"
              alt=""
            />
          </div>
          <div class="photo-item">
            <img
              class="img"
              src="@/assets/images/home/photo/photo2-img.png"
              alt=""
            />
          </div>
        </div>
      </div>
    </div>

    <!-- 伙伴 -->
    <div class="partner-container" ref="partner">
      <div class="partner-content">
        <div class="partner-title">
          <p class="title">{{ $t("home.partner.title") }}</p>
          <p class="sign"></p>
        </div>
        <!-- 展示一小部分 -->
        <div class="partner-category" v-if="!showMorePartner">
          <div class="title-box">
            <span></span>
            <p>{{ $t("home.partner.categoryTitleList")[0] }}</p>
            <span></span>
          </div>
          <div class="partner-list">
            <div
              class="partner-item"
              v-for="(item, index) in partnerList[0]"
              :key="index"
              v-if="index < 6"
            >
              <img class="icon" :src="item" alt="" />
            </div>
          </div>
        </div>
        <!-- 全部展示 -->
        <div
          class="partner-category"
          v-else
          v-for="(item, index) in $t('home.partner.categoryTitleList')"
          :key="index"
        >
          <div class="title-box">
            <span></span>
            <p>{{ item }}</p>
            <span></span>
          </div>
          <div class="partner-list">
            <div
              class="partner-item"
              v-for="(item1, index1) in partnerList[index]"
              :key="index1"
            >
              <img class="icon" :src="item1" alt="" />
            </div>
          </div>
        </div>
        <div class="more-btn" @click="showMorePartner = !showMorePartner">
          <img
            :class="['btn', showMorePartner ? 'btn-top' : '']"
            src="../../assets/images/home/partner/arrow-bottom-icon.png"
            alt=""
          />
        </div>
      </div>
    </div>

    <!-- 光圈 -->
    <div class="light-ring-container"></div>

    <!-- 社区 -->
    <!-- <div class="telegram-container" ref="ecosystem">
      <div class="telegram-content">
        <div class="telegram-title">
          <p class="title">{{ $t("home.telegram.title") }}</p>
          <p class="sign"></p>
        </div>
        <div class="telegram-list">
          <div
            class="telegram-item"
            v-for="(item, index) in $t('home.telegram.telegramList')"
            :key="index"
          >
            <img
              v-if="index == 0"
              class="icon"
              src="@/assets/images/home/telegram/earth-icon.png"
              alt=""
            />
            <img
              v-else-if="index == 1"
              class="icon"
              src="@/assets/images/home/telegram/internet-icon.png"
              alt=""
            />
            <img
              v-else-if="index == 2"
              class="icon"
              src="@/assets/images/home/telegram/chinese-icon.png"
              alt=""
            />
            <img
              v-else-if="index == 3"
              class="icon"
              src="@/assets/images/home/telegram/korean-icon.png"
              alt=""
            />
            <img
              v-else-if="index == 4"
              class="icon"
              src="@/assets/images/home/telegram/japanese-icon.png"
              alt=""
            />
            <img
              v-else
              class="icon"
              src="@/assets/images/home/telegram/english-icon.png"
              alt=""
            />
            <p class="divider"></p>
            <p class="title">{{ item }}</p>
          </div>
        </div>
      </div>
    </div> -->

    <!-- 问答 -->
    <div class="question-container">
      <div class="question-content">
        <div class="question-title">
          <p class="title">{{ $t("home.question.title") }}</p>
          <p class="sign"></p>
        </div>
        <div class="question-list" ref="questionList">
          <div
            class="question-item"
            v-for="(item, index) in $t('home.question.questionList')"
            :key="index"
            @click="handleShowQuestionContent($event)"
          >
            <div class="question-header">
              <p class="question">{{ item.question }}</p>
              <img
                class="icon"
                src="@/assets/images/home/question/arrow-cricel-bottom-icon.png"
                alt=""
              />
            </div>
            <p class="answer">{{ item.answer }}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- 加入我们 -->
    <div class="join-us-container" ref="join">
      <img
        class="join-us-banner"
        src="@/assets/images/home/joinus/join-us-banner-img.png"
        alt=""
      />
      <div class="join-us-content">
        <div class="content">
          <p v-for="(item, index) in $t('home.joinUs.introduce1')" :key="index">
            <span v-if="index == 0">F3 ClUB </span>
            {{ item }}
          </p>
          <p class="empty-content"></p>
          <p v-for="(item, index) in $t('home.joinUs.introduce2')" :key="index">
            {{ item }}
          </p>
        </div>
        <div class="join-us-btn">{{ $t("home.joinUs.btnText") }}</div>
      </div>
      <div class="share-content">
        <div class="share-list">
          <a href="https://twitter.com/F3mediaOfficial" target="_blank">
            <img
              class="icon"
              src="@/assets/images/home/joinus/share-twitter-icon.png"
              alt=""
            />
          </a>
          <a href="https://t.me/F3clubofficial" target="_blank">
            <img
              class="icon"
              src="@/assets/images/home/joinus/share-tele-icon.png"
              alt=""
            />
          </a>
          <a href="https://discord.gg/tQtdDZacEf" target="_blank">
            <img
              class="icon"
              src="@/assets/images/home/joinus/share-discord-icon.png"
              alt=""
            />
          </a>
          <a href="F3media.official@gmail.com" target="_blank">
            <img
              class="icon"
              src="@/assets/images/home/joinus/share-video-icon.png"
              alt=""
            />
          </a>
        </div>
      </div>
    </div>

    <!-- 回到顶部按钮 -->
    <div class="go-top-btn-container" @click="handleGotoTop">
      <img
        class="icon"
        src="@/assets/images/home/arrow-back-top-icon.png"
        alt=""
      />
    </div>
  </div>
</template>
<script>
if (process.browser) {
  // 在这里根据环境引入wow.js
  var { WOW } = require("wowjs");
}
export default {
  data() {
    return {
      code: "", // 合约地址
      codeText: "", // 显示的合约地址
      showMorePartner: false, // 是否展示更多合作伙伴
      showClubListOne: false, // 是否展示第一个club列表
      showClubListTwo: false, // 是否展示第一个club列表
      showClubListThree: false, // 是否展示第一个club列表
      partnerList: [
        [
          require("@/assets/images/home/partner/1binance.svg"),
          require("@/assets/images/home/partner/2bscscan.svg"),
          require("@/assets/images/home/partner/3bscnews.svg"),
          require("@/assets/images/home/partner/4certik.svg"),
          require("@/assets/images/home/partner/5coinbase.svg"),
          require("@/assets/images/home/partner/6coinmarketcap.svg"),
          require("@/assets/images/home/partner/7dextools.svg"),
          require("@/assets/images/home/partner/8Geckoterminal.svg"),
          require("@/assets/images/home/partner/9pancakeswap.svg"),
          require("@/assets/images/home/partner/10bitkeep.svg"),
          require("@/assets/images/home/partner/11arken.svg"),
          require("@/assets/images/home/partner/12BKEX.svg"),
          require("@/assets/images/home/partner/13superex.svg"),
          require("@/assets/images/home/partner/14swft.svg"),
          require("@/assets/images/home/partner/15mirror.svg"),
          require("@/assets/images/home/partner/16reddit.svg"),
          require("@/assets/images/home/partner/15mirror.svg"),
          require("@/assets/images/home/partner/17twitter.svg"),
          require("@/assets/images/home/partner/18youtube.svg"),
        ],
        [
          require("@/assets/images/home/partner/1binance.svg"),
          require("@/assets/images/home/partner/2bscscan.svg"),
          require("@/assets/images/home/partner/3bscnews.svg"),
          require("@/assets/images/home/partner/4certik.svg"),
        ],
        [
          require("@/assets/images/home/partner/1binance.svg"),
          require("@/assets/images/home/partner/2bscscan.svg"),
          require("@/assets/images/home/partner/3bscnews.svg"),
          require("@/assets/images/home/partner/4certik.svg"),
        ],
        [
          require("@/assets/images/home/partner/1binance.svg"),
          require("@/assets/images/home/partner/2bscscan.svg"),
          require("@/assets/images/home/partner/3bscnews.svg"),
          require("@/assets/images/home/partner/4certik.svg"),
        ],
        [
          require("@/assets/images/home/partner/1binance.svg"),
          require("@/assets/images/home/partner/2bscscan.svg"),
          require("@/assets/images/home/partner/3bscnews.svg"),
          require("@/assets/images/home/partner/4certik.svg"),
        ],
      ],
    };
  },
  mounted() {
    // 获取合约地址
    this.code = this.$herotonkenabiAddress;
    this.codeText =
      this.$herotonkenabiAddress.substr(0, 12) +
      "..." +
      this.$herotonkenabiAddress.substr(38, this.$herotonkenabiAddress.length);

    // 在页面mounted生命周期里面 根据环境实例化WOW
    if (process.browser) {
      new WOW({
        live: false,
        offset: 0,
      }).init();
    }
  },
  watch: {
    $route: {
      handler() {
        this.handleScrollLocation();
      },
      immediate: true,
    },
  },
  methods: {
    /**
     * 复制内容
     */
    handleCopyCode() {
      let oInput = document.createElement("input");
      oInput.value = this.code;
      document.body.appendChild(oInput);
      oInput.select();
      document.execCommand("Copy");
      this.$toast.success(this.$i18n.tc("home.about.copyCodeSuccess"));
      oInput.remove();
    },

    /**
     * 展示问答内容
     */
    handleShowQuestionContent(event) {
      let currentChild = event.currentTarget;
      let currentParent = this.$refs.questionList;

      // 删除所有子元素的classlei
      for (const child of currentParent.children) {
        if (
          child.classList.length > 1 &&
          child.innerHTML != currentChild.innerHTML
        ) {
          child.classList.remove("question-item-show-answer");
        }
      }

      if (currentChild.classList.length > 1) {
        // 给当前元素删除class类
        currentChild.classList.remove("question-item-show-answer");
      } else {
        // 给当前元素添加class类
        currentChild.classList.add("question-item-show-answer");
      }
    },

    /**
     * 滚动到页面指定位置
     */
    handleScrollLocation() {
      setTimeout(() => {
        this.$nextTick(() => {
          let path = this.$route.query.localtion;
          if (path === "/partner") {
            document.body.scrollTop = document.documentElement.scrollTop =
              this.$refs.partner.offsetTop - 100;
          } else if (path === "/ecosystem") {
            document.body.scrollTop = document.documentElement.scrollTop =
              this.$refs.ecosystem.offsetTop - 100;
          } else if (path === "/join") {
            document.body.scrollTop = document.documentElement.scrollTop =
              this.$refs.join.offsetTop - 100;
          } else {
            document.body.scrollTop = document.documentElement.scrollTop =
              this.$refs.top.offsetTop - 100;
          }
        });
      }, 200);
    },

    /**
     * 打开新窗口
     */
    openNewWindow() {
      window.open(
        `https://viewblock.io/thundercore/address/${this.$herotonkenabiAddress}`,
        "_blank"
      );
    },

    /**
     * 点击回到顶部按钮
     */
    handleGotoTop() {
      let s = document.documentElement.scrollTop;
      // 定时器 每10ms执行一次
      let timer = window.setInterval(function () {
        // 每次走50
        s -= 100;
        //  到顶部后清除定时器  必须清定时器  不然就死循环了
        if (s < 0) {
          window.clearInterval(timer);
        }
        window.scrollTo(0, s);
      }, 10);
    },

    /**
     * 切换轮播
     */
    handleSwitchSwiper(ref) {
      this.$refs[ref].next();
    },
  },
};
</script>

<style lang="scss" scoped>
.home {
  width: 100%;

  // 横幅
  .banner-container {
    width: 100%;
    height: 710px;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0 24px;
    background: url("@/assets/images/home/light-ring-img.png"),
      url("@/assets/images/home/football-img.png"),
      url("@/assets/images/home/banner/banner-bg.png");
    background-repeat: no-repeat;
    background-size: 134px 245px, 108px 103px, 100% 411px;
    background-position: 0 -50px, 98% 10%, 0 18px;

    .title {
      margin-top: 19px;
      height: 68px;
      font-size: 40px;
      font-family: BalooDa-Regular, BalooDa;
      font-weight: 500;
      color: #ffffff;
      line-height: 68px;
      -webkit-text-stroke: 2px #0c0c0c;
    }

    .sub-title {
      height: 24px;
      font-size: 18px;
      font-family: DMSans-Medium, DMSans;
      font-weight: 500;
      color: #ffffff;
      line-height: 24px;
    }

    .introduce {
      margin-top: 23px;
      width: 292px;
      font-size: 14px;
      font-family: DMSans-Regular, DMSans;
      font-weight: 400;
      color: rgba(255, 255, 255, 0.8);
      line-height: 18px;
      text-align: center;
    }

    .join-btn {
      width: 100%;
      margin-top: 40px;
      height: 40px;
      background: #eb662c;
      border-radius: 20px;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: center;
      p {
        font-size: 16px;
        font-family: FaktumTest-Bold, FaktumTest;
        font-weight: bold;
        color: #ffffff;
        margin-right: 6px;
      }

      img {
        margin-top: 3px;
        width: 12px;
        height: 12px;
      }
    }

    .video-box {
      margin-top: 50px;
      width: 100%;
      height: 263px;
      padding: 10px;
      background: url("../../assets/images/home/banner/video-bg.png");
      background-size: 100% 263px;
      .video {
        border-radius: 8px;
        width: 100%;
        height: 100%;
      }
    }
  }

  // 关于
  .about-container {
    margin-top: -90px;
    width: 100%;
    padding: 0 12px;

    .about-content {
      display: flex;
      flex-direction: column;
      width: 100%;
      margin: 0 auto;
      box-sizing: border-box;

      .about-title {
        display: flex;
        flex-direction: row;
        align-items: flex-end;

        .title {
          width: 127px;
          line-height: 35px;
          font-size: 30px;
          font-family: BalooDa-Regular, BalooDa;
          font-weight: 500;
          color: #ffffff;
        }

        .sign {
          margin-bottom: 10px;
          margin-left: -18px;
          width: 8px;
          height: 8px;
          background: #eb662c;
          border-radius: 50%;
        }
      }

      .about-list {
        width: 100%;
        margin-top: 4px;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-between;

        .about-item {
          margin-top: 16px;
          width: 48.5%;
          height: 34px;
          border-radius: 8px;
          background: rgba(255, 255, 255, 0.1);
          border: 1px solid rgba(235, 102, 44, 0.4);
          color: rgba(235, 102, 44, 0.75);
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: space-between;
          padding: 0 10px;

          &:nth-child(1) {
            background: rgba(235, 102, 44, 0.95);
            border-radius: 8px;
            border: 1px solid #eb662c;
            color: rgba(255, 255, 255, 0.9);
          }

          &:nth-child(2) {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid #f66424;
            color: #ff6b2a;
          }

          .text {
            font-size: 16px;
            font-family: DMSans-Regular, DMSans;
            font-weight: 400;
            color: rgba(255, 255, 255, 0.8);
          }

          .icon {
            width: 13px;
            height: 11px;
          }
        }
      }

      .about-description {
        width: 100%;
        height: 283px;
        margin-top: 30px;
        display: flex;
        flex-direction: column;
        align-items: center;
        border: 1px solid #eb662c;
        border-radius: 8px;
        padding: 0 10px;
        position: relative;

        .title {
          margin-top: 12px;
          font-size: 20px;
          font-family: BalooDa-Regular, BalooDa;
          font-weight: 400;
          color: #fff7f4;
          line-height: 31px;
        }

        .description {
          margin-top: 12px;
          width: 271px;
          font-size: 14px;
          font-family: DMSans-Regular, DMSans;
          font-weight: 400;
          color: rgba(255, 255, 255, 0.8);
          line-height: 18px;
          text-align: center;
        }

        .tips {
          margin-top: 16px;
          font-size: 14px;
          font-family: DMSans-Medium, DMSans;
          font-weight: 500;
          color: #ffffff;
          line-height: 18px;
        }

        .code-box {
          margin-top: 12px;
          width: 100%;
          height: 40px;
          border-radius: 8px;
          border: 1px solid #ffffff;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: center;
          padding: 0 12px;

          .code-label {
            font-size: 18px;
            font-family: DMSans-Bold, DMSans;
            font-weight: bold;
            color: rgba(255, 255, 255, 0.9);
            line-height: 24px;
            margin-right: 8px;
          }

          .code {
            font-size: 18px;
            font-family: DMSans-Bold, DMSans;
            font-weight: bold;
            color: #ffffff;
            line-height: 24px;
            margin-right: 8px;
            border-bottom: 1px solid #ffffff;
          }

          .icon {
            width: 16px;
            height: 16px;
          }
        }

        .copy-btn {
          position: absolute;
          bottom: -18px;
          left: 50%;
          transform: translateX(-50%);
          width: 170px;
          height: 34px;
          line-height: 34px;
          text-align: center;
          background: #eb662c;
          border-radius: 8px;
          font-size: 16px;
          font-family: DMSans-Medium, DMSans;
          font-weight: 500;
          color: rgba(255, 255, 255, 0.8);
        }
      }

      .about-introduce {
        margin-top: 40px;
        width: 100%;
        background: url("../../assets/images/home/about/introduce-bg.png")
          no-repeat;
        background-size: 100% 87px;
        background-position: 0 0;
        border-radius: 8px;
        border: 1px solid #eb662c;
        overflow: hidden;

        .introduce {
          margin: 19px;
          margin-top: 96px;
          font-size: 14px;
          font-family: DMSans-Bold, DMSans;
          font-weight: bold;
          color: #ffffff;
          line-height: 18px;
          text-align: center;
        }
      }
    }
  }

  // 俱乐部
  .club-container {
    margin-top: 30px;
    width: 100%;

    .club-content {
      display: flex;
      flex-direction: column;
      width: 100%;
      margin: 0 auto;
      box-sizing: border-box;

      .club-title {
        margin: 0 12px;
        display: flex;
        flex-direction: row;
        align-items: flex-end;

        .title {
          line-height: 35px;
          font-size: 30px;
          font-family: BalooDa-Regular, BalooDa;
          font-weight: 500;
          color: #ffffff;
        }

        .sign {
          margin-bottom: 10px;
          margin-left: 5px;
          width: 8px;
          height: 8px;
          background: #eb662c;
          border-radius: 50%;
        }
      }

      .club-description {
        margin: 0 12px;
        margin-top: 12px;
        font-size: 14px;
        font-family: DMSans-Regular, DMSans;
        font-weight: 400;
        color: rgba(255, 255, 255, 0.8);
        line-height: 18px;
      }

      .club-list {
        width: 100%;
        display: flex;
        flex-direction: column;

        .club-item {
          margin-top: 20px;
          display: flex;
          flex-direction: column;

          .header {
            margin: 0 12px;
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
            height: 36px;
            border-radius: 20px;
            border: 1px solid #eb662c;

            .text {
              margin-right: 7px;
              font-size: 14px;
              font-family: DMSans-Medium, DMSans;
              font-weight: 500;
              color: #eb662c;
            }

            .icon {
              width: 11px;
              height: 12px;
            }
          }

          .content {
            margin-top: 20px;
            display: flex;

            .module-list {
              width: 100%;
              display: flex;
              flex-direction: row;
              align-items: center;
              position: relative;
              padding-left: 13px;

              .van-swipe-item {
                width: 100%;
                display: flex;
                flex-direction: row;
                margin-right: 10px;
              }

              .module-item {
                width: 100%;
                display: flex;
                flex-direction: column;
                align-items: center;
                height: 123px;
                padding: 10px 3px;
                background: url("../../assets/images/home/club/card-bg.png")
                  no-repeat;
                background-size: 100% 100%;
                background-position: 0 0;

                .title {
                  text-align: center;
                  margin-top: 2px;
                  height: 31px;
                  line-height: 31px;
                  font-size: 18px;
                  font-family: BalooDa-Regular, BalooDa;
                  font-weight: 400;
                  color: #ffffff;
                }

                .title1 {
                  text-align: center;
                  font-size: 16px;
                  font-family: BalooDa-Regular, BalooDa;
                  font-weight: 400;
                  color: #ffffff;
                  line-height: 20px;
                }

                .title2 {
                  text-align: center;
                  font-size: 12px;
                  font-family: BalooDa-Regular, BalooDa;
                  font-weight: 400;
                  color: #ffffff;
                  line-height: 20px;
                }

                .divider {
                  margin-top: 10px;
                  width: 100%;
                  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                }

                .label {
                  margin-top: 11px;
                  height: 27px;
                  font-size: 16px;
                  font-family: BalooDa-Regular, BalooDa;
                  font-weight: 400;
                  color: rgba(255, 255, 255, 0.7);
                  line-height: 27px;
                }

                .icon {
                  margin-top: 3px;
                  width: 20px;
                  height: 18px;
                  margin-left: 58%;
                }
              }

              .switch-icon {
                width: 36px;
                height: 36px;
                position: absolute;
                top: 50%;
                left: 85%;
                transform: translateY(-70%);
              }
            }
          }
        }

        .club-item-one {
        }
        .club-item-two {
          .module-item {
            justify-content: center;
          }
        }
        .club-item-three {
          .module-list {
            justify-content: space-between;
            padding-right: 15px;
            .module-item {
              justify-content: center;
              width: 31.4% !important;
            }
          }
        }
      }
    }
  }

  // 路线
  .route-container {
    margin-top: 30px;
    width: 100%;
    padding: 0 12px;

    .route-content {
      display: flex;
      flex-direction: column;
      width: 100%;
      margin: 0 auto;
      box-sizing: border-box;

      .route-title {
        display: flex;
        flex-direction: row;
        align-items: flex-end;

        .title {
          line-height: 35px;
          font-size: 30px;
          font-family: BalooDa-Regular, BalooDa;
          font-weight: 500;
          color: #ffffff;
        }

        .sign {
          margin-bottom: 10px;
          margin-left: 5px;
          margin-bottom: 4px;
          width: 8px;
          height: 8px;
          background: #eb662c;
          border-radius: 50%;
        }
      }

      .route-stage {
        margin-top: 20px;
        width: 100%;
        height: 296px;
        background: url("@/assets/images/home/football-img.png") no-repeat,
          url("@/assets/images/home/route/route-grid-bg.png") no-repeat,
          url("@/assets/images/home/route/route-direction-bg.png") no-repeat;
        background-size: 89px 74px, 100% 100%, 85% 85%;
        background-position: 80% 64px, 0 0, center center;
        background-color: rgba(255, 255, 255, 0.08);

        .stage-list {
          width: 100%;
          height: 100%;
          display: flex;
          flex-direction: row;
          flex-wrap: wrap;

          .stage-item {
            height: 33.333%;
            width: 33.333%;
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
            position: relative;
            padding: 0 20px;

            .icon {
              width: 7px;
              height: 11px;
            }

            .icon-bottom {
              transform: rotate(90deg);
            }

            .icon-left {
              transform: rotate(180deg);
            }

            .icon-top {
              transform: rotate(270deg);
            }

            .text {
              margin-left: 5px;
              // width: 70px;
              font-size: 14px;
              font-family: DMSans-Bold, DMSans;
              font-weight: bold;
              line-height: 16px;
              color: rgba(255, 255, 255, 0.5);
              // text-align: center;
            }

            .active-text {
              color: rgba(255, 255, 255, 0.8);
            }

            .number {
              font-size: 90px;
              font-family: BalooDa-Regular, BalooDa;
              font-weight: 500;
              color: rgba(235, 102, 44, 0.6);
              position: absolute;
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%);
            }

            .label {
              width: 134px;
              height: 46px;
              line-height: 46px;
              background: rgba(216, 216, 216, 0.5);
              border-radius: 8px;
              backdrop-filter: blur(1px);
              font-size: 20px;
              font-family: DMSans-Bold, DMSans;
              font-weight: bold;
              color: #ffffff;
              position: absolute;
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%);
              text-align: center;
            }
          }
        }
      }

      .play-icon {
        width: 100%;
        margin-top: -5px;
        display: flex;
        align-items: center;
        justify-content: center;

        .icon {
          width: 48px;
          height: 48px;
        }
      }

      .route-first-stage {
      }

      .route-second-stage {
        margin-top: -5px;
      }
    }
  }

  // 相册
  .photo-container {
    margin-top: 20px;
    width: 100%;
    padding: 0 12px;

    .photo-content {
      display: flex;
      flex-direction: column;
      width: 100%;
      margin: 0 auto;
      box-sizing: border-box;

      .photo-title {
        display: flex;
        flex-direction: row;
        align-items: flex-end;

        .title {
          line-height: 35px;
          font-size: 30px;
          font-family: BalooDa-Regular, BalooDa;
          font-weight: 500;
          color: #ffffff;
        }

        .sign {
          margin-bottom: 10px;
          margin-left: 5px;
          width: 8px;
          height: 8px;
          background: #eb662c;
          border-radius: 50%;
        }
      }

      .photo-list {
        margin-top: 20px;
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-between;

        .photo-item {
          width: 43.5vw;
          height: 38vw;
          background: #cd5019;
          border-radius: 8px;
          margin-left: 8px;
          margin-top: 8px;

          img {
            margin-left: -8px;
            margin-top: -8px;
            width: 100%;
            height: 100%;
            border-radius: 8px;
            border: 1px solid #eb662c;
          }
        }
      }
    }
  }

  // 伙伴
  .partner-container {
    margin-top: 30px;
    width: 100%;
    padding: 0 12px;
    background: url("../../assets/images/home/partner/line-bg.png") no-repeat;
    background-size: 191px 70px;
    background-position: 125% 15px;

    .partner-content {
      display: flex;
      flex-direction: column;
      width: 100%;
      margin: 0 auto;
      box-sizing: border-box;

      .partner-title {
        display: flex;
        flex-direction: row;
        align-items: flex-end;

        .title {
          width: 127px;
          line-height: 35px;
          font-size: 30px;
          font-family: BalooDa-Regular, BalooDa;
          font-weight: 500;
          color: #ffffff;
        }

        .sign {
          margin-bottom: 10px;
          width: 8px;
          height: 8px;
          background: #eb662c;
          border-radius: 50%;
        }
      }

      .partner-category {
        .title-box {
          margin-top: 16px;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: center;

          span {
            width: 4px;
            height: 4px;
            background: #eb662c;
            border-radius: 50%;
            margin: 0 6px;
          }

          p {
            height: 26px;
            font-size: 20px;
            font-family: DMSans-Medium, DMSans;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.8);
            line-height: 26px;
          }
        }
      }

      .partner-list {
        margin-top: 6px;
        width: 100%;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-between;

        .partner-item {
          margin-top: 10px;
          width: 46vw;
          height: 15vw;
          background: #ffffff;
          border-radius: 8px;
          backdrop-filter: blur(1px);
          display: flex;
          align-items: center;
          justify-content: center;

          .icon {
            width: 75%;
            height: 75%;
          }
        }
      }

      .more-btn {
        width: 19px;
        height: 18px;
        margin: 0 auto;
        margin-top: 23px;

        .more-btn {
          width: 100%;
          height: 100%;
        }

        .btn-top {
          transform: rotate(180deg);
        }
      }
    }
  }

  // 光圈
  .light-ring-container {
    margin-top: -20px;
    width: 52px;
    height: 66px;
    background: #eb662c;
    filter: blur(38px);
  }

  // 社区
  .telegram-container {
    margin-top: -10px;
    width: 100%;
    padding: 0 12px;

    .telegram-content {
      display: flex;
      flex-direction: column;
      width: 100%;
      margin: 0 auto;
      box-sizing: border-box;

      .telegram-title {
        display: flex;
        flex-direction: row;
        align-items: flex-end;

        .title {
          width: 127px;
          line-height: 35px;
          font-size: 30px;
          font-family: BalooDa-Regular, BalooDa;
          font-weight: 500;
          color: #ffffff;
        }

        .sign {
          margin-bottom: 10px;
          margin-left: 5px;
          width: 8px;
          height: 8px;
          background: #eb662c;
          border-radius: 50%;
        }
      }

      .telegram-list {
        margin-top: 14px;
        width: 100%;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-between;

        .telegram-item {
          margin-top: 16px;
          width: 30vw;
          height: 31vw;
          padding: 7px 0;
          display: flex;
          flex-direction: column;
          align-items: center;
          background: url("@/assets/images/home/telegram/card-item-bg.png");
          background-size: 100% 100%;

          .icon {
            width: 30px;
            height: 30px;
          }

          .divider {
            margin-top: 11px;
            width: 100%;
            height: 1px;
            border-bottom: 1px dashed #0c0c0c;
          }

          .title {
            margin-top: 25px;
            height: 18px;
            font-size: 13px;
            font-family: DMSans-Medium, DMSans;
            font-weight: 500;
            color: #0c0c0c;
            line-height: 18px;
          }
        }
      }
    }
  }

  // 问答
  .question-container {
    margin-top: 30px;
    width: 100%;
    padding: 0 12px;

    .question-content {
      display: flex;
      flex-direction: column;
      width: 100%;
      margin: 0 auto;
      box-sizing: border-box;

      .question-title {
        display: flex;
        flex-direction: row;
        align-items: flex-end;

        .title {
          line-height: 35px;
          width: 108px;
          font-size: 30px;
          font-family: BalooDa-Regular, BalooDa;
          font-weight: 500;
          color: #ffffff;
        }

        .sign {
          margin-bottom: 8px;
          margin-left: 5px;
          width: 8px;
          height: 8px;
          background: #eb662c;
          border-radius: 50%;
        }
      }

      .question-list {
        margin-top: 8px;
        width: 100%;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-between;

        .question-item {
          width: 100%;
          display: flex;
          justify-content: center;
          flex-direction: column;
          padding: 6px 10px 6px 12px;
          margin-top: 12px;
          background: rgba(255, 255, 255, 0.08);
          border-radius: 20px;
          border: 1px solid #eb662c;

          .question-header {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;

            .question {
              font-size: 14px;
              font-family: DMSans-Medium, DMSans;
              font-weight: 500;
              color: #eb662c;
              line-height: 18px;
            }

            .icon {
              width: 24px;
              height: 24px;
            }
          }

          .answer {
            font-size: 14px;
            font-family: DMSans-Regular, DMSans;
            font-weight: 400;
            color: rgba(255, 255, 255, 0.8);
            line-height: 18px;
            padding: 12px 0 5px 0;
            display: none;
            margin-top: 6px;
          }
        }

        .question-item-show-answer {
          height: auto;

          .question-header {
            .icon {
              transform: rotate(180deg);
            }
          }

          .answer {
            border-top: 1px solid #eb652c50;
            display: block;
          }
        }
      }
    }
  }

  // 加入我们
  .join-us-container {
    width: 100%;
    margin-top: 20px;
    .join-us-banner {
      width: 100%;
      height: 91px;
    }

    .join-us-content {
      width: 100%;
      height: 284px;
      margin-top: 20px;
      background: url("@/assets/images/home/joinus/join-us-bg.png"),
        url("@/assets/images/home/joinus/arrow-icon.png"),
        url("@/assets/images/home/joinus/football-img.png");
      background-size: 100% 100%, 35px 31px, 229px 215px;
      background-repeat: no-repeat, no-repeat, no-repeat;
      background-position: 0 0, 35% 86%, 95% 50%;
      padding: 0 15px;

      .content {
        padding-top: 51px;

        p {
          font-size: 14px;
          font-family: DMSans-Bold, DMSans;
          font-weight: 400px;
          color: #ffffff;
          line-height: 21px;

          span {
            font-size: 16px;
            font-weight: 900;
          }
        }

        .empty-content {
          margin-top: 10px;
        }
      }

      .join-us-btn {
        display: inline-flex;
        margin-top: 12px;
        padding: 5px 22px;
        background: #eb662c;
        border-radius: 15px;
        font-size: 16px;
        font-family: DMSans-Bold, DMSans;
        font-weight: bold;
        color: #ffffff;
      }
    }

    .share-content {
      width: 100%;
      height: 133px;
      padding-top: 10px;

      .share-list {
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        padding: 20px 80px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.3);

        .icon {
          width: 30px;
          height: 30px;
        }
      }
    }
  }

  // 回到顶部按钮
  .go-top-btn-container {
    position: fixed;
    right: 22px;
    bottom: 30px;
    cursor: pointer;

    .icon {
      width: 54px;
      height: 36px;
    }
  }
}
</style>