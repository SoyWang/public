export default {
    data() {
        return {
            currentAccount: '' // 钱包地址
        };
    },

    methods: {
        /**
         * 获取当前账户地址
         */
        async getCurrentAccount() {
            let currentAccount = await this.$web3.eth.getCoinbase();
            this.currentAccount = currentAccount
            this.$web3.eth.defaultAccount = currentAccount
            console.log("当前账号：", this.currentAccount)
                // 监听账号和网络链切换
            await this.watchMetaMask();
            await this.watchNetworkChain();
        },

        /**
         * 监听钱包账号切换
         */
        async watchMetaMask() {
            window.ethereum.on('accountsChanged', (res) => {
                if (res[0]) {
                    console.log("账号改变：", res)
                    this.currentAccount = res[0]
                    this.$web3.eth.defaultAccount = res[0]
                        // 账号改变触发
                    this.watchAccountChange();
                } else {
                    // 无账户清空数据
                    this.currentAccount = ''
                    this.$web3.eth.defaultAccount = ''
                }
            });
        },

        /**
         * 监听链网络改变
         */
        watchNetworkChain() {
            window.ethereum.on('chainChanged', (res) => {
                console.log("网络链改变：", res)
                this.watchAccountChange();
            });
        },
    },
}