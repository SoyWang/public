<template>
  <div class="partner">

  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  created() {},
  methods: {},
};
</script>

<style lang="scss" scoped>
.partner {
  width: 100%;
}
</style>