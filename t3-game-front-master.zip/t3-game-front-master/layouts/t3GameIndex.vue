<template>
  <div class="t3-game-index" @click="cancelShowLanguage">
    <!-- 头部（移动端） -->
    <template>
      <div class="header-mobile" ref="menuMobile">
        <!-- 顶部logo栏 -->
        <div class="header-top" ref="menuHeader">
          <img
            class="logo"
            src="@/assets/images/layout/logo-blue-icon.png"
            alt=""
            @click="$router.push('/home')"
          />
          <img
            v-show="showCloseIcon"
            class="menu-close-icon"
            @click="handleCloseMobileMenuList"
            ref="menuIcon"
            src="@/assets/images/layout/menu-close-icon.png"
          />
          <img
            v-show="!showCloseIcon"
            class="menu-icon"
            @click="handleShowMobileMenuList"
            ref="menuIcon"
            src="@/assets/images/layout/menu-icon.png"
          />
        </div>

        <!-- 下拉菜单栏 -->
        <div
          class="header-bottom"
          v-show="showMobileMenuList"
          ref="mobileMenu"
          @click="handleCloseMobileMenuList"
        >
          <div class="menu-list" ref="mobileMenuList">
            <div
              v-for="(item, index) in $t('public.menu')"
              :key="index"
              class="menu-item-container"
            >
              <!-- 一级菜单 -->
              <div
                class="menu-item"
                v-if="!item.children"
                @click.stop="handleSkipRouter(item)"
              >
                <div class="title-box">
                  <img
                    v-if="item.icon && item.path == '/game/t3'"
                    class="icon1"
                    src="@/assets/images/layout/t3-logo-icon.png"
                    alt=""
                  />
                  <img
                    v-else-if="item.icon && item.path == '/game/cup'"
                    class="icon2"
                    src="@/assets/images/layout/cup-logo-icon.png"
                    alt=""
                  />
                  <img
                    v-else-if="item.icon && item.path == '/game/augur'"
                    class="icon3"
                    src="@/assets/images/layout/augur-logo-icon.png"
                    alt=""
                  />
                  <p class="title">{{ item.title }}</p>
                </div>
              </div>

              <!-- 二级菜单 -->
              <div class="sub-menu-list" v-else>
                <div
                  :class="[
                    'sub-menu',
                    showSubMenuList ? '' : 'sub-menu-show-divider',
                  ]"
                  @click.stop="showSubMenuList = !showSubMenuList"
                >
                  <p class="title">{{ item.title }}</p>
                  <img
                    class="bottom-icon"
                    v-if="showSubMenuList"
                    src="@/assets/images/layout/arrow-bottom-icon.png"
                    alt=""
                  />
                  <img
                    class="right-icon"
                    v-else
                    src="@/assets/images/layout/arrow-right-icon.png"
                    alt=""
                  />
                </div>
                <div
                  v-if="showSubMenuList"
                  class="sub-menu-item"
                  v-for="(item1, index1) in item.children"
                  :key="index1"
                  @click="handleSkipRouter(item1)"
                >
                  <p class="title">{{ item1.title }}</p>
                </div>
              </div>
            </div>

            <!-- 切换语言 -->
            <div class="menu-item">
              <p class="title">{{ $t("public.languageText") }}</p>
              <div class="language-content">
                <div
                  class="language-name"
                  @click.stop="showLanguageList = !showLanguageList"
                >
                  <p class="text">{{ language }}</p>
                  <div class="icon-box">
                    <img
                      class="bottom-icon"
                      v-if="showLanguageList"
                      src="@/assets/images/layout/arrow-bottom-icon.png"
                      alt=""
                    />
                    <img
                      class="right-icon"
                      v-else
                      src="@/assets/images/layout/arrow-right-icon.png"
                      alt=""
                    />
                  </div>
                </div>
                <div class="language-list" v-show="showLanguageList">
                  <div
                    :class="[
                      'language-item',
                      language == item.text ? 'active-language-item' : '',
                    ]"
                    v-for="(item, index) in languageList"
                    :key="index"
                    @click.stop="handleSwitchLanguage(item)"
                  >
                    <span
                      :class="[
                        'icon',
                        language == item.text ? 'active-icon' : '',
                      ]"
                    ></span>
                    <p>{{ item.text }}</p>
                  </div>
                </div>
              </div>
            </div>

            <!-- 切换模式 -->
            <!-- <div class="menu-item">
              <p class="title">{{ $t('public.nightmodeText') }}</p>
              <img v-show="showLightMode" class="switch-icon" @click.stop="showLightMode = !showLightMode"
                src="@/assets/images/layout/switch-active.png" alt="">
              <img v-show="!showLightMode" class="switch-icon" @click.stop="showLightMode = !showLightMode"
                src="@/assets/images/layout/switch-disabled.png" alt="">
            </div> -->
          </div>
        </div>
      </div>
    </template>

    <!-- 主要内容 -->
    <nuxt />
  </div>
</template>

<script>
import t3GameMixin from "@/layouts/mixin/t3GameMixin";
export default {
  mixins: [t3GameMixin],
  mounted() {
    // 监听菜单滚动事件事件
    this.watchMenuScrollEvent();

    // 设置菜单背景颜色
    this.$nextTick(() => {
      this.setMenuBackgroundColor();
      window.onscroll = () => {
        this.setMenuBackgroundColor();
      };
    });
  },
  watch: {
    // 监听菜单栏下拉状态
    showMobileMenuList(value) {
      let menuHeader = this.$refs.menuHeader;
      if (value) {
        menuHeader.style.cssText =
          "background: linear-gradient(180deg, #000F25 0%, #00388F 100%);";
      } else {
        this.setMenuBackgroundColor();
      }
    },
  },
  destroyed() {
    // 销毁页面监听
    window.onscroll = null;
  },
  methods: {
    /**
     * 设置菜单栏的颜色
     */
    setMenuBackgroundColor() {
      if (document.body.clientWidth <= 600) {
        // 手机端
        this.$nextTick(() => {
          let menuHeader = this.$refs.menuHeader;
          if (window.scrollY > 0) {
            menuHeader.style.cssText =
              "background: linear-gradient(180deg, #000F25 0%, #00388F 100%);";
          } else {
            menuHeader.style.cssText = "background: rgba(0, 0, 0, 0)";
          }
        });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
@import "./mixin/t3GameMixin.scss";
.t3-game-index {
  // 头部（移动端）
  .header-mobile {
    background: transparent;

    .header-top {
      background: transparent;
    }

    .header-bottom {
      .menu-list {
        background-color: #000c1d;
      }
    }
  }
}
</style>