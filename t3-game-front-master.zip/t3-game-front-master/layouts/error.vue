<template>
  <div class="error">
    <img class="error-bg"
         src="@/assets/images/layout/404-bg.png"
         alt="" />
    <p class="error-tips">{{ $t("error.errorTips") }}</p>
  </div>
</template>

<script>
export default {
  props: ['error'],
};
</script>

<style lang="scss" scoped>
.error {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;

  .error-bg {
    margin-top: 69px;
    width: 267px;
    height: 175px;
  }

  .error-tips {
    margin-top: 18px;
    font-size: 16px;
    font-family: DMSans-Medium, DMSans;
    font-weight: 500;
    color: rgba(255, 255, 255, 0.8);
  }
}
</style>
