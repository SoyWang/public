<template>
  <div class="cup-game-index">
    <div class="cup-menu">
      <!-- 菜单头部 -->
      <div class="menu-top">
        <p class="logo" @click="$router.push('/home')">Cup</p>
        <div class="register-box">
          <p class="text" @click="$router.push('/game/cup/register')">
            {{ $t("game.cup.register.title10") }}
          </p>
          <img
            class="menu-icon"
            @click="showMenuPopup = !showMenuPopup"
            src="../assets/images/game/cup/menu-icon.png"
            alt=""
          />
        </div>
      </div>

      <!-- 下拉菜单 -->
      <van-popup
        class="menu-bottom"
        v-model="showMenuPopup"
        position="right"
        :style="{ height: '100vh' }"
      >
        <img
          class="close-icon"
          src="../assets/images/game/cup/menu-close-icon.png"
          alt=""
          @click="showMenuPopup = false"
        />
        <div class="menu-list">
          <div
            class="menu-item-container"
            v-for="(item, index) in $t('game.cup.menu')"
            :key="index"
          >
            <!-- 一级菜单 -->
            <div
              v-if="!item.children"
              class="menu-item"
              @click="handleGoPath(item.path)"
            >
              <div class="item-top">
                <p class="text">{{ item.title }}</p>
              </div>
            </div>
            <!-- 二级菜单 -->
            <div v-else class="menu-item menu-item-two">
              <div
                class="item-top"
                @click="showLanguageList = !showLanguageList"
              >
                <p class="text">{{ item.title }}</p>
                <img
                  :class="['icon', showLanguageList ? 'icon-active' : '']"
                  src="../assets/images/game/cup/menu-arrow-top-icon.png"
                  alt=""
                />
              </div>
              <div class="item-bottom" v-show="showLanguageList">
                <p
                  :class="[
                    'text',
                    language == item2.title ? 'active-text' : '',
                  ]"
                  v-for="(item2, index2) in item.children"
                  :key="index2"
                  @click="handleSwitchLanguage(item2)"
                >
                  {{ item2.title }}
                </p>
              </div>
            </div>
          </div>
        </div>
      </van-popup>
    </div>

    <!-- 主体内容 -->
    <nuxt class="index-content" />
  </div>
</template>
<script>
import cupGameMixin from "@/layouts/mixin/cupGameMixin";
export default {
  mixins: [cupGameMixin],
  data() {
    return {};
  },
  methods: {},
};
</script>

<style lang="scss" scoped>
@import "./mixin/cupGameMixin.scss";
.cup-game-index {
}
</style>
