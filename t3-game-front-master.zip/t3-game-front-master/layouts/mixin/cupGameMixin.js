export default {
    data() {
        return {
            language: 'English', // 当前切换的语言
            showMenuPopup: false, // 是否显示下拉菜单弹窗
            showLanguageList: true, // 是否显示切换语言二级菜单
        };
    },
    methods: {
        /**
         * 切换语言
         */
        handleSwitchLanguage(item) {
            this.$store.commit('SET_LANG', item.value);
            this.language = item.title;
            this.$i18n.locale = item.value;
        },

        /**
         * 切换路由
         */
        handleGoPath(path) {
            this.showMenuPopup = false
            this.showLanguageList = false
            this.$router.push(path)
        }
    },
};