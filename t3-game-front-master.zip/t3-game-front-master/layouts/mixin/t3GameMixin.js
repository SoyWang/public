export default {
    data() {
        return {
            language: 'English', // 当前切换的语言
            showLanguageList: false, // 是否展示语言列表
            languageList: [{
                    text: 'English',
                    value: 'en',
                },
                {
                    text: '繁體中文',
                    value: 'zh',
                },
            ], // 语言列表
            showCloseIcon: false, // 是否展示关闭菜单图标
            showMobileMenuList: false, // 是否展示下拉菜单
            showSubMenuList: false, // 是否展示二级菜单
            showLightMode: true, // 是否展示夜间模式
        };
    },
    async created() {
        // 获取当前切换的语言
        let language = this.$store.state.locale
        let index = this.languageList.findIndex(item => item.value == language)
        this.language = this.languageList[index].text
    },
    methods: {
        /**
         * 点击取消切换语言列表
         */
        cancelShowLanguage() {
            this.showLanguageList = false;
        },

        /**
         * 切换语言
         */
        handleSwitchLanguage(item) {
            this.$store.commit('SET_LANG', item.value)
            this.language = item.text;
            this.$i18n.locale = item.value;
            this.cancelShowLanguage()
        },

        /**
         * 路由跳转
         */
        handleSkipRouter(item) {
            // 拒绝跳转到cup,augura
            // if (item.path == "/game/t3" || item.path == "/game/cup" || item.path == "/game/augur") return

            // 允许跳转的页面
            if (item.skip) {
                // 跳转
                this.$router.push(item.path);
            } else {
                // 滚动
                this.$router.push({
                    path: '/home',
                    query: {
                        localtion: item.path,
                    },
                });
            }
            // 关闭下拉菜单
            this.handleCloseMobileMenuList();
        },

        /**
         * 展示手机端的下拉菜单栏
         */
        handleShowMobileMenuList() {
            // 禁止body滚动
            let body = document.getElementsByTagName('body')[0]
            body.style.cssText = 'overflow: hidden;'

            // 显示下拉菜单
            this.showCloseIcon = true;
            this.showMobileMenuList = true;
            setTimeout(() => {
                this.$refs.mobileMenuList.style.cssText += 'transform: translateY(0);';
                this.$refs.mobileMenu.style.cssText += 'background-color: rgba(0, 0, 0, 0.692);';
            }, 10)
        },

        /**
         * 关闭手机端的下拉菜单栏
         */
        handleCloseMobileMenuList() {
            // 允许body滚动
            let body = document.getElementsByTagName('body')[0]
            body.style.cssText = 'overflow: auto;'

            // 隐藏下拉菜单
            this.showCloseIcon = false;
            this.$refs.mobileMenuList.style.cssText += 'transform: translateY(-100vh);';
            this.$refs.mobileMenu.style.cssText += 'background-color: transparent;'
            setTimeout(() => {
                this.showMobileMenuList = false;
                this.showSubMenuList = false;
            }, 500)
        },

        /**
         * 监听菜单滚动事件事件
         */
        watchMenuScrollEvent() {
            let box = this.$refs.mobileMenu // 监听对象
            let startTime = '' // 触摸开始时间
            let startDistanceX = '' // 触摸开始X轴位置
            let startDistanceY = '' // 触摸开始Y轴位置
            let endTime = '' // 触摸结束时间
            let endDistanceX = '' // 触摸结束X轴位置
            let endDistanceY = '' // 触摸结束Y轴位置
            let moveTime = '' // 触摸时间
            let moveDistanceX = '' // 触摸移动X轴距离
            let moveDistanceY = '' // 触摸移动Y轴距离
            box.addEventListener("touchstart", (e) => {
                startTime = new Date().getTime()
                startDistanceX = e.touches[0].screenX
                startDistanceY = e.touches[0].screenY
            })
            box.addEventListener("touchend", (e) => {
                endTime = new Date().getTime()
                endDistanceX = e.changedTouches[0].screenX
                endDistanceY = e.changedTouches[0].screenY
                moveTime = endTime - startTime
                moveDistanceX = startDistanceX - endDistanceX
                moveDistanceY = startDistanceY - endDistanceY
                    // 判断滑动距离超过40 且 时间小于500毫秒
                if ((Math.abs(moveDistanceX) > 40 || Math.abs(moveDistanceY) > 40) && moveTime < 500) {
                    // 判断X轴移动的距离是否大于Y轴移动的距离
                    if (Math.abs(moveDistanceX) <= Math.abs(moveDistanceY)) {
                        // 上线滑动
                        if (startDistanceY < endDistanceY) {
                            // 下滑
                            this.showSubMenuList = true
                        } else {
                            // 上滑
                            this.showSubMenuList = false
                        }
                    }
                }
            })
        }
    },
}