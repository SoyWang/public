// 打包去除console.log()
let remove_console = []
if (process.env.NODE_ENV === 'production') {
    remove_console.push("transform-remove-console")
}

export default {
    // Global page headers: https://go.nuxtjs.dev/config-head
    loading: { color: '#3B8070' },
    head: {
        title: 'F3 CLUB',
        htmlAttrs: {
            lang: 'en'
        },
        meta: [
            { charset: 'utf-8' },
            { name: 'viewport', content: 'width=device-width, initial-scale=1' },
            { hid: 'description', name: 'description', content: '' },
            { name: 'format-detection', content: 'telephone=no' }
        ],
        link: [
            { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }
        ],
        script: [
            { src: '/qrcode/index.js' }
        ]
    },

    // Global CSS: https://go.nuxtjs.dev/config-css
    css: [
        '@/assets/css/font.scss',
        '@/assets/css/reset.scss',
        "@/assets/css/animate.css",
        "element-ui/lib/theme-chalk/index.css",
        "vant/lib/index.css",
    ],

    // Plugins to run before rendering page: https://go.nuxtjs.dev/config-plugins
    plugins: [
        { src: "@/plugins/ElementUI", ssr: true },
        { src: "@/plugins/Vant", ssr: true },
        { src: "@/static/web3js/index", ssr: false },
        { src: "@/plugins/G2", ssr: false },
        "@/plugins/axios",
        "@/plugins/i18n",
    ],

    // Auto import components: https://go.nuxtjs.dev/config-components
    components: true,

    // Modules for dev and build (recommended): https://go.nuxtjs.dev/config-modules
    buildModules: [],

    // build: {
    //     babel: {
    //         'plugins': remove_console
    //     }
    // },

    // Modules: https://go.nuxtjs.dev/config-modules
    modules: [
        '@nuxtjs/axios'
    ],

    router: {
        extendRoutes(routes, resolve) {
            routes.push({
                name: 'home',
                path: '/',
                component: resolve(__dirname, 'pages/home/index.vue')
            })
        }
    },

    server: {
        port: 7000, // default: 3000
        host: '0.0.0.0' // default: localhost只能用于本机访问，如果需要对外访问需要设置0.0.0.0
    },

    // axios: {
    //     proxy: true,
    //     prefix: '/test/',
    //     credential: true
    // },

    // proxy: {
    //     '/test/': {
    //         target: 'http://192.168.1.14:9999/test/', // 目标服务器ip
    //         pathRewrite: {
    //             '^/test/': '/', // 把 /test 替换成 /
    //             changeOrigin: true // 是否跨域
    //         }
    //     }
    // }
}