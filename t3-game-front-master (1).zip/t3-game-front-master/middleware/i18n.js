export default function({ isHMR, app, store, route, params, error, redirect }) {

    if (isHMR) {
        return
    } else if (!params.lang) {
        return redirect('/zh' + route.fullPath)
    }

    const locale = params.lang || 'zh'

    store.commit('SET_LANG', locale)
    app.i18n.locale = store.state.locale
}