<template>
  <div class="register">
    <!-- 注册区域 -->
    <div class="register-content">
      <p class="title">Graffiti your name on the Blockchain</p>
      <input
        :disabled="userInfo.userName != ''"
        v-model="userInfo.userName"
        class="input"
        type="text"
        placeholder="Kokochi Mikimoto"
      />
      <p class="rule-text">Names must follow these rules:</p>
      <div class="rule-list">
        <p class="rule-item">Must be unique</p>
        <p class="rule-item">32 Characters or less</p>
        <p class="rule-item">A-Z(upper and lowercase)</p>
        <p class="rule-item">No special characters</p>
        <p class="rule-item">No more than one space between characters</p>
      </div>
      <p class="rule-tips">
        If the transaction fails, one of these criteria was not met properly.
      </p>
      <!-- 未注册 -->
      <div
        class="pay-btn"
        @click="verifyRegisterName"
        v-if="userInfo.userName == ''"
      >
        Pay X F3Cash
      </div>
      <!-- 已注册 -->
      <div class="pay-btn disabled" v-else>Registered</div>
      <p class="register-tips">
        The fee is distributed across community members who made this game
        possible.
      </p>
    </div>

    <!-- 注册支付弹窗 -->
    <confirm-payment-popup
      :show="showRegisterPaymentPopup"
      functionType="Register fee"
      :balance="userInfo.balance"
      :price="registerPrice"
      @close="showRegisterPaymentPopup = false"
      @payment="handlePaymentRegister"
    ></confirm-payment-popup>

    <!-- 注册成功弹窗 -->
    <result-popup
      :show="showRegisterSuccessPopup"
      type="success"
      message="注册成功"
      @close="showRegisterSuccessPopup = false"
    ></result-popup>

    <!-- 注册失败弹窗 -->
    <result-popup
      :show="showRegisterFailedPopup"
      type="failed"
      message="注册失败"
      @close="showRegisterFailedPopup = false"
    ></result-popup>

    <!-- 余额不足弹窗 -->
    <no-money-popup
      :show="showNoMoneyPopup"
      @close="showNoMoneyPopup = false"
    ></no-money-popup>
  </div>
</template>

<script>
import ConfirmPaymentPopup from "@/components/cup/ConfirmPaymentPopup";
import ResultPopup from "@/components/cup/ResultPopup";
import NoMoneyPopup from "@/components/cup/NoMoneyPopup";
import walletMxin from "@/pages/mixin/walletMxin";
import playerbookabi from "@/static/web3js/abi/cup/playerbookabi.json";
import fomoabi from "@/static/web3js/abi/cup/fomoabi.json";
import f3cashtokenabi from "@/static/web3js/abi/cup/f3cashtokenabi.json";

import allMatchList from "./data/allMatchData";
export default {
  layout: "cupGame",
  mixins: [walletMxin],
  components: { ConfirmPaymentPopup, ResultPopup, NoMoneyPopup },
  data() {
    return {
      showRegisterPaymentPopup: false, // 是否显示注册支付弹窗
      showRegisterSuccessPopup: false, // 是否展示支付成功弹窗
      showRegisterFailedPopup: false, // 是否展示支付失败弹窗
      showNoMoneyPopup: false, // 是否展示余额不足弹窗
      registerPrice: 1, // 注册费用
      fomoContractAddress: "", // fomo合约合约地址
      userInfo: {
        balance: 0,
        userId: "",
        userName: "",
      }, // 用户信息
      shareInfo: {
        type: 3, // 分享的类型 1 地址分享链接；2 昵称分享链接；3 id分享链接
        address: "", // 上级分享的地址
      }, // 分享信息
    };
  },
  async created() {
    if (this.$route.query.type && this.$route.query.address) {
      this.shareInfo.type = Number(this.$route.query.type);
      this.shareInfo.address = this.$route.query.address;
    }
  },
  async mounted() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      await this.watchAccountChange();
    }
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      // 获取请求数据
      await this.fetchFomoContractAddress();
      await this.fetchUserInfo();
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 验证注册的名称合法性
     */
    verifyRegisterName() {
      // 判断注册名字不能为空
      if (this.userInfo.userName.trim().length == 0) {
        return this.$toast.fail(
          this.$i18n.tc("game.cup.tips.toast.registerNameNoPassText")
        );
      }

      // 判断注册名字长度是否大于32位
      if (this.userInfo.userName.trim().length > 32) {
        return this.$toast.fail(
          this.$i18n.tc("game.cup.tips.toast.registerNameNoPassText")
        );
      }

      // 判断注册名字是否包含英文
      if (!this.userInfo.userName.match(/[a-z]/gi)) {
        return this.$toast.fail(
          this.$i18n.tc("game.cup.tips.toast.registerNameNoPassText")
        );
      }

      // 判断注册名字是否包含特殊字符
      const p = new RegExp(
        "[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]"
      );
      if (p.test(this.userInfo.userName)) {
        return this.$toast.fail(
          this.$i18n.tc("game.cup.tips.toast.registerNameNoPassText")
        );
      }

      this.showRegisterPaymentPopup = true;
    },

    /**
     * 获取fomo合约的地址
     */
    async fetchFomoContractAddress() {
      // todo 发送请求获取所有比赛
      let allMatchData = allMatchList;
      this.fomoContractAddress = allMatchData[0].fomoAddress;
    },

    /**
     * 获取用户信息
     */
    async fetchUserInfo() {
      // 获取用户余额
      let ethContract = new this.$web3.eth.Contract(
        f3cashtokenabi,
        this.$f3cashtokenabiAddress
      );
      let data = await ethContract.methods
        .balanceOf(this.currentAccount)
        .call();
      this.userInfo.balance = Number(
        this.$BigNumber(data).div(Math.pow(10, 18)).toFixed(4).toString(10)
      );

      // 获取用户注册后的id
      ethContract = new this.$web3.eth.Contract(
        playerbookabi,
        this.$playerbookabiAddress
      );
      data = await ethContract.methods.pIDxAddr_(this.currentAccount).call();
      this.userInfo.userId = data;

      // 获取用户注册后的名称
      data = await ethContract.methods.plyr_(this.userInfo.userId).call();
      this.userInfo.userName = this.$web3.utils.hexToUtf8(data.name);
      console.log("用户信息：", this.userInfo);
    },

    /**
     * 支付注册
     */
    async handlePaymentRegister() {
      if (this.userInfo.balance < this.registerPrice) {
        // 注册费用不足
        this.showNoMoneyPopup = true;
      } else {
        // 查询授权金额
        let result = await this.fetchAuthorizationPayMoney();
        if (!result) return;

        // 开始加载动画
        let loading = this.$toast.loading({
          message: "payment...",
          forbidClick: true,
          duration: 0,
          loadingType: "spinner",
          overlay: true,
        });

        // 注册
        let ethContract = new this.$web3.eth.Contract(
          fomoabi,
          this.fomoContractAddress
        );
        try {
          console.log("注册信息：", {
            userName: this.userInfo.userName,
            type: this.shareInfo.type,
            address: this.shareInfo.address,
          });

          let data;
          if (this.shareInfo.type == 1) {
            console.log("根据地址分享链接注册");
            // 根据地址分享链接注册
            data = await ethContract.methods
              .registerNameXaddr(
                this.userInfo.userName,
                this.shareInfo.address,
                this.$BigNumber(this.registerPrice)
                  .times(Math.pow(10, 18))
                  .toString(10),
                true
              )
              .send({
                from: this.currentAccount,
              });
          } else if (this.shareInfo.type == 2) {
            console.log("根据名称分享链接注册");
            // 根据名称分享链接注册
            data = await ethContract.methods
              .registerNameXname(
                this.userInfo.userName,
                this.$web3.utils.toHex(this.shareInfo.address),
                this.$BigNumber(this.registerPrice)
                  .times(Math.pow(10, 18))
                  .toString(10),
                true
              )
              .send({
                from: this.currentAccount,
              });
          } else {
            console.log("根据id分享链接注册（默认）");
            // 根据id分享链接注册（默认）
            data = await ethContract.methods
              .registerNameXID(
                this.userInfo.userName,
                this.shareInfo.address || 0,
                this.$BigNumber(this.registerPrice)
                  .times(Math.pow(10, 18))
                  .toString(10),
                true
              )
              .send({
                from: this.currentAccount,
              });
          }
          await this.fetchUserInfo();
          this.showRegisterSuccessPopup = true;
          console.log(data);
        } catch (err) {
          this.showRegisterFailedPopup = true;
          console.error(err);
        } finally {
          // 关闭加载动画
          loading.clear();
          this.showRegisterPaymentPopup = false;
        }
      }
    },

    /**
     * 查询授权金额的余量
     */
    async fetchAuthorizationPayMoney() {
      let ethContract = new this.$web3.eth.Contract(
        f3cashtokenabi,
        this.$f3cashtokenabiAddress
      );
      let data = await ethContract.methods
        .allowance(this.currentAccount, this.fomoContractAddress)
        .call();
      let authorizationMoney = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4);

      console.log("注册需要的t3t：", this.registerPrice);
      console.log("剩余授权金额额度：", authorizationMoney.toString(10));
      if (this.$BigNumber(this.registerPrice).gt(authorizationMoney)) {
        // 额度不够，调用授权金额接口
        return await this.authorizationPayMoney();
      }
      return true;
    },

    /**
     * 授权金额
     */
    async authorizationPayMoney() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.cup.tips.loading.authorizeText"),
        forbidClick: true,
        duration: 0,
        loadingType: "spinner",
        overlay: true,
      });
      let ethContract = new this.$web3.eth.Contract(
        f3cashtokenabi,
        this.$f3cashtokenabiAddress
      );
      try {
        let data = await ethContract.methods
          .approve(
            this.fomoContractAddress,
            this.$BigNumber(10000000000000 * Math.pow(10, 6)).toString(10)
          )
          .send({ from: this.currentAccount });
        console.log(data);
        this.$notify({
          type: "success",
          message: this.$i18n.tc("game.cup.tips.notify.authorizeSuccessText"),
        });
        return true;
      } catch (err) {
        console.error(err);
        this.$notify({
          type: "danger",
          message: this.$i18n.tc("game.cup.tips.notify.authorizeFailText"),
        });
        return false;
      } finally {
        // 关闭加载动画
        loading.clear();
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.register {
  width: 100%;
  height: 100vh;
  background: #1b1b1b;

  // 注册区域
  .register-content {
    padding: 20px 20px 20px 20px;
    display: flex;
    flex-direction: column;

    .title {
      font-size: 12px;
      font-family: DM Sans-Regular, DM Sans;
      font-weight: 400;
      color: #ffffff;
      line-height: 14px;
    }

    .input {
      margin-top: 8px;
      height: 30px;
      background: rgba(255, 255, 255, 0.4);
      border-radius: 43px 43px 43px 43px;
      border: 1px solid rgba(255, 255, 255, 0.6);
      padding: 0 16px;
      line-height: 30px;
      font-size: 12px;
      font-family: DM Sans-Regular, DM Sans;
      font-weight: 400;
      color: #ffffff;
    }

    input::-webkit-input-placeholder {
      color: rgba(255, 255, 255, 0.8);
    }

    .rule-text {
      margin-top: 12px;
      font-size: 12px;
      font-family: DM Sans-Regular, DM Sans;
      font-weight: 400;
      color: rgba(255, 255, 255, 0.7);
      line-height: 14px;
    }
    .rule-list {
      display: flex;
      flex-direction: column;
      .rule-item {
        font-size: 12px;
        font-family: DM Sans-Regular, DM Sans;
        font-weight: 400;
        color: rgba(255, 255, 255, 0.7);
        line-height: 22px;
        position: relative;
        margin-left: 7px;

        &::before {
          content: "";
          display: flex;
          background: rgba(255, 255, 255, 0.7);
          width: 3px;
          height: 3px;
          border-radius: 50%;
          position: absolute;
          left: -7px;
          top: 50%;
          transform: translateX(-50%);
        }
      }
    }

    .rule-tips {
      margin-top: 14px;
      font-size: 12px;
      font-family: DM Sans-Regular, DM Sans;
      font-weight: 400;
      color: #ffffff;
      line-height: 14px;
    }

    .pay-btn {
      margin: 0 auto;
      margin-top: 20px;
      width: 180px;
      height: 30px;
      line-height: 30px;
      text-align: center;
      background: #d23634;
      border-radius: 104px;
      font-size: 16px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #ffffff;
    }

    .disabled {
      background: rgba(255, 255, 255, 0.4);
    }

    .register-tips {
      margin-top: 16px;
      font-size: 12px;
      font-family: DM Sans-Regular, DM Sans;
      font-weight: 400;
      color: rgba(255, 255, 255, 0.8);
      line-height: 14px;
      text-align: center;
    }
  }
}
</style>
