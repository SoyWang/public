<template>
  <div class="withdrawal">
    <!-- 表单区域 -->
    <div class="form-contaienr">
      <div class="input-item">
        <div class="label">
          {{ $t("game.cup.withdrawal.inputLabelList[0].label") }}
        </div>
        <div class="input-box">
          <input
            class="input"
            type="text"
            disabled
            v-model="currentAccount"
            :placeholder="
              $t('game.cup.withdrawal.inputLabelList[0].placeholder')
            "
          />
        </div>
      </div>
      <div class="input-item">
        <div class="label">
          {{ $t("game.cup.withdrawal.inputLabelList[1].label") }}
        </div>
        <div class="input-box">
          <input
            class="input"
            type="number"
            v-model="withdrawFrom.t3t"
            :placeholder="`${$t(
              'game.cup.withdrawal.inputLabelList[1].placeholder'
            )} ${balance} F3Cash`"
          />
          <p class="unit unit-red" @click="withdrawFrom.t3t = balance">
            {{ $t("game.cup.withdrawal.inputLabelList[1].allText") }}
          </p>
        </div>
      </div>
      <div class="input-item">
        <div class="label">
          {{ $t("game.cup.withdrawal.inputLabelList[2].label") }}
        </div>
        <div class="input-box">
          <input
            class="input"
            type="number"
            disabled
            v-model="withdrawFrom.usdt"
            :placeholder="
              $t('game.cup.withdrawal.inputLabelList[2].placeholder')
            "
          />
          <p class="unit">USDT</p>
        </div>
      </div>
      <div class="input-item">
        <div class="label">
          {{ $t("game.cup.withdrawal.inputLabelList[3].label") }}
        </div>
        <div class="input-box">
          <input
            class="input"
            disabled
            type="number"
            v-model="withdrawFrom.poundage"
            :placeholder="
              $t('game.cup.withdrawal.inputLabelList[3].placeholder')
            "
          />
          <p class="unit">USDT</p>
        </div>
      </div>
    </div>
    <!-- 按钮区域 -->
    <div class="btn-group">
      <div class="withdrawal-btn" @click="handleWithdraw">
        {{ $t("game.cup.withdrawal.withdrawalBtnText") }}
      </div>
      <div
        class="withdrawal-detail-btn"
        @click="$router.push('/game/cup/withdrawalDetail')"
      >
        {{ $t("game.cup.withdrawal.withdrawalDetailBtnText") }}
      </div>
    </div>
  </div>
</template>

<script>
import walletMxin from "@/pages/mixin/walletMxin";
import f3cashtokenabi from "@/static/web3js/abi/cup/f3cashtokenabi.json";
import usdttokenabi from "@/static/web3js/abi/cup/usdttokenabi.json";
import bankabi from "@/static/web3js/abi/cup/bankabi.json";
export default {
  layout: "cupGame",
  mixins: [walletMxin],
  data() {
    return {
      exchangeRatio: null, // 兑换比例数
      poundageRatio: null, // 手续费比例
      balance: null, // 代币余额
      withdrawFrom: {
        t3t: null,
        usdt: null,
        poundage: null,
      }, // 提现表单
    };
  },
  async mounted() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      await this.watchAccountChange();
    }
  },
  watch: {
    "withdrawFrom.t3t"(value) {
      if (value) {
        this.withdrawFrom.usdt = this.$BigNumber(value)
          .times(this.exchangeRatio)
          .toString(10);
        this.withdrawFrom.poundage =
          this.withdrawFrom.usdt * this.poundageRatio;
      } else {
        this.withdrawFrom.usdt = null;
        this.withdrawFrom.poundage = null;
      }
    },
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.cup.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      await this.fetchCoinNumber();
      await this.fetchWithdrawRatio();
      await this.fetchWithdrawPoundage();
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 获取用户可提现的代币数量
     */
    async fetchCoinNumber() {
      let ethContract = new this.$web3.eth.Contract(
        f3cashtokenabi,
        this.$f3cashtokenabiAddress
      );
      let data = await ethContract.methods
        .balanceOf(this.currentAccount)
        .call();
      this.balance = this.$BigNumber(data)
        .div(Math.pow(10, 18))
        .toFixed(4)
        .toString(10);
      console.log("用户当前可提现的T3T：", this.balance);
    },

    /**
     * 获取提现兑换比列
     */
    async fetchWithdrawRatio() {
      let ethContract = new this.$web3.eth.Contract(
        bankabi,
        this.$bankabiAddress
      );
      let data = await ethContract.methods.f3ExchangeRatio().call();
      this.exchangeRatio = Number(data) / 100;
      console.log("提现兑换比例：", this.exchangeRatio);
    },

    /**
     * 获取提现手续费比例
     */
    async fetchWithdrawPoundage() {
      // let ethContract = new this.$web3.eth.Contract(
      //   herostorageabi,
      //   this.$herostorageabiAddress
      // );
      // let data = await ethContract.methods.config().call();
      // this.poundageRatio = Number(data.commissionRatio) / 100;
      // console.log("体现手续费比例：", this.poundageRatio);
      // todo 提现手续费手动设置为0
      this.poundageRatio = 0;
    },

    /**
     * 提现
     */
    async handleWithdraw() {
      // 判断提现金额是否为空
      if (!this.withdrawFrom.t3t) {
        return this.$toast(
          this.$i18n.tc("game.cup.tips.toast.withdrawNumberText1")
        );
      }

      // 判断提现的t3t是否大于最大可提现数量
      if (this.withdrawFrom.t3t > Number(this.balance)) {
        return this.$toast(
          this.$i18n.tc("game.cup.tips.toast.withdrawNumberText3")
        );
      }

      // 判断提现的t3t是否等于0
      if (Number(this.balance) == 0) {
        return this.$toast(
          this.$i18n.tc("game.cup.tips.toast.withdrawNumberText4")
        );
      }

      // 查询授权金额
      let result = await this.fetchAuthorizationPayMoney();
      if (!result) return;

      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.cup.tips.loading.withdrawText"),
        forbidClick: true,
        duration: 0,
        loadingType: "spinner",
        overlay: true,
      });

      // 提现
      let ethContract = new this.$web3.eth.Contract(
        bankabi,
        this.$bankabiAddress
      );
      try {
        let data = await ethContract.methods
          .exchangeF3IntoUsdt(
            this.$BigNumber(this.withdrawFrom.t3t)
              .times(Math.pow(10, 18))
              .integerValue()
              .toString(10)
          )
          .send({ from: this.currentAccount });
        console.log(data);
        this.$notify({
          type: "success",
          message: this.$i18n.tc("game.cup.tips.notify.withdarwalSuccessText"),
        });
        this.withdrawFrom.t3t = null;
        this.withdrawFrom.usdt = null;
      } catch (err) {
        console.error(err);
        this.$notify({
          type: "danger",
          message: this.$i18n.tc("game.cup.tips.notify.withdarwalFailText"),
        });
      } finally {
        // 关闭加载动画
        loading.clear();
      }
    },

    /**
     * 查询授权金额的余量
     */
    async fetchAuthorizationPayMoney() {
      let ethContract = new this.$web3.eth.Contract(
        f3cashtokenabi,
        this.$f3cashtokenabiAddress
      );
      let data = await ethContract.methods
        .allowance(this.currentAccount, this.$bankabiAddress)
        .call();
      let authorizationMoney = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4);
      console.log("需要提现的t3t：", this.withdrawFrom.t3t);
      console.log("剩余授权金额额度：", authorizationMoney.toString(10));
      if (this.$BigNumber(this.withdrawFrom.t3t).gt(authorizationMoney)) {
        // 额度不够，调用授权金额接口
        return await this.authorizationPayMoney();
      }
      return true;
    },

    /**
     * 授权金额
     */
    async authorizationPayMoney() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.cup.tips.loading.authorizeText"),
        forbidClick: true,
        duration: 0,
        loadingType: "spinner",
        overlay: true,
      });
      let ethContract = new this.$web3.eth.Contract(
        f3cashtokenabi,
        this.$f3cashtokenabiAddress
      );
      try {
        let data = await ethContract.methods
          .approve(
            this.$bankabiAddress,
            this.$BigNumber(10000000000000 * Math.pow(10, 6)).toString(10)
          )
          .send({ from: this.currentAccount });
        console.log(data);
        this.$notify({
          type: "success",
          message: this.$i18n.tc("game.cup.tips.notify.authorizeSuccessText"),
        });
        return true;
      } catch (err) {
        console.error(err);
        this.$notify({
          type: "danger",
          message: this.$i18n.tc("game.cup.tips.notify.authorizeFailText"),
        });
        return false;
      } finally {
        // 关闭加载动画
        loading.clear();
      }
    },

    /**
     * 往后端添加提现记录
     */
    async handleAddWithDrawalRecord() {
      let data = await this.$axios.get(`${this.$cupBaseURL}play`, {});
    },
  },
};
</script>

<style lang="scss" scoped>
.withdrawal {
  width: 100%;
  padding: 0 12px;
  padding-bottom: 20px;

  // 表单区域
  .form-contaienr {
    .input-item {
      display: flex;
      flex-direction: column;
      margin-top: 30px;

      .label {
        font-size: 16px;
        font-family: DM Sans-Medium, DM Sans;
        font-weight: 500;
        color: rgba(255, 255, 255, 0.8);
      }

      .input-box {
        height: 37px;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid rgba(255, 255, 255, 0.7);
        padding: 0 2px;

        .input {
          width: 100%;
          height: 100%;
          color: #ffffff;
          background: transparent;
          border: none;
          outline: none;
          font-size: 16px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #ffffff;
        }

        .unit {
          font-size: 14px;
          font-family: DM Sans-Medium, DM Sans;
          font-weight: 500;
          color: #ffffff9c;
          padding: 0 19px;
        }

        .unit-red {
          color: #d23634;
        }
      }
    }
  }

  // 按钮区域
  .btn-group {
    margin-top: 100px;
    display: flex;
    flex-direction: column;
    align-items: center;

    .withdrawal-btn {
      margin-bottom: 20px;
      width: 220px;
      height: 40px;
      line-height: 40px;
      text-align: center;
      background: #d23634;
      border-radius: 131px;
      font-size: 16px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #ffffff;
    }

    .withdrawal-detail-btn {
      width: 220px;
      height: 40px;
      height: 40px;
      line-height: 40px;
      text-align: center;
      border-radius: 131px;
      border: 1px solid #d23634;
      font-size: 16px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #d23634;
    }
  }
}
</style>