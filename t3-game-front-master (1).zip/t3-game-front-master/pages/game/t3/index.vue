<template>
  <div class="t3">
    <!-- 数字列表 -->
    <div class="number-list">
      <div class="number-item">
        <p class="number">{{ totalBalance }}</p>
        <p class="text">{{ $t("game.t3.index.numberList[0]") }}</p>
      </div>
      <p class="diveder"></p>
      <div class="number-item">
        <p class="number">{{ totalUser }}</p>
        <p class="text">{{ $t("game.t3.index.numberList[1]") }}</p>
      </div>
      <p class="diveder"></p>
      <div class="number-item">
        <p class="number">{{ userIncome }}</p>
        <p class="text">{{ $t("game.t3.index.numberList[2]") }}</p>
      </div>
    </div>

    <div class="content-container">
      <!-- 功能列表 -->
      <div class="function-list">
        <div
          class="function-item"
          @click="$router.push('/game/t3/sorrowValue')"
        >
          <div class="icon">
            <img src="@/assets/images/game/t3/function1-icon.png" alt="" />
          </div>
          <p class="title">{{ $t("game.t3.index.optList[0]") }}</p>
        </div>
        <div class="function-item" @click="$router.push('/game/t3/mineIncome')">
          <div class="icon">
            <img src="@/assets/images/game/t3/function2-icon.png" alt="" />
          </div>
          <p class="title">{{ $t("game.t3.index.optList[1]") }}</p>
        </div>
        <div class="function-item" @click="$router.push('/game/t3/recharge')">
          <div class="icon">
            <img src="@/assets/images/game/t3/function3-icon.png" alt="" />
          </div>
          <p class="title">{{ $t("game.t3.index.optList[2]") }}</p>
        </div>
        <div class="function-item" @click="$router.push('/game/t3/withdraw')">
          <div class="icon">
            <img src="@/assets/images/game/t3/function4-icon.png" alt="" />
          </div>
          <p class="title">{{ $t("game.t3.index.optList[3]") }}</p>
        </div>
      </div>

      <!-- 球星列表轮播 -->
      <van-swipe
        :loop="false"
        indicator-color="white"
        ref="starSwiper"
        @change="handelChangeSwiper"
      >
        <van-swipe-item
          v-for="(item0, index0) in starList"
          :key="index0"
          class="swiper-item"
        >
          <div class="star-list">
            <div
              class="star-item"
              v-for="(item1, index1) in item0"
              :key="index1"
            >
              <!-- 解锁后球星 -->
              <template v-if="userInfo.starCount >= item1.sort">
                <!-- 球星头像 -->
                <div class="avatar-box">
                  <img class="avatar" :src="item1.activeAvatar" alt="" />
                </div>
                <!-- 点位图标 -->
                <div
                  class="icon-list"
                  @click="showIncomeDescriptionPopup = true"
                >
                  <div
                    :class="[
                      'icon-item',
                      item1.pointsState.length >= 1 || item1.state == 1
                        ? 'icon-item-active'
                        : '',
                    ]"
                  >
                    <img
                      class="icon"
                      :src="require(`@/assets/images/game/t3/star1-icon.png`)"
                      alt=""
                    />
                  </div>
                  <div
                    :class="[
                      'icon-item',
                      item1.pointsState.length >= 2 || item1.state == 1
                        ? 'icon-item-active'
                        : '',
                    ]"
                  >
                    <img
                      class="icon"
                      :src="require(`@/assets/images/game/t3/star1-icon.png`)"
                      alt=""
                    />
                  </div>
                  <div
                    v-if="item1.points"
                    :class="[
                      'icon-item',
                      item1.pointsState.length >= 3 || item1.state == 1
                        ? 'icon-item-active'
                        : '',
                    ]"
                  >
                    <!-- 自己图标 -->
                    <img
                      v-if="item1.points[2] == 0"
                      class="icon"
                      :src="require(`@/assets/images/game/t3/star1-icon.png`)"
                      alt=""
                    />
                    <!-- 上级图标 -->
                    <img
                      v-else-if="item1.points[2] == 1"
                      class="icon"
                      :src="require(`@/assets/images/game/t3/star2-icon.png`)"
                      alt=""
                    />
                    <!-- 随机图标 -->
                    <img
                      v-else="item1.points[2] == 2"
                      class="icon"
                      :src="require(`@/assets/images/game/t3/star3-icon.png`)"
                      alt=""
                    />
                  </div>
                  <div
                    v-if="item1.points"
                    :class="[
                      'icon-item',
                      item1.pointsState.length >= 4 || item1.state == 1
                        ? 'icon-item-active'
                        : '',
                    ]"
                  >
                    <!-- 自己图标 -->
                    <img
                      v-if="item1.points[3] == 0"
                      class="icon"
                      :src="require(`@/assets/images/game/t3/star1-icon.png`)"
                      alt=""
                    />
                    <!-- 上级图标 -->
                    <img
                      v-else-if="item1.points[3] == 1"
                      class="icon"
                      :src="require(`@/assets/images/game/t3/star2-icon.png`)"
                      alt=""
                    />
                    <!-- 随机图标 -->
                    <img
                      v-else="item1.points[3] == 2"
                      class="icon"
                      :src="require(`@/assets/images/game/t3/star3-icon.png`)"
                      alt=""
                    />
                  </div>
                </div>
                <!-- 冻结状态按钮 -->
                <div
                  class="btn btn-freeze"
                  v-if="item1.state == 1"
                  @click="showFreezeDescriptionPopup = true"
                >
                  <span>{{ $t("game.t3.index.freezeBtnText") }}</span>
                  <img
                    class="icon"
                    src="@/assets/images/game/t3/question-icon.png"
                    alt=""
                  />
                </div>

                <!-- 永久经营按钮 -->
                <div class="btn" v-else-if="item1.state == 2">
                  {{ $t("game.t3.index.runBtnText") }}
                </div>

                <!-- 正常状态按钮 -->
                <div class="btn" v-else>
                  {{ $t("game.t3.index.unlockedBtnText") }}
                </div>
              </template>

              <!-- 未解锁球星 -->
              <template v-else>
                <!-- 球星头像 -->
                <div class="avatar-box">
                  <img
                    class="avatar avatar-filter"
                    :src="item1.avatar"
                    alt=""
                  />
                  <div class="lock-box">
                    <img
                      class="lock-icon"
                      src="@/assets/images/game/t3/lock-icon.png"
                      alt=""
                    />
                  </div>
                </div>
                <!-- 点位图标 -->
                <div
                  class="icon-list"
                  @click="showIncomeDescriptionPopup = true"
                >
                  <div class="icon-item">
                    <img
                      class="icon"
                      :src="require(`@/assets/images/game/t3/star1-icon.png`)"
                      alt=""
                    />
                  </div>
                  <div class="icon-item">
                    <img
                      class="icon"
                      :src="require(`@/assets/images/game/t3/star1-icon.png`)"
                      alt=""
                    />
                  </div>
                  <div class="icon-item">
                    <img
                      class="icon icon2"
                      :src="require(`@/assets/images/game/t3/star4-icon.png`)"
                      alt=""
                    />
                  </div>
                  <div class="icon-item">
                    <img
                      class="icon icon2"
                      :src="require(`@/assets/images/game/t3/star4-icon.png`)"
                      alt=""
                    />
                  </div>
                </div>
                <!-- 按钮 -->
                <div
                  class="btn btn-active"
                  @click="handleShowUnlockStarPopup(item1.sort)"
                >
                  {{ $t("game.t3.index.unlockBtnText") }}
                </div>
              </template>
            </div>
          </div>
        </van-swipe-item>
      </van-swipe>

      <!-- 轮播控制 -->
      <div class="controller-container">
        <p
          :class="[currentSwiperIndex != 0 ? 'active' : '']"
          @click="handleSwitchSwiper('prev')"
        >
          {{ $t("game.t3.index.prevText") }}
        </p>
        <p
          :class="[currentSwiperIndex != 3 ? 'active' : '']"
          @click="handleSwitchSwiper('next')"
        >
          {{ $t("game.t3.index.nextText") }}
        </p>
      </div>

      <!-- 底部邀请 -->
      <div class="invite-link">
        <div class="team-number">
          <span class="label">{{ $t("game.t3.index.teamText") }}：</span>
          <span class="number">{{ userInfo.partnersCount }}</span>
          <!-- <img class="icon" src="@/assets/images/game/t3/question-icon.png" alt=""> -->
        </div>
        <p class="text">{{ $t("game.t3.index.inviteLinkText") }}：</p>
        <div class="invite-box">
          <input class="input" type="text" :value="invitLink" disabled />
          <div class="copy-btn" ref="copyBtn" @click="handleCopyInvitLink">
            {{ $t("game.t3.index.copyLinkText") }}
          </div>
        </div>
        <div class="share-btn" @click="$router.push('/game/t3/share')">
          <img
            class="icon"
            src="@/assets/images/game/t3/share-icon.png"
            alt=""
          />
          <p class="text">{{ $t("game.t3.index.shareText") }}</p>
        </div>
      </div>
    </div>

    <!-- 收益说明弹框 -->
    <van-popup v-model="showIncomeDescriptionPopup" class="income-popup">
      <p class="title">{{ $t("game.t3.index.incomePopup.titleText") }}</p>
      <div class="description-list">
        <div
          class="description-item"
          v-for="(item, index) in $t(
            'game.t3.index.incomePopup.descriptionList'
          )"
          :key="index"
        >
          <img
            class="icon"
            :src="
              require(`@/assets/images/game/t3/star${
                index + 1
              }-active-icon.png`)
            "
            alt=""
          />
          <p class="text">{{ item }}</p>
        </div>
      </div>
      <div class="confirm-btn" @click="showIncomeDescriptionPopup = false">
        {{ $t("game.t3.index.incomePopup.confirmBtnText") }}
      </div>
    </van-popup>

    <!-- 冻结说明弹框 -->
    <van-popup v-model="showFreezeDescriptionPopup" class="income-popup">
      <p class="title">{{ $t("game.t3.index.freezePopup.titleText") }}</p>
      <div class="description-list">
        <div class="description-item">
          <img
            class="icon"
            :src="require(`@/assets/images/game/t3/star4-active-icon.png`)"
            alt=""
          />
          <p class="text">
            {{ $t("game.t3.index.freezePopup.descriptionContent") }}
          </p>
        </div>
      </div>
      <div class="confirm-btn" @click="showFreezeDescriptionPopup = false">
        {{ $t("game.t3.index.freezePopup.confirmBtnText") }}
      </div>
    </van-popup>

    <!-- 解锁弹框 -->
    <van-popup
      v-model="showUnlockStarPopup"
      class="buy-confirm"
      closeable
      :close-icon="require('@/assets/images/game/t3/close-icon.png')"
      position="bottom"
      @closed="handleCloseUnlockStarPopup"
      @click-close-icon="handleCloseUnlockStarPopup"
    >
      <p class="title">{{ startCoin }} F3Cash</p>
      <p class="text">{{ $t("game.t3.index.unlockPopup.payText") }}</p>
      <div class="parameter-list">
        <div class="parameter-item">
          <p>{{ $t("game.t3.index.unlockPopup.functionLabel") }}</p>
          <p>{{ $t("game.t3.index.unlockPopup.functionValue") }}</p>
        </div>
        <div class="parameter-item">
          <p>{{ $t("game.t3.index.unlockPopup.balanceText") }}</p>
          <p>{{ userInfo.balance }} F3Cash</p>
        </div>
      </div>
      <div class="btn" @click="handleConfirmUnlockStar">
        {{ $t("game.t3.index.unlockPopup.confirmBtnText") }}
      </div>
    </van-popup>
  </div>
</template>

<script>
import herostorageabi from "@/static/web3js/abi/t3/herostorageabi.json";
import herotonkenabi from "@/static/web3js/abi/t3/herotonkenabi.json";
import autoheroabi from "@/static/web3js/abi/t3/autoheroabi.json";
import walletMxin from "@/pages/mixin/walletMxin";
export default {
  mixins: [walletMxin],
  layout: "t3GameIndex",
  data() {
    return {
      totalBalance: 0, // 总流水
      totalUser: 0, // 总用户
      userIncome: 0, // 用户收益
      showIncomeDescriptionPopup: false, // 是否展示收益说明弹框
      showFreezeDescriptionPopup: false, // 是否展示冻结说明弹框
      showUnlockStarPopup: false, // 是否展示解锁弹框
      currentSwiperIndex: 0, // 当前轮播索引
      invitLink: null, // 邀请链接
      parentAddress: null, // 上级用户地址
      userInfo: {
        starCount: 0, // 解锁的球星数量
        partnersCount: 0, // 团队成员数量
        balance: 0, // 用户当前的代币余额
      },
      startCoin: 0, // 解锁球星需要的代币
      starList: [
        [
          {
            avatar: require("@/assets/images/game/t3/star1-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star1-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 1, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star2-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star2-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 2, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star3-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star3-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 3, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star4-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star4-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 4, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star5-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star5-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 5, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star6-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star6-avatar-active.png"),
            points: null, // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 6, // 序号
          },
        ],
        [
          {
            avatar: require("@/assets/images/game/t3/star7-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star7-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 7, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star8-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star8-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 8, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star9-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star9-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 9, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star10-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star10-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 10, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star11-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star11-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 11, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star12-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star12-avatar-active.png"),
            points: null, // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 12, // 序号
          },
        ],
        [
          {
            avatar: require("@/assets/images/game/t3/star13-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star13-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 13, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star14-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star14-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 14, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star15-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star15-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 15, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star16-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star16-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 16, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star17-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star17-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 17, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star18-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star18-avatar-active.png"),
            points: null, // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 18, // 序号
          },
        ],
        [
          {
            avatar: require("@/assets/images/game/t3/star19-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star19-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 19, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star20-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star20-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 20, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star21-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star21-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 21, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star22-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star22-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 22, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star23-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star23-avatar-active.png"),
            points: [], // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 23, // 序号
          },
          {
            avatar: require("@/assets/images/game/t3/star24-avatar.png"),
            activeAvatar: require("@/assets/images/game/t3/star24-avatar-active.png"),
            points: null, // 点位列表
            state: 0, // 汽车状态
            pointsState: [], // 已使用的利益点
            sort: 24, // 序号
          },
        ],
      ],
    };
  },
  async mounted() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      await this.watchAccountChange();
    }

    // 监听是否需要弹出解锁球星弹框
    if (this.$route.query.showUnlockStarPopup) {
      this.handleShowUnlockStarPopup(this.userInfo.starCount + 1);
    }
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 获取数据
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      // 获取请求数据
      await this.fetchNumberList();
      await this.fetchTotalBalance();
      await this.fetchUserIncome();
      await this.fetchUserInfo();
      await this.fetchStarInfo();
      await this.fetchRootAccount();
      // 生成邀请链接
      this.createInviteLink();
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 获取用户总量
     */
    async fetchNumberList() {
      let ethContract = new this.$web3.eth.Contract(
        herostorageabi,
        this.$herostorageabiAddress
      );
      let data = await ethContract.methods.data().call();
      this.totalUser = Number(data.totalUserCount);
      console.log("总用户：", this.totalUser);
    },

    /**
     * 获取总流水
     */
    async fetchTotalBalance() {
      let ethContract = new this.$web3.eth.Contract(
        herostorageabi,
        this.$herostorageabiAddress
      );
      let data = await ethContract.methods
        .getTotalBalance(this.$herotonkenabiAddress)
        .call();
      this.totalBalance = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4)
        .toString(10);
      console.log("总流水", this.totalBalance);
    },

    /**
     * 获取用户收益
     */
    async fetchUserIncome() {
      let ethContract = new this.$web3.eth.Contract(
        herostorageabi,
        this.$herostorageabiAddress
      );
      let data = await ethContract.methods
        .getUserDepositBalance(this.currentAccount, this.$herotonkenabiAddress)
        .call();
      this.userIncome = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4)
        .toString(10);
      console.log("用户收益", this.userIncome);
    },

    /**
     * 获取用户信息
     */
    async fetchUserInfo() {
      let ethContract = new this.$web3.eth.Contract(
        herostorageabi,
        this.$herostorageabiAddress
      );
      let data = await ethContract.methods.getUser(this.currentAccount).call();
      this.userInfo.starCount = Number(data.carCount);
      this.userInfo.partnersCount = Number(data.partnersCount);
      if (data.id !== "0") {
        // 判断是不是新用户，如果不是新用户则获取上级用户账号
        this.parentAddress = data.referrer;
      }
      console.log("用户信息：", this.userInfo);
    },

    /**
     * 获取球星信息
     */
    async fetchStarInfo() {
      let ethContract = new this.$web3.eth.Contract(
        herostorageabi,
        this.$herostorageabiAddress
      );

      // 更具用户拥有的球星数量，循环获取球星信息
      for (let i = 0; i < this.userInfo.starCount; i++) {
        let data = await ethContract.methods
          .getUserCar(this.currentAccount, i + 1)
          .call();
        let index = Math.floor(i / 6);
        let subIndex = i % 6;
        this.starList[index][subIndex].points = data.points;
        this.starList[index][subIndex].pointsState = data.pointsState;
        this.starList[index][subIndex].state = data.state;
      }
      console.log("球星信息：", this.starList);
    },

    /**
     * 获取解锁球星需要花费的代币
     */
    async fetchUnlockStarCoin() {
      let ethContract = new this.$web3.eth.Contract(
        herostorageabi,
        this.$herostorageabiAddress
      );
      let data = await ethContract.methods
        .getCar(this.userInfo.starCount + 1)
        .call();
      this.startCoin = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4)
        .toString(10);
      console.log("球星价格：", this.startCoin);
    },

    /**
     * 获取用户当前的代币
     */
    async fetchUserCoin() {
      let ethContract = new this.$web3.eth.Contract(
        herotonkenabi,
        this.$herotonkenabiAddress
      );
      let data = await ethContract.methods
        .balanceOf(this.currentAccount)
        .call();
      this.userInfo.balance = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4)
        .toString(10);
      console.log("用户当前的T3T：", this.userInfo.balance);
    },

    /**
     * 查询授权金额的余量
     */
    async fetchAuthorizationPayMoney() {
      let ethContract = new this.$web3.eth.Contract(
        herotonkenabi,
        this.$herotonkenabiAddress
      );
      let data = await ethContract.methods
        .allowance(this.currentAccount, this.$autoheroabiAddress)
        .call();
      let authorizationMoney = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4);
      console.log("剩余授权金额额度：", authorizationMoney.toString(10));
      if (this.$BigNumber(this.startCoin).gt(authorizationMoney)) {
        // 额度不够，调用授权金额接口
        return await this.authorizationPayMoney();
      }
      return true;
    },

    /**
     * 授权金额
     */
    async authorizationPayMoney() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.authorizeText"),
        forbidClick: true,
        duration: 0,
        loadingType: "spinner",
        overlay: true,
      });
      let ethContract = new this.$web3.eth.Contract(
        herotonkenabi,
        this.$herotonkenabiAddress
      );
      try {
        let data = await ethContract.methods
          .approve(
            this.$autoheroabiAddress,
            this.$BigNumber(10000000000000 * Math.pow(10, 6)).toString(10)
          )
          .send({ from: this.currentAccount });
        console.log(data);
        this.$notify({
          type: "success",
          message: this.$i18n.tc("game.t3.tips.notify.authorizeSuccessText"),
        });
        return true;
      } catch (err) {
        console.error(err);
        this.$notify({
          type: "danger",
          message: this.$i18n.tc("game.t3.tips.notify.authorizeFailText"),
        });
        return false;
      } finally {
        // 关闭加载动画
        loading.clear();
      }
    },

    /**
     * 确认解锁球星
     */
    async handleConfirmUnlockStar() {
      // 判断余额是否足够
      if (
        this.$BigNumber(this.startCoin).gt(
          this.$BigNumber(this.userInfo.balance)
        )
      ) {
        // 余额不足弹框
        this.$dialog
          .confirm({
            title: this.$i18n.tc("game.t3.index.confirm.title"),
            message:
              this.$i18n.tc("game.t3.index.confirm.messageFront") +
              this.userInfo.balance +
              this.$i18n.tc("game.t3.index.confirm.messageBack"),
            cancelButtonText: this.$i18n.tc(
              "game.t3.index.confirm.cancelButtonText"
            ),
            confirmButtonText: this.$i18n.tc(
              "game.t3.index.confirm.confirmButtonText"
            ),
          })
          .then(() => {
            return this.$router.push("/game/t3/recharge");
          });
        return this.handleCloseUnlockStarPopup();
      }

      // 查询授权金额
      let result = await this.fetchAuthorizationPayMoney();
      if (!result) return;

      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.unlockText"),
        forbidClick: true,
        duration: 0,
        loadingType: "spinner",
        overlay: true,
      });
      let ethContract = new this.$web3.eth.Contract(
        autoheroabi,
        this.$autoheroabiAddress
      );

      // 解锁球星
      try {
        let data = await ethContract.methods
          .sendBuyCarRequest(this.userInfo.starCount + 1, this.parentAddress)
          .send({ from: this.currentAccount });
        console.log(data);

        // 轮询查询球星是否购买成功
        let timer = setInterval(async () => {
          let result = await this.isBuyStarSuccess();
          if (result) {
            // 关闭加载动画
            clearInterval(timer);
            loading.clear();
            this.showUnlockStarPopup = false;
            this.$router.push("/game/t3/unlockSuccess");
          }
        }, 500);
      } catch (err) {
        console.error(err);
        // 关闭加载动画
        loading.clear();
        this.showUnlockStarPopup = false;
        this.$router.push("/game/t3/unlockFail");
      }
    },

    /**
     * 判断球星是否购买成功
     */
    async isBuyStarSuccess() {
      let ethContract = new this.$web3.eth.Contract(
        herostorageabi,
        this.$herostorageabiAddress
      );
      let data = await ethContract.methods.getUser(this.currentAccount).call();
      if (Number(data.carCount) > this.userInfo.starCount) {
        // 解锁成功
        return true;
      } else {
        // 解锁失败
        return false;
      }
    },

    /**
     * 获取上级用户账号
     */
    async fetchRootAccount() {
      if (this.parentAddress) {
        console.log("用户上级地址：", this.parentAddress);
      } else if (this.$route.query.address) {
        // 有上级账号
        this.parentAddress = this.$route.query.address;
        console.log("用户上级地址：", this.parentAddress);
      } else {
        // 没有上级账号，请求接口获取跟用户
        let ethContract = new this.$web3.eth.Contract(
          autoheroabi,
          this.$autoheroabiAddress
        );
        let data = await ethContract.methods.getRoot().call();
        this.parentAddress = data;
        console.log("用户根地址：", this.parentAddress);
      }
    },

    /**
     * 展示解锁球星弹框
     */
    async handleShowUnlockStarPopup(sort) {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });

      // 判断是否解锁了上级球星
      if (this.userInfo.starCount !== sort - 1) {
        return this.$toast.fail(this.$i18n.tc("game.t3.tips.toast.unlockText"));
      }
      await this.fetchUnlockStarCoin();
      await this.fetchUserCoin();

      this.showUnlockStarPopup = true;
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 关闭解锁球星弹框
     */
    handleCloseUnlockStarPopup() {
      if (this.$route.query.address) {
        this.$router.replace({
          path: "/game/t3",
          query: {
            address: this.$route.query.address,
          },
        });
      } else {
        this.$router.replace("/game/t3");
      }
      this.showUnlockStarPopup = false;
    },

    /**
     * 生成邀请链接
     */
    createInviteLink() {
      this.invitLink =
        window.location.origin + "/game/t3?address=" + this.currentAccount;
    },

    /**
     * 复制邀请链接
     */
    handleCopyInvitLink() {
      let oInput = document.createElement("input");
      oInput.value = this.invitLink;
      document.body.appendChild(oInput);
      oInput.select();
      document.execCommand("Copy");
      this.$toast.success(this.$i18n.tc("game.t3.tips.toast.copySuccessText"));
      oInput.remove();
      this.$refs.copyBtn.style.cssText = "background: rgba(255,255,255,0.2);";
    },

    /**
     * 切换轮播
     */
    handleSwitchSwiper(tag) {
      if (tag === "prev") {
        // 上一页
        this.$refs.starSwiper.prev();
      } else {
        // 下一页
        this.$refs.starSwiper.next();
      }
    },

    /**
     * 轮播切换触发
     */
    handelChangeSwiper(index) {
      this.currentSwiperIndex = index;
    },
  },
};
</script>

<style lang="scss" scoped>
.t3 {
  width: 100%;

  // 数字列表
  .number-list {
    height: 140px;
    width: 100%;
    padding: 0 15px;
    padding-top: 60px;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    background: url("@/assets/images/game/t3/index-header-bg.png") no-repeat;
    background-size: 100% 100%;

    .number-item {
      width: 30%;
      height: 50%;
      display: flex;
      flex-direction: column;

      .number {
        font-size: 14px;
        font-family: PingFang SC;
        font-weight: bold;
        line-height: 20px;
        color: #ffffff;
        text-align: center;
      }

      .text {
        margin-top: 7px;
        text-align: center;
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        line-height: 15px;
        color: #ffffff;
      }
    }

    .diveder {
      // margin: 0 10px;
      width: 2px;
      height: 15px;
      background: rgba(255, 255, 255, 1);
    }
  }

  .content-container {
    margin-top: -1px;
    padding-bottom: 30px;
    background: linear-gradient(180deg, #00388f 0%, #000f25 100%);

    // 功能列表
    .function-list {
      margin: 0 15px;
      padding-top: 25px;
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;

      .function-item {
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;

        .icon {
          width: 50px;
          height: 50px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 5px;
          padding: 5px;
        }

        &:nth-child(1) {
          img {
            width: 28px;
            height: 30px;
          }
        }

        &:nth-child(2) {
          img {
            width: 40px;
            height: 40px;
          }
        }

        &:nth-child(3) {
          img {
            width: 23px;
            height: 41px;
          }
        }

        &:nth-child(4) {
          img {
            width: 42px;
            height: 40px;
          }
        }

        .title {
          margin-top: 5px;
          font-size: 12px;
          font-family: PingFang SC;
          font-weight: 400;
          line-height: 17px;
          color: #ffffff;
        }

        &:nth-child(1) {
          .icon {
            background: linear-gradient(180deg, #6b92ff 0%, #023ad4 100%);
          }
        }

        &:nth-child(2) {
          .icon {
            background: linear-gradient(180deg, #64ffcf 0%, #00d0ff 100%);
          }
        }

        &:nth-child(3) {
          .icon {
            background: linear-gradient(180deg, #ffcb91 0%, #ff671c 100%);
          }
        }

        &:nth-child(4) {
          .icon {
            background: linear-gradient(180deg, #ff91b3 0%, #ff316b 100%);
          }
        }
      }
    }

    // 球星列表轮播
    .star-list {
      margin: 0 15px;
      margin-top: 30px;
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
      justify-content: space-between;
      background: rgba(255, 255, 255, 0.15);
      border-radius: 10px;
      padding: 0 10px 40px 10px;

      .star-item {
        width: 26vw;
        height: 43vw;
        margin-top: 15px;
        display: flex;
        flex-direction: column;
        align-items: center;

        .avatar-box {
          width: 100%;
          height: 26vw;
          position: relative;
          border-radius: 3px;
          overflow: hidden;

          .avatar {
            width: 100%;
            height: 100%;
          }

          .avatar-filter {
            filter: blur(2px);
          }

          .lock-box {
            width: 100%;
            height: 100%;
            position: absolute;
            left: 0;
            top: 0;
            background-color: rgba(255, 255, 255, 0.1);
            background-size: 100% 100%;

            .lock-icon {
              width: 11px;
              height: 13px;
              position: absolute;
              left: 50%;
              top: 50%;
              transform: translateX(-50%);
              z-index: 999999;
            }
          }
        }

        .icon-list {
          width: 100%;
          margin-top: 10px;
          display: flex;
          flex-direction: row;
          justify-content: space-between;

          .icon-item {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 21px;
            height: 21px;
            border-radius: 5px;
            background: rgba(255, 255, 255, 0.2);

            .icon {
              width: 9px;
              height: 9px;
            }

            .icon2 {
              width: 6px;
              height: 9px;
            }
          }

          .icon-item-active {
            background: rgba(71, 115, 253, 1);
          }
        }

        .btn {
          margin-top: 10px;
          width: 100%;
          height: 25px;
          background: rgba(61, 96, 152, 0.39);
          border-radius: 5px;
          font-size: 12px;
          font-family: PingFang SC;
          font-weight: 400;
          line-height: 25px;
          text-align: center;
          color: rgba(255, 255, 255, 0.5);
        }

        .btn-active {
          color: #ffffff;
          background: linear-gradient(180deg, #00d5ff 0%, #0044ff 100%);
        }

        .btn-freeze {
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: center;
          color: #fff;

          .icon {
            display: inline-block;
            margin-left: 5px;
            width: 15px;
            height: 15px;
          }
        }
      }
    }

    // 轮播控制
    .controller-container {
      width: 100%;
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      padding: 0 50px;
      position: relative;
      top: -30px;

      p {
        line-height: 22px;
        width: 50px;
        text-align: center;
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        color: rgb(123, 123, 123);
        // background-color: rgba(255, 255, 255, 0.1);
        // border-radius: 4px;
      }

      .active {
        color: #fff;
      }
    }

    // 底部邀请
    .invite-link {
      margin: 0 15px;
      margin-top: 10px;
      height: 195px;
      padding: 33px 15px 0 15px;
      background: url("@/assets/images/game/t3/share-bottom-bg.png") no-repeat;
      background-size: 100% 100%;

      .team-number {
        background: rgba(0, 0, 0, 0.5);
        border-radius: 13px;
        padding: 0 12px;
        display: inline-flex;
        flex-direction: row;
        align-items: center;
        height: 25px;

        .label,
        .number {
          font-size: 14px;
          font-family: PingFang SC;
          font-weight: 400;
          // color: #4796fd;
          color: #fff;
        }

        .icon {
          display: inline-block;
          margin-left: 5px;
          width: 15px;
          height: 15px;
        }
      }

      .text {
        margin-top: 15px;
        height: 20px;
        font-size: 14px;
        font-family: PingFang SC;
        font-weight: 400;
        line-height: 20px;
        color: #ffffff;
      }

      .invite-box {
        padding-top: 5px;
        display: flex;
        flex-direction: row;
        justify-content: space-between;

        .input {
          outline: none;
          border: none;
          background: none;
          padding: 0 10px;
          width: 65%;
          height: 30px;
          background: rgba(255, 255, 255, 1);
          border-radius: 5px;
          font-size: 12px;
          font-family: PingFang SC;
          font-weight: 400;
          line-height: 30px;
          color: #333333;
          // overflow: hidden;
          // text-overflow: ellipsis;
          // white-space: nowrap;
        }

        .copy-btn {
          text-align: center;
          width: 30%;
          height: 30px;
          background: linear-gradient(180deg, #ffcb91 0%, #ff671c 100%);
          border-radius: 5px;
          font-size: 12px;
          font-family: PingFang SC;
          font-weight: 400;
          line-height: 30px;
          color: #ffffff;
        }
      }

      .share-btn {
        margin-top: 10px;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        width: 100%;
        height: 40px;
        background: linear-gradient(180deg, #00d5ff 0%, #0044ff 100%);
        border-radius: 5px;

        .icon {
          width: 16px;
          margin-right: 10px;
        }

        .text {
          height: 35px;
          font-size: 14px;
          font-family: PingFang SC;
          font-weight: 400;
          color: #ffffff;
        }
      }
    }
  }

  // 收益说明弹框
  .income-popup {
    padding: 30px 20px;
    width: 90%;
    background: #ffffff;
    border-radius: 10px 10px 10px 10px;
    display: flex;
    flex-direction: column;

    .title {
      font-size: 16px;
      font-family: PingFang TC-Regular, PingFang SC;
      font-weight: 500;
      color: #333333;
      text-align: center;
    }

    .description-list {
      margin-top: 20px;
      display: flex;
      flex-direction: column;

      .description-item {
        margin-top: 10px;
        display: flex;
        flex-direction: row;

        .icon {
          width: 20px;
          height: 20px;
        }

        .text {
          margin-left: 10px;
          font-size: 14px;
          font-family: PingFang TC-Regular, PingFang SC;
          font-weight: 400;
          color: #333333;
        }
      }
    }

    .confirm-btn {
      margin-top: 30px;
      width: 100%;
      height: 40px;
      line-height: 40px;
      background: linear-gradient(180deg, #00d0ff 0%, #0048ff 100%);
      border-radius: 5px 5px 5px 5px;
      text-align: center;
      font-size: 16px;
      font-family: PingFang TC-Semibold, PingFang SC;
      font-weight: 500;
      color: #ffffff;
    }
  }

  // 解锁弹框
  .buy-confirm {
    padding: 0 20px;
    width: 100%;
    height: 350px;
    display: flex;
    flex-direction: column;
    align-items: center;

    .title {
      margin-top: 30px;
      height: 42px;
      font-size: 30px;
      font-family: PingFang SC;
      font-weight: bold;
      line-height: 42px;
      color: #333333;
    }

    .text {
      margin-top: 5px;
      height: 20px;
      font-size: 14px;
      font-family: PingFang SC;
      font-weight: bold;
      line-height: 20px;
      color: #333333;
    }

    .parameter-list {
      width: 100%;
      margin-top: 20px;
      display: flex;
      flex-direction: column;

      .parameter-item {
        padding: 10px 0;
        margin-top: 10px;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        font-size: 14px;
        font-family: PingFang SC;
        font-weight: 400;
        color: rgba(0, 0, 0, 0.7);
        border-bottom: 1px solid rgba(0, 0, 0, 0.1);
      }
    }

    .btn {
      width: 100%;
      margin-top: 30px;
      height: 40px;
      background: linear-gradient(180deg, #00d5ff 0%, #0044ff 100%);
      border-radius: 5px;
      font-size: 16px;
      font-family: PingFang SC;
      font-weight: bold;
      line-height: 40px;
      color: #ffffff;
      text-align: center;
    }
  }
}

/* 浏览器可视宽度大于600px */
@media only screen and (min-width: 600px) {
  .t3 {
    // 数字列表
    .number-list {
      .number-item {
        .number {
          font-size: 20px;
          line-height: 30px;
        }

        .text {
          font-size: 18px;
          line-height: 25px;
        }
      }

      .diveder {
      }
    }

    .content-container {
      // 功能列表
      .function-list {
        padding-top: 25px;

        .function-item {
          .icon {
            margin-top: 20px;
            width: 80px;
            height: 80px;
          }

          &:nth-child(1) {
            img {
              width: 50px;
              height: 55px;
            }
          }

          &:nth-child(2) {
            img {
              width: 55px;
              height: 55px;
            }
          }

          &:nth-child(3) {
            img {
              width: 43px;
              height: 61px;
            }
          }

          &:nth-child(4) {
            img {
              width: 62px;
              height: 60px;
            }
          }

          .title {
            font-size: 18px;
            line-height: 30px;
          }
        }
      }

      // 球星列表轮播
      .star-list {
        justify-content: space-around;
        padding: 0 10px 60px 10px;

        .star-item {
          height: 37vw;
          margin-top: 25px;

          .avatar-box {
            .avatar {
            }

            .avatar-filter {
            }

            .lock-box {
              .lock-icon {
                width: 20px;
                height: 23px;
              }
            }
          }

          .icon-list {
            width: 90%;
            margin-top: 10px;

            .icon-item {
              width: 28px;
              height: 28px;

              .icon {
                width: 15px;
                height: 15px;
              }

              .icon2 {
                width: 10px;
                height: 15px;
              }
            }

            .icon-item-active {
            }
          }

          .btn {
            margin-top: 15px;
            height: 40px;
            font-size: 18px;
            line-height: 40px;
          }

          .btn-active {
          }

          .btn-freeze {
            .icon {
              width: 20px;
              height: 20px;
            }
          }
        }
      }

      // 轮播控制
      .controller-container {
        top: -40px;

        p {
          width: 70px;
          font-size: 18px;
        }

        .active {
        }
      }

      // 底部邀请
      .invite-link {
        height: 250px;
        background-size: 100% 100%;

        .team-number {
          padding: 0 12px;
          height: 32px;

          .label,
          .number {
            font-size: 20px;
          }

          .icon {
          }
        }

        .text {
          height: 30px;
          font-size: 20px;
          line-height: 30px;
        }

        .invite-box {
          .input {
            height: 40px;
            font-size: 20px;
            line-height: 40px;
          }

          .copy-btn {
            height: 40px;
            line-height: 40px;
            font-size: 20px;
          }
        }

        .share-btn {
          margin-top: 15px;
          height: 55px;

          .icon {
            width: 25px;
          }

          .text {
            height: 45px;
            font-size: 22px;
          }
        }
      }
    }

    // 收益说明弹框
    .income-popup {
      width: 550px;

      .title {
        font-size: 24px;
      }

      .description-list {
        .description-item {
          .icon {
            width: 25px;
            height: 25px;
          }

          .text {
            font-size: 18px;
          }
        }
      }

      .confirm-btn {
        height: 55px;
        line-height: 50px;
        font-size: 25px;
      }
    }

    // 解锁弹框
    .buy-confirm {
      width: 100%;
      height: 480px;

      .title {
        height: 62px;
        font-size: 40px;
        line-height: 62px;
      }

      .text {
        height: 30px;
        font-size: 20px;
        line-height: 30px;
      }

      .parameter-list {
        margin-top: 40px;

        .parameter-item {
          font-size: 20px;
          margin-top: 20px;
        }
      }

      .btn {
        margin-top: 40px;
        height: 55px;
        font-size: 22px;
        line-height: 55px;
      }
    }
  }
}
</style>