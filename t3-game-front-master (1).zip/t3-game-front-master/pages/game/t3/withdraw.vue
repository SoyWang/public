<template>
  <!-- 提现 -->
  <div class="withdraw">
    <div class="form">
      <div class="form-item">
        <p class="label">
          {{ $t("game.t3.withdrawal.inputLabelList[0].label") }}
        </p>
        <div class="input-box">
          <input
            class="input account-input"
            type="text"
            disabled
            v-model="currentAccount"
            :placeholder="
              $t('game.t3.withdrawal.inputLabelList[0].placeholder')
            "
          />
        </div>
        <div class="form-item">
          <p class="label">
            {{ $t("game.t3.withdrawal.inputLabelList[1].label") }}
          </p>
          <div class="input-box">
            <input
              class="input"
              type="number"
              v-model="withdrawFrom.t3t"
              :placeholder="`${$t(
                'game.t3.withdrawal.inputLabelList[1].placeholder'
              )} ${balance} F3Cash`"
            />
            <p class="unit unit-blue" @click="withdrawFrom.t3t = balance">
              {{ $t("game.t3.withdrawal.inputLabelList[1].allText") }}
            </p>
          </div>
        </div>
      </div>
      <div class="form-item">
        <p class="label">
          {{ $t("game.t3.withdrawal.inputLabelList[2].label") }}
        </p>
        <div class="input-box">
          <input
            class="input"
            type="number"
            disabled
            v-model="withdrawFrom.usdt"
            :placeholder="
              $t('game.t3.withdrawal.inputLabelList[2].placeholder')
            "
          />
          <p class="unit">USDT</p>
        </div>
      </div>
      <div class="form-item">
        <p class="label">
          {{ $t("game.t3.withdrawal.inputLabelList[3].label") }}
        </p>
        <div class="input-box">
          <input
            class="input"
            disabled
            type="number"
            v-model="withdrawFrom.poundage"
            :placeholder="
              $t('game.t3.withdrawal.inputLabelList[3].placeholder')
            "
          />
          <p class="unit">USDT</p>
        </div>
      </div>
    </div>
    <div class="btn-group">
      <div class="btn" @click="handleWithdraw">
        {{ $t("game.t3.withdrawal.withdrawalBtnText") }}
      </div>
      <div class="btn" @click="$router.push('/game/t3/withdrawDetail')">
        {{ $t("game.t3.withdrawal.withdrawalDetailBtnText") }}
      </div>
    </div>
  </div>
</template>

<script>
import herobankabi from "@/static/web3js/abi/t3/herobankabi.json";
import autoheroabi from "@/static/web3js/abi/t3/autoheroabi.json";
import herostorageabi from "@/static/web3js/abi/t3/herostorageabi.json";
import walletMxin from "@/pages/mixin/walletMxin";
export default {
  mixins: [walletMxin],
  layout: "t3Game",
  data() {
    return {
      exchangeRatio: null, // 兑换比例数
      poundageRatio: null, // 手续费比例
      balance: null, // 代币余额
      usdtBalance: null, // 合约usdt余额
      withdrawFrom: {
        walletAddress: null,
        t3t: null,
        usdt: null,
        poundage: null,
      }, // 提现表单
    };
  },
  async created() {
    // 判断是否连接了钱包
    if (
      this.$web3.currentProvider.selectedAddress &&
      this.$web3.utils.hexToNumber(this.$web3.currentProvider.chainId) ==
        this.$chainId
    ) {
      // 获取当前账户
      await this.getCurrentAccount();
      // 获取合约数据
      await this.watchAccountChange();
    }
  },
  watch: {
    "withdrawFrom.t3t"(value) {
      if (value) {
        this.withdrawFrom.usdt = this.$BigNumber(value)
          .times(this.exchangeRatio)
          .toString(10);
        this.withdrawFrom.poundage =
          this.withdrawFrom.usdt * this.poundageRatio;
      } else {
        this.withdrawFrom.usdt = null;
        this.withdrawFrom.poundage = null;
      }
    },
  },
  methods: {
    /**
     * 监听账号改变
     */
    async watchAccountChange() {
      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.loadingText"),
        forbidClick: true,
        duration: 0,
        overlay: true,
      });
      await this.fetchCoinNumber();
      await this.fetchUsdtBalance();
      await this.fetchWithdrawRatio();
      await this.fetchWithdrawPoundage();
      // 关闭加载动画
      loading.clear();
    },

    /**
     * 获取用户可提现的代币数量
     */
    async fetchCoinNumber() {
      let ethContract = new this.$web3.eth.Contract(
        autoheroabi,
        this.$autoheroabiAddress
      );
      let data = await ethContract.methods
        .getUserAvailableHeroBalance(this.currentAccount)
        .call();
      this.balance = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4)
        .toString(10);
      console.log("用户当前可提现的T3T：", this.balance);
    },

    /**
     * 获取合约中的usdt余额
     */
    async fetchUsdtBalance() {
      let ethContract = new this.$web3.eth.Contract(
        herobankabi,
        this.$herobankabiAddress
      );
      let data = await ethContract.methods
        .balanceOf(this.$usdttokenabiAddress)
        .call();
      this.usdtBalance = this.$BigNumber(data)
        .div(Math.pow(10, 6))
        .toFixed(4)
        .toString(10);
      console.log("合约中usdt余额：", this.usdtBalance);
    },

    /**
     * 获取提现兑换比列
     */
    async fetchWithdrawRatio() {
      let ethContract = new this.$web3.eth.Contract(
        autoheroabi,
        this.$autoheroabiAddress
      );
      let data = await ethContract.methods
        .getNTExchangeRatioAgainstUsdt()
        .call();
      this.exchangeRatio = Number(data) / 100;
      console.log("提现兑换比例：", this.exchangeRatio);
    },

    /**
     * 获取提现手续费比例
     */
    async fetchWithdrawPoundage() {
      let ethContract = new this.$web3.eth.Contract(
        herostorageabi,
        this.$herostorageabiAddress
      );
      let data = await ethContract.methods.config().call();
      this.poundageRatio = Number(data.commissionRatio) / 100;
      console.log("体现手续费比例：", this.poundageRatio);
    },

    /**
     * 提现
     */
    async handleWithdraw() {
      // 判断提现金额是否为空
      if (!this.withdrawFrom.t3t) {
        return this.$toast(
          this.$i18n.tc("game.t3.tips.toast.withdrawNumberText1")
        );
      }
      // 判断合约中的usdt是否足够
      if (
        this.$BigNumber(this.withdrawFrom.usdt)
          .times(Math.pow(10, 6))
          .integerValue()
          .gt(
            this.$BigNumber(this.usdtBalance)
              .times(Math.pow(10, 6))
              .integerValue()
          )
      ) {
        return this.$toast.fail(
          this.$i18n.tc("game.t3.tips.toast.withdrawNumberText2")
        );
      }
      // 判断提现的t3t是否大于最大可提现数量
      if (this.withdrawFrom.t3t > Number(this.balance)) {
        return this.$toast(
          this.$i18n.tc("game.t3.tips.toast.withdrawNumberText3")
        );
      }
      // 判断提现的t3t是否等于0
      if (Number(this.balance) == 0) {
        return this.$toast(
          this.$i18n.tc("game.t3.tips.toast.withdrawNumberText4")
        );
      }

      // 开始加载动画
      let loading = this.$toast.loading({
        message: this.$i18n.tc("game.t3.tips.loading.withdrawText"),
        forbidClick: true,
        duration: 0,
        loadingType: "spinner",
        overlay: true,
      });

      // 提现
      let ethContract = new this.$web3.eth.Contract(
        autoheroabi,
        this.$autoheroabiAddress
      );
      try {
        let data = await ethContract.methods
          .withdraw(
            this.$herotonkenabiAddress,
            this.$BigNumber(this.withdrawFrom.t3t)
              .times(Math.pow(10, 6))
              .integerValue()
              .toString(10)
          )
          .send({ from: this.currentAccount });
        console.log(data);
        this.$router.push("/game/t3/withdrawSuccess");
      } catch (err) {
        console.error(err);
        this.$router.push("/game/t3/withdrawFail");
      } finally {
        // 关闭加载动画
        loading.clear();
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.withdraw {
  width: 100%;
  padding: 0 15px;
  padding-bottom: 30px;

  .form {
    display: flex;
    flex-direction: column;
    align-items: center;

    .form-item {
      margin-top: 30px;
      width: 100%;
      display: flex;
      flex-direction: column;

      .label {
        font-size: 14px;
        font-family: PingFang SC;
        font-weight: 400;
        line-height: 22px;
        color: #ffffff;
      }

      .input-box {
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);

        .input {
          width: 88%;
          font-size: 14px;
          height: 45px;
          background: none;
          outline: none;
          border: none;
          outline: none;
          color: rgba(255, 255, 255, 0.5);
          font-family: PingFang SC;
          font-weight: 400;
        }

        .account-input {
          width: 100%;
        }

        .unit {
          font-size: 14px;
          font-family: PingFang SC;
          font-weight: 400;
          line-height: 45px;
          color: #ffffff;
        }

        .unit-blue {
          color: #4773fd;
        }
      }
    }
  }

  .btn-group {
    margin-top: 50px;
    width: 100%;
    display: flex;
    flex-direction: column;

    .btn {
      height: 40px;
      border-radius: 5px;
      text-align: center;
      font-size: 16px;
      font-family: PingFang SC;
      font-weight: bold;
      line-height: 40px;
      color: #ffffff;

      &:nth-child(1) {
        background: linear-gradient(180deg, #00d5ff 0%, #0044ff 100%);
      }

      &:nth-child(2) {
        margin-top: 20px;
        background: rgba(255, 255, 255, 0.39);
      }
    }
  }
}

/* 浏览器可视宽度大于600px */
@media only screen and (min-width: 600px) {
  .withdraw {
    padding-bottom: 40px;

    .form {
      .form-item {
        margin-top: 40px;

        .label {
          font-size: 20px;
          line-height: 32px;
        }

        .input-box {
          .input {
            font-size: 20px;
            height: 55px;
          }

          .account-input {
            width: 100%;
          }

          .unit {
            font-size: 20px;
            line-height: 55px;
          }

          .unit-blue {
          }
        }
      }
    }

    .btn-group {
      margin-top: 65px;

      .btn {
        height: 65px;
        font-size: 22px;
        line-height: 65px;

        &:nth-child(1) {
        }

        &:nth-child(2) {
          margin-top: 30px;
        }
      }
    }
  }
}
</style>