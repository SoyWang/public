<template>
  <!-- 操作结果弹窗 -->
  <van-popup
    class="result-popup"
    v-model="show"
    :close-on-click-overlay="false"
    @click-overlay="handleClosePopup"
  >
    <div class="result-content">
      <img
        @click="handleClosePopup"
        class="close-icon"
        src="@/assets/images/game/cup/close-cricle-icon.png"
        alt=""
      />
      <img
        class="result-icon"
        src="@/assets/images/game/cup/success-icon.png"
        alt=""
        v-if="type == 'success'"
      />
      <img
        class="result-icon"
        src="@/assets/images/game/cup/faild-icon.png"
        alt=""
        v-else
      />
      <p class="message">{{ message }}</p>
    </div>
  </van-popup>
</template>

<script>
export default {
  props: {
    show: {
      type: Boolean,
      default: false,
    },
    type: {
      type: String,
      default: "",
    },
    message: {
      type: String,
      default: "",
    },
  },
  data() {
    return {};
  },
  methods: {
    /**
     * 关闭弹窗
     */
    handleClosePopup() {
      this.$emit("close");
    },
  },
};
</script>

<style lang="scss" scoped>
.result-popup {
  // 操作结果弹窗
  width: 93%;
  background: #1b1b1b !important;
  border-radius: 7px;
  padding-bottom: 20px;

  .result-content {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    .close-icon {
      position: absolute;
      top: 10px;
      right: 12px;
      width: 24px;
      height: 24px;
    }

    .result-icon {
      margin-top: 30px;
      width: 80px;
      height: 80px;
    }

    .message {
      margin-top: 10px;
      font-size: 16px;
      font-family: DM Sans-Medium, DM Sans;
      font-weight: 500;
      color: #ffffff;
    }
  }
}
</style>