export const state = () => ({
    locales: ['zh', 'en'],
    locale: 'en',
    matchList: [], // 比赛列表
    teamList: [], // 球队列表
})

export const mutations = {
    // 设置语言
    SET_LANG(state, locale) {
        if (state.locales.indexOf(locale) !== -1) {
            state.locale = locale
        }
    },

    // 比赛列表
    SET_MATCH_LIST(state, matchList) {
        state.matchList = matchList
    },

    // 设置球队列表
    SET_TEAM_LIST(state, teamList) {
        state.teamList = teamList
    }
}

export const actions = {

}